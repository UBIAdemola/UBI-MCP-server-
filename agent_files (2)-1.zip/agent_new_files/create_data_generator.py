
# BEGIN: user added these matplotlib lines to ensure any plots do not pop-up in their UI
import matplotlib
matplotlib.use('Agg')  # Set the backend to non-interactive
import matplotlib.pyplot as plt
plt.ioff()
import os
os.environ['TERM'] = 'dumb'
# END: user added these matplotlib lines to ensure any plots do not pop-up in their UI
# filename: create_data_generator.py
# execution: true

data_generator_code = '''"""
Data generator for University Incubator Analysis.

Generates realistic synthetic data for incubator performance metrics,
structuration contexts, and entrepreneur profiles.
"""

import random
from typing import List
from data_models import (
    IncubatorMetrics, StructurationContext, StructurationDimension,
    EntrepreneurProfile, AgenticCapability, IncubatorData
)


def generate_incubator_data(
    num_incubators: int = 5,
    time_periods: int = 12,
    seed: int = None
) -> IncubatorData:
    """
    Generate synthetic incubator data.
    
    Args:
        num_incubators: Number of incubators to generate
        time_periods: Number of time periods (e.g., quarters)
        seed: Random seed for reproducibility
        
    Returns:
        IncubatorData object with metrics, contexts, and profiles
    """
    if seed is not None:
        random.seed(seed)
    
    metrics = []
    structuration_contexts = []
    entrepreneur_profiles = []
    
    # Generate data for each incubator
    for i in range(num_incubators):
        incubator_id = f"INC-{i+1:03d}"
        
        # Generate performance metrics over time
        for period in range(time_periods):
            period_name = f"Q{(period % 4) + 1}-{2020 + (period // 4)}"
            
            # Base values with growth trend
            growth_factor = 1 + (period * 0.05)
            total_capacity = random.randint(20, 50)
            occupied = int(total_capacity * random.uniform(0.6, 0.95))
            
            startups_admitted = random.randint(2, 8)
            startups_graduated = random.randint(1, 5)
            active_startups = int(occupied * random.uniform(0.8, 1.0))
            
            jobs = int(active_startups * random.uniform(3, 8) * growth_factor)
            revenue = active_startups * random.uniform(50000, 500000) * growth_factor
            funding = active_startups * random.uniform(100000, 1000000) * growth_factor
            
            occupancy_rate = occupied / total_capacity
            graduation_rate = startups_graduated / max(startups_admitted, 1)
            
            metric = IncubatorMetrics(
                incubator_id=incubator_id,
                period=period_name,
                total_capacity=total_capacity,
                occupied_spaces=occupied,
                staff_count=random.randint(3, 10),
                startups_admitted=startups_admitted,
                startups_graduated=startups_graduated,
                active_startups=active_startups,
                jobs_created=jobs,
                total_revenue=revenue,
                funding_raised=funding,
                survival_rate_1yr=random.uniform(0.7, 0.95),
                survival_rate_3yr=random.uniform(0.5, 0.8),
                occupancy_rate=occupancy_rate,
                graduation_rate=graduation_rate
            )
            metrics.append(metric)
        
        # Generate structuration context
        signification = StructurationDimension(
            dimension_name="Signification",
            structural_properties=[
                "Shared entrepreneurial language",
                "Innovation narratives",
                "Success stories and role models"
            ],
            modalities=[
                "Interpretive schemes",
                "Communication channels",
                "Symbolic resources"
            ],
            interaction_patterns=[
                "Mentoring conversations",
                "Pitch presentations",
                "Networking events"
            ],
            reproduction_score=random.uniform(0.5, 0.8),
            transformation_score=random.uniform(0.2, 0.5)
        )
        
        domination = StructurationDimension(
            dimension_name="Domination",
            structural_properties=[
                "Access to funding networks",
                "Physical infrastructure",
                "Expert knowledge base"
            ],
            modalities=[
                "Resource allocation mechanisms",
                "Authority structures",
                "Facilities management"
            ],
            interaction_patterns=[
                "Resource distribution",
                "Decision-making processes",
                "Power negotiations"
            ],
            reproduction_score=random.uniform(0.6, 0.9),
            transformation_score=random.uniform(0.1, 0.4)
        )
        
        legitimation = StructurationDimension(
            dimension_name="Legitimation",
            structural_properties=[
                "Entrepreneurial norms",
                "Ethical guidelines",
                "Quality standards"
            ],
            modalities=[
                "Normative frameworks",
                "Sanctions and rewards",
                "Evaluation criteria"
            ],
            interaction_patterns=[
                "Peer review",
                "Performance assessments",
                "Community building"
            ],
            reproduction_score=random.uniform(0.5, 0.8),
            transformation_score=random.uniform(0.2, 0.5)
        )
        
        structural_rigidity = random.uniform(0.3, 0.7)
        agency_space = 1.0 - structural_rigidity + random.uniform(-0.1, 0.1)
        agency_space = max(0.0, min(1.0, agency_space))
        
        context = StructurationContext(
            incubator_id=incubator_id,
            signification=signification,
            domination=domination,
            legitimation=legitimation,
            structural_rigidity=structural_rigidity,
            agency_space=agency_space,
            duality_balance=abs(structural_rigidity - agency_space)
        )
        structuration_contexts.append(context)
        
        # Generate entrepreneur profiles
        num_entrepreneurs = random.randint(5, 15)
        for j in range(num_entrepreneurs):
            entrepreneur_id = f"ENT-{i+1:03d}-{j+1:03d}"
            
            intentionality = AgenticCapability(
                capability_name="Intentionality",
                score=random.uniform(0.5, 1.0),
                indicators=[
                    "Clear business goals",
                    "Strategic planning",
                    "Goal commitment"
                ],
                constraints=[
                    "Market uncertainty",
                    "Resource limitations"
                ]
            )
            
            forethought = AgenticCapability(
                capability_name="Forethought",
                score=random.uniform(0.4, 0.95),
                indicators=[
                    "Scenario planning",
                    "Risk assessment",
                    "Future visioning"
                ],
                constraints=[
                    "Information asymmetry",
                    "Rapid market changes"
                ]
            )
            
            self_reactiveness = AgenticCapability(
                capability_name="Self-Reactiveness",
                score=random.uniform(0.5, 0.95),
                indicators=[
                    "Performance monitoring",
                    "Adaptive behavior",
                    "Self-motivation"
                ],
                constraints=[
                    "Time pressure",
                    "Competing priorities"
                ]
            )
            
            self_reflectiveness = AgenticCapability(
                capability_name="Self-Reflectiveness",
                score=random.uniform(0.4, 0.9),
                indicators=[
                    "Critical self-assessment",
                    "Learning from failure",
                    "Metacognitive awareness"
                ],
                constraints=[
                    "Cognitive biases",
                    "Emotional attachment"
                ]
            )
            
            overall_score = (
                intentionality.score +
                forethought.score +
                self_reactiveness.score +
                self_reflectiveness.score
            ) / 4
            
            # Determine agency type
            if overall_score > 0.8:
                agency_type = "Transformative"
            elif overall_score > 0.6:
                agency_type = "Proactive"
            elif overall_score > 0.4:
                agency_type = "Adaptive"
            else:
                agency_type = "Reactive"
            
            profile = EntrepreneurProfile(
                entrepreneur_id=entrepreneur_id,
                incubator_id=incubator_id,
                intentionality=intentionality,
                forethought=forethought,
                self_reactiveness=self_reactiveness,
                self_reflectiveness=self_reflectiveness,
                overall_agency_score=overall_score,
                agency_type=agency_type
            )
            entrepreneur_profiles.append(profile)
    
    return IncubatorData(
        metrics=metrics,
        structuration_contexts=structuration_contexts,
        entrepreneur_profiles=entrepreneur_profiles,
        metadata={
            "num_incubators": num_incubators,
            "time_periods": time_periods,
            "seed": seed
        }
    )
'''

# Write the file
with open('mcp_tools_runner/university_incubator_analysis/data_generator.py', 'w') as f:
    f.write(data_generator_code)

print("Created data_generator.py")
print(f"File size: {len(data_generator_code)} characters")