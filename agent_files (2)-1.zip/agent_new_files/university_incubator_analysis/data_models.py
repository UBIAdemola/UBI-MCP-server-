"""
Data models for University Incubator Analysis Tool

This module defines the data structures for performance metrics,
structuration theory concepts, and agentic processes.
"""

from dataclasses import dataclass, field, asdict
from typing import List, Dict, Any, Optional
from datetime import datetime
from enum import Enum


class MarketReach(Enum):
    """Market reach categories"""
    LOCAL = "local"
    REGIONAL = "regional"
    NATIONAL = "national"
    INTERNATIONAL = "international"


class IncubatorStage(Enum):
    """Incubator lifecycle stages"""
    STARTUP = "startup"
    GROWTH = "growth"
    MATURITY = "maturity"
    DECLINE = "decline"


@dataclass
class InputMetrics:
    """Input-based metrics (resources and services)"""
    staff_count: int
    mentors_available: int
    training_hours: float
    infrastructure_investment: float
    networking_events: int = 0
    legal_support_hours: float = 0.0
    technical_support_hours: float = 0.0

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class OutputMetrics:
    """Output-based metrics (outcomes and impact)"""
    patents_filed: int
    products_launched: int
    market_reach: MarketReach
    revenue_generated: float
    external_funding_secured: float
    partnerships_formed: int = 0
    media_mentions: int = 0

    def to_dict(self) -> Dict[str, Any]:
        result = asdict(self)
        result['market_reach'] = self.market_reach.value
        return result


@dataclass
class IncubatorMetrics:
    """Comprehensive incubator performance metrics"""
    incubator_id: str
    period: datetime
    incubator_name: str

    # Capacity and occupancy
    total_capacity: int
    current_occupants: int
    occupancy_rate: float

    # Startup flow metrics
    startups_admitted: int
    startups_graduated: int
    startups_failed: int
    startups_active: int

    # Success metrics
    graduation_rate: float
    survival_rate: float

    # Economic impact
    jobs_created: int
    total_revenue_generated: float
    total_funding_raised: float

    # Input and output metrics
    input_metrics: InputMetrics
    output_metrics: OutputMetrics

    # Stage and context
    stage: IncubatorStage = IncubatorStage.GROWTH

    def to_dict(self) -> Dict[str, Any]:
        result = asdict(self)
        result['period'] = self.period.isoformat()
        result['stage'] = self.stage.value
        result['input_metrics'] = self.input_metrics.to_dict()
        result['output_metrics'] = self.output_metrics.to_dict()
        return result


# Structuration Theory Models

@dataclass
class SignificationStructure:
    """Signification dimension - meaning-making structures"""
    formal_rules: List[str]
    informal_norms: List[str]
    communication_patterns: List[str]
    interpretive_schemas: List[Dict[str, Any]] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class DominationStructure:
    """Domination dimension - power relations and resources"""
    resource_allocation: Dict[str, Any]
    power_hierarchies: List[Dict[str, Any]]
    decision_making_authority: Dict[str, str]
    resource_control_points: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class LegitimationStructure:
    """Legitimation dimension - normative orders"""
    institutional_norms: List[str]
    evaluation_criteria: List[str]
    sanctions_rewards: Dict[str, Any]
    moral_frameworks: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class AgencyManifestation:
    """How agency manifests within structures"""
    rule_interpretations: List[Dict[str, Any]]
    resource_mobilizations: List[Dict[str, Any]]
    norm_challenges: List[Dict[str, Any]]
    creative_adaptations: List[Dict[str, Any]] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class StructurationDynamics:
    """Dynamic processes of structuration"""
    reproduction_events: List[Dict[str, Any]]
    transformation_events: List[Dict[str, Any]]
    temporal_evolution: List[Dict[str, Any]] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class StructurationContext:
    """Complete structuration context for an incubator"""
    incubator_id: str
    timestamp: datetime

    # The three dimensions of structure
    signification: SignificationStructure
    domination: DominationStructure
    legitimation: LegitimationStructure

    # Agency manifestations
    agency_manifestations: AgencyManifestation

    # Structuration dynamics
    structuration_dynamics: StructurationDynamics

    # Meta-information
    structural_rigidity: float = 0.5  # 0 = highly flexible, 1 = highly rigid
    agency_space: float = 0.5  # 0 = highly constrained, 1 = highly autonomous

    def to_dict(self) -> Dict[str, Any]:
        result = {
            'incubator_id': self.incubator_id,
            'timestamp': self.timestamp.isoformat(),
            'signification': self.signification.to_dict(),
            'domination': self.domination.to_dict(),
            'legitimation': self.legitimation.to_dict(),
            'agency_manifestations': self.agency_manifestations.to_dict(),
            'structuration_dynamics': self.structuration_dynamics.to_dict(),
            'structural_rigidity': self.structural_rigidity,
            'agency_space': self.agency_space
        }
        return result


# Agentic Processes Models

@dataclass
class Intentionality:
    """Intentionality - goal-directed behavior"""
    goal_clarity: float  # 0-1
    strategic_planning: float  # 0-1
    commitment_level: float  # 0-1
    goal_descriptions: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class Forethought:
    """Forethought - anticipatory capability"""
    future_orientation: float  # 0-1
    scenario_planning: float  # 0-1
    risk_assessment: float  # 0-1
    planning_horizon_months: int = 12

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class SelfReactiveness:
    """Self-reactiveness - adaptive capability"""
    adaptability: float  # 0-1
    course_correction: float  # 0-1
    resource_seeking: float  # 0-1
    pivot_count: int = 0

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class SelfReflectiveness:
    """Self-reflectiveness - metacognitive capability"""
    metacognition: float  # 0-1
    learning_orientation: float  # 0-1
    feedback_integration: float  # 0-1
    reflection_frequency: str = "weekly"

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class AgenticCapabilities:
    """Complete set of agentic capabilities"""
    intentionality: Intentionality
    forethought: Forethought
    self_reactiveness: SelfReactiveness
    self_reflectiveness: SelfReflectiveness

    def overall_agency_score(self) -> float:
        """Calculate overall agency score"""
        scores = [
            (self.intentionality.goal_clarity +
             self.intentionality.strategic_planning +
             self.intentionality.commitment_level) / 3,
            (self.forethought.future_orientation +
             self.forethought.scenario_planning +
             self.forethought.risk_assessment) / 3,
            (self.self_reactiveness.adaptability +
             self.self_reactiveness.course_correction +
             self.self_reactiveness.resource_seeking) / 3,
            (self.self_reflectiveness.metacognition +
             self.self_reflectiveness.learning_orientation +
             self.self_reflectiveness.feedback_integration) / 3
        ]
        return sum(scores) / len(scores)

    def to_dict(self) -> Dict[str, Any]:
        result = {
            'intentionality': self.intentionality.to_dict(),
            'forethought': self.forethought.to_dict(),
            'self_reactiveness': self.self_reactiveness.to_dict(),
            'self_reflectiveness': self.self_reflectiveness.to_dict(),
            'overall_agency_score': self.overall_agency_score()
        }
        return result


@dataclass
class EmbeddedConstraints:
    """Structural constraints embedding the entrepreneur"""
    institutional_pressures: List[str]
    resource_limitations: List[str]
    network_dependencies: List[str]
    constraint_severity: Dict[str, float] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class AgencyStructureInteraction:
    """Interactions between agency and structure"""
    constraint_negotiations: List[Dict[str, Any]]
    opportunity_creations: List[Dict[str, Any]]
    structure_transformations: List[Dict[str, Any]]

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class EntrepreneurProfile:
    """Complete entrepreneur profile within incubator"""
    entrepreneur_id: str
    incubator_id: str
    timestamp: datetime
    entrepreneur_name: str
    venture_name: str

    # Agentic capabilities
    agentic_capabilities: AgenticCapabilities

    # Embedded constraints
    embedded_constraints: EmbeddedConstraints

    # Agency-structure interactions
    agency_structure_interactions: AgencyStructureInteraction

    # Outcomes
    venture_stage: str = "ideation"
    success_indicators: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        result = {
            'entrepreneur_id': self.entrepreneur_id,
            'incubator_id': self.incubator_id,
            'timestamp': self.timestamp.isoformat(),
            'entrepreneur_name': self.entrepreneur_name,
            'venture_name': self.venture_name,
            'agentic_capabilities': self.agentic_capabilities.to_dict(),
            'embedded_constraints': self.embedded_constraints.to_dict(),
            'agency_structure_interactions': self.agency_structure_interactions.to_dict(),
            'venture_stage': self.venture_stage,
            'success_indicators': self.success_indicators
        }
        return result
