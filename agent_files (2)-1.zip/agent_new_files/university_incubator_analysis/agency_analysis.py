"""
Agentic processes analysis module

Analyzes entrepreneurial agency and agency-structure interactions in incubator contexts.
"""

from typing import Dict, Any, List, Optional
from datetime import datetime
import numpy as np
from collections import defaultdict

from .data_models import EntrepreneurProfile, StructurationContext


class AgencyAnalyzer:
    """Analyzes agentic processes and capabilities"""

    def __init__(self):
        """Initialize the agency analyzer"""
        pass

    def analyze_agency(
        self,
        entrepreneur_profiles: List[EntrepreneurProfile],
        structural_context: Optional[StructurationContext] = None
    ) -> Dict[str, Any]:
        """
        Comprehensive agentic processes analysis

        Args:
            entrepreneur_profiles: List of entrepreneur profiles
            structural_context: Optional structural context for interaction analysis

        Returns:
            Dictionary with agency analysis results
        """
        if not entrepreneur_profiles:
            return {'error': 'No entrepreneur profiles provided'}

        analysis = {
            'summary': self._generate_summary(entrepreneur_profiles),
            'capability_analysis': self._analyze_capabilities(entrepreneur_profiles),
            'constraint_analysis': self._analyze_constraints(entrepreneur_profiles),
            'interaction_analysis': self._analyze_interactions(entrepreneur_profiles),
            'typology': self._create_agency_typology(entrepreneur_profiles),
            'success_correlations': self._analyze_success_correlations(entrepreneur_profiles),
            'insights': self._generate_agency_insights(entrepreneur_profiles),
            'timestamp': datetime.now().isoformat()
        }

        if structural_context:
            analysis['agency_structure_fit'] = self._analyze_agency_structure_fit(
                entrepreneur_profiles, structural_context
            )

        return analysis

    def _generate_summary(self, profiles: List[EntrepreneurProfile]) -> Dict[str, Any]:
        """Generate summary statistics"""

        summary = {
            'total_entrepreneurs': len(profiles),
            'incubators_represented': len(set(p.incubator_id for p in profiles)),
            'venture_stages': self._count_venture_stages(profiles),
            'average_agency_score': float(np.mean([
                p.agentic_capabilities.overall_agency_score() for p in profiles
            ]))
        }

        return summary

    def _count_venture_stages(self, profiles: List[EntrepreneurProfile]) -> Dict[str, int]:
        """Count ventures by stage"""
        stages = defaultdict(int)
        for p in profiles:
            stages[p.venture_stage] += 1
        return dict(stages)

    def _analyze_capabilities(self, profiles: List[EntrepreneurProfile]) -> Dict[str, Any]:
        """Analyze agentic capabilities across all entrepreneurs"""

        capability_analysis = {}

        # Extract capability scores
        intentionality_scores = []
        forethought_scores = []
        reactiveness_scores = []
        reflectiveness_scores = []

        for profile in profiles:
            cap = profile.agentic_capabilities

            intentionality_scores.append(
                (cap.intentionality.goal_clarity +
                 cap.intentionality.strategic_planning +
                 cap.intentionality.commitment_level) / 3
            )

            forethought_scores.append(
                (cap.forethought.future_orientation +
                 cap.forethought.scenario_planning +
                 cap.forethought.risk_assessment) / 3
            )

            reactiveness_scores.append(
                (cap.self_reactiveness.adaptability +
                 cap.self_reactiveness.course_correction +
                 cap.self_reactiveness.resource_seeking) / 3
            )

            reflectiveness_scores.append(
                (cap.self_reflectiveness.metacognition +
                 cap.self_reflectiveness.learning_orientation +
                 cap.self_reflectiveness.feedback_integration) / 3
            )

        # Aggregate statistics
        capability_analysis['intentionality'] = self._capability_stats(intentionality_scores)
        capability_analysis['forethought'] = self._capability_stats(forethought_scores)
        capability_analysis['self_reactiveness'] = self._capability_stats(reactiveness_scores)
        capability_analysis['self_reflectiveness'] = self._capability_stats(reflectiveness_scores)

        # Detailed sub-dimension analysis
        capability_analysis['detailed_dimensions'] = self._detailed_dimension_analysis(profiles)

        # Capability patterns
        capability_analysis['patterns'] = self._identify_capability_patterns(profiles)

        return capability_analysis

    def _capability_stats(self, scores: List[float]) -> Dict[str, float]:
        """Calculate statistics for a capability dimension"""
        return {
            'mean': float(np.mean(scores)),
            'median': float(np.median(scores)),
            'std': float(np.std(scores)),
            'min': float(np.min(scores)),
            'max': float(np.max(scores)),
            'q25': float(np.percentile(scores, 25)),
            'q75': float(np.percentile(scores, 75))
        }

    def _detailed_dimension_analysis(self, profiles: List[EntrepreneurProfile]) -> Dict[str, Dict[str, float]]:
        """Analyze each sub-dimension of agentic capabilities"""

        dimensions = {
            'goal_clarity': [p.agentic_capabilities.intentionality.goal_clarity for p in profiles],
            'strategic_planning': [p.agentic_capabilities.intentionality.strategic_planning for p in profiles],
            'commitment_level': [p.agentic_capabilities.intentionality.commitment_level for p in profiles],
            'future_orientation': [p.agentic_capabilities.forethought.future_orientation for p in profiles],
            'scenario_planning': [p.agentic_capabilities.forethought.scenario_planning for p in profiles],
            'risk_assessment': [p.agentic_capabilities.forethought.risk_assessment for p in profiles],
            'adaptability': [p.agentic_capabilities.self_reactiveness.adaptability for p in profiles],
            'course_correction': [p.agentic_capabilities.self_reactiveness.course_correction for p in profiles],
            'resource_seeking': [p.agentic_capabilities.self_reactiveness.resource_seeking for p in profiles],
            'metacognition': [p.agentic_capabilities.self_reflectiveness.metacognition for p in profiles],
            'learning_orientation': [p.agentic_capabilities.self_reflectiveness.learning_orientation for p in profiles],
            'feedback_integration': [p.agentic_capabilities.self_reflectiveness.feedback_integration for p in profiles]
        }

        result = {}
        for dim_name, scores in dimensions.items():
            result[dim_name] = {
                'mean': float(np.mean(scores)),
                'std': float(np.std(scores))
            }

        return result

    def _identify_capability_patterns(self, profiles: List[EntrepreneurProfile]) -> Dict[str, Any]:
        """Identify patterns in capability combinations"""

        patterns = {}

        # Correlation between capabilities
        cap_matrix = []
        for profile in profiles:
            cap = profile.agentic_capabilities
            cap_matrix.append([
                (cap.intentionality.goal_clarity + cap.intentionality.strategic_planning + cap.intentionality.commitment_level) / 3,
                (cap.forethought.future_orientation + cap.forethought.scenario_planning + cap.forethought.risk_assessment) / 3,
                (cap.self_reactiveness.adaptability + cap.self_reactiveness.course_correction + cap.self_reactiveness.resource_seeking) / 3,
                (cap.self_reflectiveness.metacognition + cap.self_reflectiveness.learning_orientation + cap.self_reflectiveness.feedback_integration) / 3
            ])

        cap_matrix = np.array(cap_matrix)
        if len(cap_matrix) > 1:
            corr_matrix = np.corrcoef(cap_matrix.T)
            patterns['correlations'] = {
                'intentionality_forethought': float(corr_matrix[0, 1]),
                'intentionality_reactiveness': float(corr_matrix[0, 2]),
                'intentionality_reflectiveness': float(corr_matrix[0, 3]),
                'forethought_reactiveness': float(corr_matrix[1, 2]),
                'forethought_reflectiveness': float(corr_matrix[1, 3]),
                'reactiveness_reflectiveness': float(corr_matrix[2, 3])
            }

        # Identify capability profiles
        patterns['profiles'] = self._cluster_capability_profiles(cap_matrix)

        return patterns

    def _cluster_capability_profiles(self, cap_matrix: np.ndarray) -> Dict[str, Any]:
        """Cluster entrepreneurs by capability profiles"""

        if len(cap_matrix) < 3:
            return {'insufficient_data': True}

        # Simple clustering based on overall capability level
        overall_scores = np.mean(cap_matrix, axis=1)

        high_agency = np.sum(overall_scores > 0.7)
        moderate_agency = np.sum((overall_scores >= 0.4) & (overall_scores <= 0.7))
        low_agency = np.sum(overall_scores < 0.4)

        return {
            'high_agency_count': int(high_agency),
            'moderate_agency_count': int(moderate_agency),
            'low_agency_count': int(low_agency),
            'distribution': {
                'high': float(high_agency / len(overall_scores)),
                'moderate': float(moderate_agency / len(overall_scores)),
                'low': float(low_agency / len(overall_scores))
            }
        }

    def _analyze_constraints(self, profiles: List[EntrepreneurProfile]) -> Dict[str, Any]:
        """Analyze embedded constraints"""

        constraint_analysis = {}

        # Count constraint types
        institutional_counts = defaultdict(int)
        resource_counts = defaultdict(int)
        network_counts = defaultdict(int)

        for profile in profiles:
            constraints = profile.embedded_constraints
            for inst in constraints.institutional_pressures:
                institutional_counts[inst] += 1
            for res in constraints.resource_limitations:
                resource_counts[res] += 1
            for net in constraints.network_dependencies:
                network_counts[net] += 1

        constraint_analysis['institutional_pressures'] = dict(institutional_counts)
        constraint_analysis['resource_limitations'] = dict(resource_counts)
        constraint_analysis['network_dependencies'] = dict(network_counts)

        # Constraint severity
        severity_scores = []
        for profile in profiles:
            if profile.embedded_constraints.constraint_severity:
                severity_scores.append(profile.embedded_constraints.constraint_severity)

        if severity_scores:
            constraint_analysis['severity_analysis'] = {
                'institutional_avg': float(np.mean([s.get('institutional', 0.5) for s in severity_scores])),
                'resource_avg': float(np.mean([s.get('resource', 0.5) for s in severity_scores])),
                'network_avg': float(np.mean([s.get('network', 0.5) for s in severity_scores]))
            }

        # Most common constraints
        constraint_analysis['most_common'] = {
            'institutional': sorted(institutional_counts.items(), key=lambda x: x[1], reverse=True)[:3],
            'resource': sorted(resource_counts.items(), key=lambda x: x[1], reverse=True)[:3],
            'network': sorted(network_counts.items(), key=lambda x: x[1], reverse=True)[:3]
        }

        return constraint_analysis

    def _analyze_interactions(self, profiles: List[EntrepreneurProfile]) -> Dict[str, Any]:
        """Analyze agency-structure interactions"""

        interaction_analysis = {}

        # Constraint negotiations
        negotiation_outcomes = defaultdict(int)
        negotiation_strategies = defaultdict(int)

        for profile in profiles:
            for negotiation in profile.agency_structure_interactions.constraint_negotiations:
                outcome = negotiation.get('outcome', 'unknown')
                strategy = negotiation.get('strategy', 'unknown')
                negotiation_outcomes[outcome] += 1
                negotiation_strategies[strategy] += 1

        interaction_analysis['constraint_negotiations'] = {
            'outcomes': dict(negotiation_outcomes),
            'strategies': dict(negotiation_strategies),
            'success_rate': negotiation_outcomes.get('successful', 0) / max(1, sum(negotiation_outcomes.values()))
        }

        # Opportunity creation
        opportunity_mechanisms = defaultdict(int)
        opportunity_values = []

        for profile in profiles:
            for opp in profile.agency_structure_interactions.opportunity_creations:
                mechanism = opp.get('mechanism', 'unknown')
                value = opp.get('value', 0)
                opportunity_mechanisms[mechanism] += 1
                opportunity_values.append(value)

        interaction_analysis['opportunity_creation'] = {
            'mechanisms': dict(opportunity_mechanisms),
            'average_value': float(np.mean(opportunity_values)) if opportunity_values else 0,
            'total_opportunities': len(opportunity_values)
        }

        # Structure transformation
        transformation_roles = defaultdict(int)
        transformation_impacts = []

        for profile in profiles:
            for trans in profile.agency_structure_interactions.structure_transformations:
                role = trans.get('agency_role', 'unknown')
                impact = trans.get('impact', 0)
                transformation_roles[role] += 1
                transformation_impacts.append(impact)

        interaction_analysis['structure_transformation'] = {
            'roles': dict(transformation_roles),
            'average_impact': float(np.mean(transformation_impacts)) if transformation_impacts else 0,
            'transformative_entrepreneurs': len([p for p in profiles if p.agency_structure_interactions.structure_transformations])
        }

        return interaction_analysis

    def _create_agency_typology(self, profiles: List[EntrepreneurProfile]) -> Dict[str, Any]:
        """Create typology of entrepreneurial agency"""

        typology = {}

        # Classify each entrepreneur
        types = defaultdict(list)

        for profile in profiles:
            agency_type = self._classify_agency_type(profile)
            types[agency_type].append(profile.entrepreneur_id)

        typology['types'] = {
            agency_type: {
                'count': len(entrepreneurs),
                'percentage': len(entrepreneurs) / len(profiles),
                'examples': entrepreneurs[:3]
            }
            for agency_type, entrepreneurs in types.items()
        }

        # Type descriptions
        typology['descriptions'] = {
            'strategic_planner': 'High intentionality and forethought, methodical approach',
            'adaptive_improviser': 'High reactiveness and reflectiveness, flexible approach',
            'constrained_navigator': 'Moderate agency, works within structural constraints',
            'transformative_leader': 'High agency across dimensions, actively shapes structures',
            'learning_explorer': 'High reflectiveness, continuous learning orientation'
        }

        return typology

    def _classify_agency_type(self, profile: EntrepreneurProfile) -> str:
        """Classify an entrepreneur's agency type"""

        cap = profile.agentic_capabilities

        intentionality_score = (cap.intentionality.goal_clarity + cap.intentionality.strategic_planning + cap.intentionality.commitment_level) / 3
        forethought_score = (cap.forethought.future_orientation + cap.forethought.scenario_planning + cap.forethought.risk_assessment) / 3
        reactiveness_score = (cap.self_reactiveness.adaptability + cap.self_reactiveness.course_correction + cap.self_reactiveness.resource_seeking) / 3
        reflectiveness_score = (cap.self_reflectiveness.metacognition + cap.self_reflectiveness.learning_orientation + cap.self_reflectiveness.feedback_integration) / 3

        # High in intentionality and forethought
        if intentionality_score > 0.7 and forethought_score > 0.7:
            return 'strategic_planner'

        # High in reactiveness and reflectiveness
        if reactiveness_score > 0.7 and reflectiveness_score > 0.7:
            return 'adaptive_improviser'

        # High across all dimensions
        if all(score > 0.7 for score in [intentionality_score, forethought_score, reactiveness_score, reflectiveness_score]):
            return 'transformative_leader'

        # High in reflectiveness specifically
        if reflectiveness_score > 0.7:
            return 'learning_explorer'

        # Moderate or constrained
        return 'constrained_navigator'

    def _analyze_success_correlations(self, profiles: List[EntrepreneurProfile]) -> Dict[str, Any]:
        """Analyze correlations between agency and success indicators"""

        correlations = {}

        # Extract success metrics
        revenues = []
        users = []
        funding = []
        agency_scores = []

        for profile in profiles:
            if profile.success_indicators:
                revenues.append(profile.success_indicators.get('revenue', 0))
                users.append(profile.success_indicators.get('users', 0))
                funding.append(profile.success_indicators.get('funding_raised', 0))
                agency_scores.append(profile.agentic_capabilities.overall_agency_score())

        # Calculate correlations (if enough data)
        if len(agency_scores) > 2:
            correlations['agency_revenue_correlation'] = float(np.corrcoef(agency_scores, revenues)[0, 1]) if np.std(revenues) > 0 else 0
            correlations['agency_funding_correlation'] = float(np.corrcoef(agency_scores, funding)[0, 1]) if np.std(funding) > 0 else 0

            # High agency vs success
            high_agency = [i for i, score in enumerate(agency_scores) if score > 0.7]
            if high_agency:
                correlations['high_agency_outcomes'] = {
                    'avg_revenue': float(np.mean([revenues[i] for i in high_agency])),
                    'avg_funding': float(np.mean([funding[i] for i in high_agency])),
                    'count': len(high_agency)
                }

        return correlations

    def _generate_agency_insights(self, profiles: List[EntrepreneurProfile]) -> List[str]:
        """Generate insights about agency"""

        insights = []

        # Calculate average agency score
        avg_agency = np.mean([p.agentic_capabilities.overall_agency_score() for p in profiles])

        if avg_agency > 0.7:
            insights.append(f"High average agency score ({avg_agency:.2f}) indicates strong entrepreneurial capabilities across the cohort.")
        elif avg_agency < 0.4:
            insights.append(f"Low average agency score ({avg_agency:.2f}) suggests need for capability development programs.")

        # Constraint insights
        constraint_counts = [
            len(p.embedded_constraints.institutional_pressures) +
            len(p.embedded_constraints.resource_limitations) +
            len(p.embedded_constraints.network_dependencies)
            for p in profiles
        ]
        avg_constraints = np.mean(constraint_counts)

        if avg_constraints > 7:
            insights.append(f"High constraint load (avg {avg_constraints:.1f}) may limit entrepreneurial action. Consider structural reforms.")

        # Interaction insights
        transformative_count = len([
            p for p in profiles
            if p.agency_structure_interactions.structure_transformations
        ])
        if transformative_count > len(profiles) * 0.3:
            insights.append(f"{transformative_count} entrepreneurs are actively transforming structures, indicating dynamic agency-structure interplay.")

        # Capability variance
        agency_scores = [p.agentic_capabilities.overall_agency_score() for p in profiles]
        if np.std(agency_scores) > 0.2:
            insights.append("High variance in agency capabilities suggests need for differentiated support strategies.")

        return insights

    def _analyze_agency_structure_fit(
        self,
        profiles: List[EntrepreneurProfile],
        context: StructurationContext
    ) -> Dict[str, Any]:
        """Analyze fit between agency and structure"""

        fit_analysis = {}

        # Average agency space vs structural agency space
        avg_agency_score = np.mean([p.agentic_capabilities.overall_agency_score() for p in profiles])
        structural_agency_space = context.agency_space

        fit_analysis['fit_metrics'] = {
            'entrepreneur_agency_level': float(avg_agency_score),
            'structural_agency_space': float(structural_agency_space),
            'fit_gap': float(avg_agency_score - structural_agency_space),
            'fit_assessment': self._assess_fit(avg_agency_score, structural_agency_space)
        }

        # Constraint alignment
        # (Would need more detailed analysis of how structural constraints align with entrepreneur constraints)

        fit_analysis['recommendations'] = self._generate_fit_recommendations(avg_agency_score, structural_agency_space)

        return fit_analysis

    def _assess_fit(self, agency_score: float, agency_space: float) -> str:
        """Assess quality of fit between agency and structure"""
        gap = abs(agency_score - agency_space)

        if gap < 0.15:
            return 'excellent_fit'
        elif gap < 0.3:
            return 'good_fit'
        elif gap < 0.5:
            return 'moderate_mismatch'
        else:
            return 'poor_fit'

    def _generate_fit_recommendations(self, agency_score: float, agency_space: float) -> List[str]:
        """Generate recommendations based on fit analysis"""

        recommendations = []

        if agency_score > agency_space + 0.2:
            recommendations.append("Entrepreneurs have higher agency than structure allows. Consider relaxing constraints and increasing flexibility.")
        elif agency_score < agency_space - 0.2:
            recommendations.append("Structure provides more agency space than entrepreneurs utilize. Consider capability development programs.")
        else:
            recommendations.append("Good alignment between entrepreneurial agency and structural agency space.")

        return recommendations


def analyze_agency(
    entrepreneur_profiles: List[EntrepreneurProfile],
    structural_context: Optional[StructurationContext] = None
) -> Dict[str, Any]:
    """
    Convenience function for agency analysis

    Args:
        entrepreneur_profiles: List of entrepreneur profiles
        structural_context: Optional structural context

    Returns:
        Agency analysis results
    """
    analyzer = AgencyAnalyzer()
    return analyzer.analyze_agency(entrepreneur_profiles, structural_context)
