"""
Synthetic data generation for university incubator analysis

Generates realistic synthetic data for incubator performance metrics,
structuration contexts, and entrepreneur profiles.
"""

import numpy as np
import pandas as pd
from datetime import datetime, timedelta
from typing import List, Optional, Tuple
import random

from .data_models import (
    IncubatorMetrics, InputMetrics, OutputMetrics, MarketReach, IncubatorStage,
    StructurationContext, SignificationStructure, DominationStructure,
    LegitimationStructure, AgencyManifestation, StructurationDynamics,
    EntrepreneurProfile, AgenticCapabilities, Intentionality, Forethought,
    SelfReactiveness, SelfReflectiveness, EmbeddedConstraints,
    AgencyStructureInteraction
)


class IncubatorDataGenerator:
    """Generates realistic synthetic incubator data"""

    def __init__(self, seed: Optional[int] = None):
        """Initialize generator with optional seed for reproducibility"""
        if seed is not None:
            np.random.seed(seed)
            random.seed(seed)
        self.seed = seed

    def generate_incubator_data(
        self,
        num_incubators: int,
        time_periods: int,
        start_date: Optional[datetime] = None
    ) -> pd.DataFrame:
        """
        Generate synthetic incubator performance data

        Args:
            num_incubators: Number of incubators to generate
            time_periods: Number of time periods (quarters)
            start_date: Starting date (defaults to 3 years ago)

        Returns:
            DataFrame with incubator metrics
        """
        if start_date is None:
            start_date = datetime.now() - timedelta(days=365 * 3)

        all_metrics = []

        for inc_idx in range(num_incubators):
            incubator_id = f"INC_{inc_idx + 1:03d}"
            incubator_name = self._generate_incubator_name()

            # Initialize incubator characteristics
            base_capacity = np.random.randint(20, 100)
            stage_progression = self._generate_stage_progression(time_periods)

            for period_idx in range(time_periods):
                period_date = start_date + timedelta(days=90 * period_idx)
                stage = stage_progression[period_idx]

                metrics = self._generate_period_metrics(
                    incubator_id, incubator_name, period_date,
                    base_capacity, stage, period_idx
                )
                all_metrics.append(metrics.to_dict())

        df = pd.DataFrame(all_metrics)
        return df

    def _generate_incubator_name(self) -> str:
        """Generate a realistic incubator name"""
        prefixes = ["Tech", "Innovation", "Startup", "Venture", "Business", "Digital"]
        suffixes = ["Hub", "Lab", "Accelerator", "Incubator", "Center", "Space"]
        universities = ["University", "Institute", "College", "Academy"]

        return f"{random.choice(universities)} {random.choice(prefixes)} {random.choice(suffixes)}"

    def _generate_stage_progression(self, time_periods: int) -> List[IncubatorStage]:
        """Generate realistic stage progression over time"""
        stages = []
        current_stage = IncubatorStage.STARTUP

        for i in range(time_periods):
            # Probability of advancing to next stage
            if i > time_periods * 0.2 and current_stage == IncubatorStage.STARTUP:
                if np.random.random() > 0.6:
                    current_stage = IncubatorStage.GROWTH
            elif i > time_periods * 0.5 and current_stage == IncubatorStage.GROWTH:
                if np.random.random() > 0.7:
                    current_stage = IncubatorStage.MATURITY

            stages.append(current_stage)

        return stages

    def _generate_period_metrics(
        self,
        incubator_id: str,
        incubator_name: str,
        period_date: datetime,
        base_capacity: int,
        stage: IncubatorStage,
        period_idx: int
    ) -> IncubatorMetrics:
        """Generate metrics for a specific period"""

        # Stage-dependent multipliers
        stage_multipliers = {
            IncubatorStage.STARTUP: {'capacity': 0.6, 'performance': 0.5, 'resources': 0.7},
            IncubatorStage.GROWTH: {'capacity': 0.85, 'performance': 0.8, 'resources': 1.0},
            IncubatorStage.MATURITY: {'capacity': 1.0, 'performance': 0.9, 'resources': 1.2},
            IncubatorStage.DECLINE: {'capacity': 0.7, 'performance': 0.6, 'resources': 0.8}
        }

        mult = stage_multipliers[stage]

        # Capacity and occupancy
        total_capacity = int(base_capacity * mult['capacity'])
        occupancy_rate = np.random.beta(8, 3) * mult['capacity']  # Skewed towards higher occupancy
        current_occupants = int(total_capacity * occupancy_rate)

        # Startup flow metrics with temporal growth
        growth_factor = 1 + (period_idx * 0.05)  # 5% growth per period
        startups_admitted = max(1, int(np.random.poisson(5 * mult['performance']) * growth_factor))
        startups_graduated = max(0, int(np.random.poisson(2 * mult['performance'])))
        startups_failed = max(0, int(np.random.poisson(1.5)))
        startups_active = current_occupants

        # Success metrics
        # Total startups ever in the program (admitted + those already active)
        total_startups_processed = startups_admitted + startups_graduated + startups_failed
        graduation_rate = startups_graduated / max(1, total_startups_processed)
        # Survival rate: those who didn't fail out of total processed
        survival_rate = (startups_graduated + max(0, startups_admitted - startups_graduated - startups_failed)) / max(1, total_startups_processed)
        # Ensure survival rate is valid
        survival_rate = min(1.0, max(0.0, survival_rate))

        # Economic impact (log-normal distributions for financial metrics)
        jobs_created = max(0, int(np.random.lognormal(2.5, 0.8) * mult['performance']))
        total_revenue_generated = max(0, np.random.lognormal(12, 1.5) * mult['performance'])
        total_funding_raised = max(0, np.random.lognormal(13, 1.8) * mult['performance'])

        # Input metrics
        input_metrics = InputMetrics(
            staff_count=max(3, int(np.random.poisson(8 * mult['resources']))),
            mentors_available=max(5, int(np.random.poisson(15 * mult['resources']))),
            training_hours=max(10, np.random.lognormal(4, 0.5) * mult['resources']),
            infrastructure_investment=max(0, np.random.lognormal(11, 1.0) * mult['resources']),
            networking_events=max(1, int(np.random.poisson(6 * mult['resources']))),
            legal_support_hours=max(0, np.random.exponential(20) * mult['resources']),
            technical_support_hours=max(0, np.random.exponential(40) * mult['resources'])
        )

        # Output metrics
        market_reach_prob = np.random.random()
        if market_reach_prob < 0.4:
            market_reach = MarketReach.LOCAL
        elif market_reach_prob < 0.7:
            market_reach = MarketReach.REGIONAL
        elif market_reach_prob < 0.9:
            market_reach = MarketReach.NATIONAL
        else:
            market_reach = MarketReach.INTERNATIONAL

        output_metrics = OutputMetrics(
            patents_filed=max(0, int(np.random.poisson(2 * mult['performance']))),
            products_launched=max(0, int(np.random.poisson(3 * mult['performance']))),
            market_reach=market_reach,
            revenue_generated=total_revenue_generated,
            external_funding_secured=total_funding_raised,
            partnerships_formed=max(0, int(np.random.poisson(4 * mult['performance']))),
            media_mentions=max(0, int(np.random.poisson(8 * mult['performance'])))
        )

        return IncubatorMetrics(
            incubator_id=incubator_id,
            period=period_date,
            incubator_name=incubator_name,
            total_capacity=total_capacity,
            current_occupants=current_occupants,
            occupancy_rate=occupancy_rate,
            startups_admitted=startups_admitted,
            startups_graduated=startups_graduated,
            startups_failed=startups_failed,
            startups_active=startups_active,
            graduation_rate=graduation_rate,
            survival_rate=survival_rate,
            jobs_created=jobs_created,
            total_revenue_generated=total_revenue_generated,
            total_funding_raised=total_funding_raised,
            input_metrics=input_metrics,
            output_metrics=output_metrics,
            stage=stage
        )

    def generate_structuration_context(
        self,
        incubator_id: str,
        timestamp: Optional[datetime] = None
    ) -> StructurationContext:
        """Generate structuration context for an incubator"""

        if timestamp is None:
            timestamp = datetime.now()

        # Signification structures
        formal_rules = [
            "Startups must attend mandatory weekly check-ins",
            "Minimum 40 hours per week on-site presence required",
            "Quarterly milestone reviews with management committee",
            "IP ownership retained by startups with university having right of first refusal",
            "Equity stake of 5-10% required for acceptance",
            "Maximum 24-month residency period"
        ]

        informal_norms = [
            "Peer mentoring and collaboration expected among cohorts",
            "Open office hours maintain collaborative atmosphere",
            "Friday demo days for showcasing progress",
            "Coffee meetups for networking",
            "Failure is treated as learning opportunity",
            "Resource sharing among startups is encouraged"
        ]

        communication_patterns = [
            "Slack channel for daily communication",
            "Monthly all-hands meetings",
            "One-on-one mentor sessions",
            "Email updates to stakeholders",
            "Social media presence for publicity"
        ]

        signification = SignificationStructure(
            formal_rules=random.sample(formal_rules, k=random.randint(4, 6)),
            informal_norms=random.sample(informal_norms, k=random.randint(3, 5)),
            communication_patterns=communication_patterns,
            interpretive_schemas=[
                {"schema": "entrepreneurial_mindset", "prevalence": np.random.uniform(0.6, 0.9)},
                {"schema": "innovation_focus", "prevalence": np.random.uniform(0.7, 1.0)},
                {"schema": "growth_orientation", "prevalence": np.random.uniform(0.5, 0.8)}
            ]
        )

        # Domination structures
        resource_types = ["office_space", "funding", "mentorship", "equipment", "networks"]
        resource_allocation = {
            rt: {
                "availability": np.random.uniform(0.4, 0.9),
                "allocation_mechanism": random.choice(["merit_based", "equity_based", "first_come_first_serve", "needs_based"])
            } for rt in resource_types
        }

        power_hierarchies = [
            {"level": "director", "authority": "strategic_decisions", "power_score": 1.0},
            {"level": "program_manager", "authority": "operational_decisions", "power_score": 0.7},
            {"level": "mentors", "authority": "advisory", "power_score": 0.5},
            {"level": "entrepreneurs", "authority": "venture_decisions", "power_score": 0.6}
        ]

        decision_authorities = {
            "admission": "selection_committee",
            "funding_allocation": "director",
            "resource_access": "program_manager",
            "graduation_criteria": "board",
            "policy_changes": "director_and_board"
        }

        domination = DominationStructure(
            resource_allocation=resource_allocation,
            power_hierarchies=power_hierarchies,
            decision_making_authority=decision_authorities,
            resource_control_points=["funding_committee", "space_allocation_office", "mentor_network"]
        )

        # Legitimation structures
        institutional_norms = [
            "Innovation and disruption are valued",
            "Evidence-based decision making is expected",
            "Ethical business practices are mandatory",
            "Social responsibility is encouraged",
            "Continuous learning is promoted",
            "Collaboration over competition"
        ]

        evaluation_criteria = [
            "Revenue growth and profitability potential",
            "Market traction and customer validation",
            "Team capability and execution",
            "Innovation and IP potential",
            "Social impact and sustainability",
            "Scalability of business model"
        ]

        sanctions_rewards = {
            "rewards": ["additional_funding", "extended_residency", "showcase_opportunities", "media_coverage"],
            "sanctions": ["reduced_resources", "mandatory_improvement_plan", "early_exit"],
            "evaluation_frequency": "quarterly"
        }

        legitimation = LegitimationStructure(
            institutional_norms=random.sample(institutional_norms, k=random.randint(4, 6)),
            evaluation_criteria=evaluation_criteria,
            sanctions_rewards=sanctions_rewards,
            moral_frameworks=["stakeholder_value", "social_good", "innovation_imperative"]
        )

        # Agency manifestations
        agency = AgencyManifestation(
            rule_interpretations=[
                {"rule": "weekly_checkins", "interpretation": "flexible_timing", "frequency": 0.3},
                {"rule": "onsite_presence", "interpretation": "hybrid_allowed", "frequency": 0.5}
            ],
            resource_mobilizations=[
                {"resource": "mentorship", "strategy": "network_building", "success": 0.7},
                {"resource": "funding", "strategy": "milestone_demonstration", "success": 0.6}
            ],
            norm_challenges=[
                {"norm": "equity_stake", "challenge_type": "negotiation", "outcome": "partial_success"}
            ],
            creative_adaptations=[
                {"adaptation": "peer_learning_groups", "adoption": 0.8},
                {"adaptation": "resource_pooling", "adoption": 0.6}
            ]
        )

        # Structuration dynamics
        dynamics = StructurationDynamics(
            reproduction_events=[
                {"event": "policy_enforcement", "frequency": "weekly", "reinforcement": 0.8},
                {"event": "ritual_meetings", "frequency": "monthly", "reinforcement": 0.9}
            ],
            transformation_events=[
                {"event": "policy_revision", "trigger": "entrepreneur_feedback", "impact": 0.6},
                {"event": "resource_reallocation", "trigger": "performance_data", "impact": 0.7}
            ],
            temporal_evolution=[
                {"period": "early", "structural_change": 0.3},
                {"period": "current", "structural_change": 0.15}
            ]
        )

        # Calculate meta-scores
        structural_rigidity = np.random.beta(5, 5)  # Centered around 0.5
        agency_space = 1.0 - (structural_rigidity * 0.6)  # Inverse relationship with some independence

        return StructurationContext(
            incubator_id=incubator_id,
            timestamp=timestamp,
            signification=signification,
            domination=domination,
            legitimation=legitimation,
            agency_manifestations=agency,
            structuration_dynamics=dynamics,
            structural_rigidity=structural_rigidity,
            agency_space=agency_space
        )

    def generate_entrepreneur_profile(
        self,
        entrepreneur_id: str,
        incubator_id: str,
        timestamp: Optional[datetime] = None
    ) -> EntrepreneurProfile:
        """Generate entrepreneur profile with agentic capabilities"""

        if timestamp is None:
            timestamp = datetime.now()

        entrepreneur_name = self._generate_person_name()
        venture_name = self._generate_venture_name()

        # Agentic capabilities - correlated but with variation
        base_capability = np.random.beta(6, 3)  # Skewed towards higher capability

        intentionality = Intentionality(
            goal_clarity=np.clip(base_capability + np.random.normal(0, 0.1), 0, 1),
            strategic_planning=np.clip(base_capability + np.random.normal(0, 0.15), 0, 1),
            commitment_level=np.clip(base_capability + np.random.normal(0, 0.1), 0, 1),
            goal_descriptions=[
                random.choice([
                    "Achieve product-market fit",
                    "Secure Series A funding",
                    "Reach 10K users",
                    "Build MVP",
                    "Generate revenue"
                ])
            ]
        )

        forethought = Forethought(
            future_orientation=np.clip(base_capability + np.random.normal(0, 0.12), 0, 1),
            scenario_planning=np.clip(base_capability + np.random.normal(-0.1, 0.15), 0, 1),
            risk_assessment=np.clip(base_capability + np.random.normal(0, 0.1), 0, 1),
            planning_horizon_months=random.choice([6, 12, 18, 24])
        )

        self_reactiveness = SelfReactiveness(
            adaptability=np.clip(base_capability + np.random.normal(0.05, 0.1), 0, 1),
            course_correction=np.clip(base_capability + np.random.normal(0, 0.15), 0, 1),
            resource_seeking=np.clip(base_capability + np.random.normal(0.1, 0.1), 0, 1),
            pivot_count=int(np.random.poisson(1))
        )

        self_reflectiveness = SelfReflectiveness(
            metacognition=np.clip(base_capability + np.random.normal(0, 0.12), 0, 1),
            learning_orientation=np.clip(base_capability + np.random.normal(0.05, 0.1), 0, 1),
            feedback_integration=np.clip(base_capability + np.random.normal(0, 0.15), 0, 1),
            reflection_frequency=random.choice(["daily", "weekly", "monthly"])
        )

        agentic_capabilities = AgenticCapabilities(
            intentionality=intentionality,
            forethought=forethought,
            self_reactiveness=self_reactiveness,
            self_reflectiveness=self_reflectiveness
        )

        # Embedded constraints
        constraint_pool = {
            "institutional": ["university_IP_policy", "incubator_equity_requirements", "reporting_obligations"],
            "resource": ["limited_funding", "space_constraints", "mentor_availability", "technical_resources"],
            "network": ["limited_industry_connections", "market_access_barriers", "talent_acquisition"]
        }

        embedded_constraints = EmbeddedConstraints(
            institutional_pressures=random.sample(constraint_pool["institutional"], k=random.randint(1, 3)),
            resource_limitations=random.sample(constraint_pool["resource"], k=random.randint(2, 4)),
            network_dependencies=random.sample(constraint_pool["network"], k=random.randint(1, 3)),
            constraint_severity={
                "institutional": np.random.uniform(0.3, 0.7),
                "resource": np.random.uniform(0.4, 0.8),
                "network": np.random.uniform(0.3, 0.6)
            }
        )

        # Agency-structure interactions
        interactions = AgencyStructureInteraction(
            constraint_negotiations=[
                {
                    "constraint": random.choice(["equity_requirements", "residency_duration"]),
                    "strategy": random.choice(["direct_negotiation", "alternative_proposal", "leveraging_performance"]),
                    "outcome": random.choice(["successful", "partially_successful", "unsuccessful"])
                }
            ],
            opportunity_creations=[
                {
                    "opportunity": random.choice(["new_partnership", "funding_source", "market_entry"]),
                    "mechanism": random.choice(["network_leverage", "resource_recombination", "rule_interpretation"]),
                    "value": np.random.uniform(0.3, 0.9)
                }
            ],
            structure_transformations=[
                {
                    "transformation": random.choice(["policy_change", "resource_reallocation", "norm_shift"]),
                    "agency_role": random.choice(["initiator", "contributor", "beneficiary"]),
                    "impact": np.random.uniform(0.1, 0.5)
                }
            ]
        )

        # Venture stage and success indicators
        venture_stage = random.choice(["ideation", "validation", "early_traction", "growth", "scaling"])
        success_indicators = {
            "revenue": np.random.lognormal(8, 2),
            "users": int(np.random.lognormal(6, 3)),
            "funding_raised": np.random.lognormal(10, 2),
            "team_size": int(np.random.poisson(5)),
            "product_ready": random.choice([True, False])
        }

        return EntrepreneurProfile(
            entrepreneur_id=entrepreneur_id,
            incubator_id=incubator_id,
            timestamp=timestamp,
            entrepreneur_name=entrepreneur_name,
            venture_name=venture_name,
            agentic_capabilities=agentic_capabilities,
            embedded_constraints=embedded_constraints,
            agency_structure_interactions=interactions,
            venture_stage=venture_stage,
            success_indicators=success_indicators
        )

    def _generate_person_name(self) -> str:
        """Generate a random person name"""
        first_names = ["Alex", "Jordan", "Taylor", "Morgan", "Casey", "Riley", "Sam", "Avery"]
        last_names = ["Smith", "Johnson", "Chen", "Patel", "Garcia", "Martinez", "Lee", "Williams"]
        return f"{random.choice(first_names)} {random.choice(last_names)}"

    def _generate_venture_name(self) -> str:
        """Generate a realistic venture name"""
        prefixes = ["Tech", "Smart", "Cloud", "Data", "AI", "Eco", "Bio", "Quantum"]
        suffixes = ["Labs", "Systems", "Solutions", "Works", "Tech", "AI", "Hub", "Ventures"]
        return f"{random.choice(prefixes)}{random.choice(suffixes)}"


def generate_incubator_data(
    num_incubators: int,
    time_periods: int,
    start_date: Optional[datetime] = None,
    seed: Optional[int] = None
) -> pd.DataFrame:
    """
    Convenience function to generate incubator data

    Args:
        num_incubators: Number of incubators
        time_periods: Number of time periods (quarters)
        start_date: Starting date
        seed: Random seed for reproducibility

    Returns:
        DataFrame with incubator metrics
    """
    generator = IncubatorDataGenerator(seed=seed)
    return generator.generate_incubator_data(num_incubators, time_periods, start_date)


def generate_structuration_contexts(
    incubator_ids: List[str],
    timestamp: Optional[datetime] = None,
    seed: Optional[int] = None
) -> List[StructurationContext]:
    """
    Generate structuration contexts for multiple incubators

    Args:
        incubator_ids: List of incubator IDs
        timestamp: Timestamp for contexts
        seed: Random seed

    Returns:
        List of StructurationContext objects
    """
    generator = IncubatorDataGenerator(seed=seed)
    return [
        generator.generate_structuration_context(inc_id, timestamp)
        for inc_id in incubator_ids
    ]


def generate_entrepreneur_profiles(
    num_entrepreneurs: int,
    incubator_ids: List[str],
    timestamp: Optional[datetime] = None,
    seed: Optional[int] = None
) -> List[EntrepreneurProfile]:
    """
    Generate entrepreneur profiles distributed across incubators

    Args:
        num_entrepreneurs: Number of entrepreneur profiles to generate
        incubator_ids: List of available incubator IDs
        timestamp: Timestamp for profiles
        seed: Random seed

    Returns:
        List of EntrepreneurProfile objects
    """
    generator = IncubatorDataGenerator(seed=seed)
    profiles = []

    for i in range(num_entrepreneurs):
        entrepreneur_id = f"ENT_{i + 1:04d}"
        incubator_id = random.choice(incubator_ids)
        profile = generator.generate_entrepreneur_profile(
            entrepreneur_id, incubator_id, timestamp
        )
        profiles.append(profile)

    return profiles
