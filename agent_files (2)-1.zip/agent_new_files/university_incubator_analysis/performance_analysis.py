"""
Performance analysis module for business incubators

Analyzes KPIs and generates performance reports using various analytical methods.
"""

import pandas as pd
import numpy as np
from typing import Dict, Any, List, Optional
from datetime import datetime
from scipy import stats


class PerformanceAnalyzer:
    """Analyzes incubator performance metrics"""

    def __init__(self):
        """Initialize the performance analyzer"""
        pass

    def analyze_performance(
        self,
        data: pd.DataFrame,
        benchmark_data: Optional[pd.DataFrame] = None
    ) -> Dict[str, Any]:
        """
        Comprehensive performance analysis

        Args:
            data: DataFrame with incubator metrics
            benchmark_data: Optional benchmark data for comparison

        Returns:
            Dictionary with analysis results
        """
        analysis = {
            'summary_statistics': self._calculate_summary_stats(data),
            'kpi_analysis': self._analyze_kpis(data),
            'trend_analysis': self._analyze_trends(data),
            'efficiency_analysis': self._analyze_efficiency(data),
            'comparative_analysis': self._comparative_analysis(data),
            'performance_rankings': self._rank_incubators(data),
            'insights': self._generate_insights(data),
            'timestamp': datetime.now().isoformat()
        }

        if benchmark_data is not None:
            analysis['benchmark_comparison'] = self._benchmark_comparison(data, benchmark_data)

        return analysis

    def _calculate_summary_stats(self, data: pd.DataFrame) -> Dict[str, Any]:
        """Calculate summary statistics for key metrics"""

        numeric_cols = [
            'occupancy_rate', 'graduation_rate', 'survival_rate',
            'jobs_created', 'total_revenue_generated', 'total_funding_raised',
            'startups_admitted', 'startups_graduated', 'current_occupants'
        ]

        summary = {}
        for col in numeric_cols:
            if col in data.columns:
                summary[col] = {
                    'mean': float(data[col].mean()),
                    'median': float(data[col].median()),
                    'std': float(data[col].std()),
                    'min': float(data[col].min()),
                    'max': float(data[col].max()),
                    'q25': float(data[col].quantile(0.25)),
                    'q75': float(data[col].quantile(0.75))
                }

        return summary

    def _analyze_kpis(self, data: pd.DataFrame) -> Dict[str, Any]:
        """Detailed KPI analysis"""

        kpis = {}

        # Occupancy metrics
        kpis['occupancy'] = {
            'average_rate': float(data['occupancy_rate'].mean()),
            'variance': float(data['occupancy_rate'].var()),
            'incubators_above_80': int((data['occupancy_rate'] > 0.8).sum()),
            'incubators_below_50': int((data['occupancy_rate'] < 0.5).sum())
        }

        # Graduation and survival metrics
        kpis['success_metrics'] = {
            'average_graduation_rate': float(data['graduation_rate'].mean()),
            'average_survival_rate': float(data['survival_rate'].mean()),
            'high_performers': int((data['graduation_rate'] > 0.7).sum()),
            'struggling': int((data['survival_rate'] < 0.5).sum())
        }

        # Economic impact
        total_jobs = data['jobs_created'].sum()
        total_revenue = data['total_revenue_generated'].sum()
        total_funding = data['total_funding_raised'].sum()

        kpis['economic_impact'] = {
            'total_jobs_created': int(total_jobs),
            'total_revenue_generated': float(total_revenue),
            'total_funding_raised': float(total_funding),
            'avg_revenue_per_incubator': float(total_revenue / len(data)),
            'avg_jobs_per_incubator': float(total_jobs / len(data))
        }

        # Startup flow metrics
        total_admitted = data['startups_admitted'].sum()
        total_graduated = data['startups_graduated'].sum()

        kpis['startup_flow'] = {
            'total_startups_admitted': int(total_admitted),
            'total_startups_graduated': int(total_graduated),
            'overall_graduation_rate': float(total_graduated / max(1, total_admitted)),
            'avg_admissions_per_period': float(data['startups_admitted'].mean())
        }

        return kpis

    def _analyze_trends(self, data: pd.DataFrame) -> Dict[str, Any]:
        """Analyze temporal trends in performance"""

        if 'period' not in data.columns:
            return {'error': 'No temporal data available'}

        # Convert period to datetime if string
        if data['period'].dtype == 'object':
            data = data.copy()
            data['period'] = pd.to_datetime(data['period'])

        # Sort by period
        data = data.sort_values('period')

        trends = {}

        # Analyze trends for key metrics
        metrics_to_analyze = [
            'occupancy_rate', 'graduation_rate', 'survival_rate',
            'jobs_created', 'total_revenue_generated'
        ]

        for metric in metrics_to_analyze:
            if metric in data.columns:
                # Group by period and calculate mean
                temporal = data.groupby('period')[metric].mean().reset_index()

                # Calculate trend (linear regression)
                x = np.arange(len(temporal))
                y = temporal[metric].values

                if len(x) > 1:
                    slope, intercept, r_value, p_value, std_err = stats.linregress(x, y)

                    trend_direction = 'increasing' if slope > 0 else 'decreasing'
                    trend_strength = abs(r_value)

                    trends[metric] = {
                        'direction': trend_direction,
                        'slope': float(slope),
                        'r_squared': float(r_value ** 2),
                        'p_value': float(p_value),
                        'strength': 'strong' if trend_strength > 0.7 else 'moderate' if trend_strength > 0.4 else 'weak',
                        'statistically_significant': p_value < 0.05
                    }

        return trends

    def _analyze_efficiency(self, data: pd.DataFrame) -> Dict[str, Any]:
        """Analyze input-output efficiency"""

        efficiency = {}

        # Need to parse nested input/output metrics
        # For simplicity, calculating based on available data

        # Revenue per staff (if data available)
        if 'total_revenue_generated' in data.columns and 'input_metrics' in data.columns:
            # Would need to parse input_metrics from dict format
            pass

        # Simple efficiency metrics from available data
        efficiency['startups_per_capacity'] = {
            'metric': 'startups_admitted / total_capacity',
            'average': float((data['startups_admitted'] / data['total_capacity']).mean()),
            'best_performer': float((data['startups_admitted'] / data['total_capacity']).max())
        }

        efficiency['graduation_efficiency'] = {
            'metric': 'startups_graduated / current_occupants',
            'average': float((data['startups_graduated'] / data['current_occupants'].replace(0, 1)).mean()),
            'best_performer': float((data['startups_graduated'] / data['current_occupants'].replace(0, 1)).max())
        }

        # Revenue per occupant
        efficiency['revenue_per_occupant'] = {
            'metric': 'total_revenue_generated / current_occupants',
            'average': float((data['total_revenue_generated'] / data['current_occupants'].replace(0, 1)).mean()),
            'median': float((data['total_revenue_generated'] / data['current_occupants'].replace(0, 1)).median())
        }

        return efficiency

    def _comparative_analysis(self, data: pd.DataFrame) -> Dict[str, Any]:
        """Compare performance across incubators"""

        if 'incubator_id' not in data.columns:
            return {'error': 'No incubator_id column for comparison'}

        comparison = {}

        # Group by incubator
        incubator_groups = data.groupby('incubator_id')

        # Calculate aggregate metrics per incubator
        incubator_metrics = incubator_groups.agg({
            'occupancy_rate': 'mean',
            'graduation_rate': 'mean',
            'survival_rate': 'mean',
            'jobs_created': 'sum',
            'total_revenue_generated': 'sum',
            'total_funding_raised': 'sum',
            'startups_admitted': 'sum',
            'startups_graduated': 'sum'
        }).round(4)

        # Convert to dict format
        comparison['by_incubator'] = incubator_metrics.to_dict('index')

        # Identify top performers
        comparison['top_performers'] = {
            'by_graduation_rate': incubator_metrics.nlargest(5, 'graduation_rate')['graduation_rate'].to_dict(),
            'by_revenue': incubator_metrics.nlargest(5, 'total_revenue_generated')['total_revenue_generated'].to_dict(),
            'by_jobs_created': incubator_metrics.nlargest(5, 'jobs_created')['jobs_created'].to_dict()
        }

        # Variance analysis
        comparison['variance'] = {
            'occupancy_rate_cv': float(incubator_metrics['occupancy_rate'].std() / incubator_metrics['occupancy_rate'].mean()),
            'graduation_rate_cv': float(incubator_metrics['graduation_rate'].std() / incubator_metrics['graduation_rate'].mean())
        }

        return comparison

    def _rank_incubators(self, data: pd.DataFrame) -> Dict[str, Any]:
        """Rank incubators using composite scoring"""

        if 'incubator_id' not in data.columns:
            return {'error': 'No incubator_id column for ranking'}

        # Aggregate by incubator
        incubator_agg = data.groupby('incubator_id').agg({
            'occupancy_rate': 'mean',
            'graduation_rate': 'mean',
            'survival_rate': 'mean',
            'jobs_created': 'sum',
            'total_revenue_generated': 'sum',
            'total_funding_raised': 'sum'
        })

        # Normalize metrics to 0-1 scale
        normalized = incubator_agg.copy()
        for col in normalized.columns:
            min_val = normalized[col].min()
            max_val = normalized[col].max()
            if max_val > min_val:
                normalized[col] = (normalized[col] - min_val) / (max_val - min_val)
            else:
                normalized[col] = 0.5

        # Weighted composite score
        weights = {
            'occupancy_rate': 0.15,
            'graduation_rate': 0.25,
            'survival_rate': 0.20,
            'jobs_created': 0.15,
            'total_revenue_generated': 0.15,
            'total_funding_raised': 0.10
        }

        normalized['composite_score'] = sum(
            normalized[metric] * weight
            for metric, weight in weights.items()
        )

        # Rank
        normalized['rank'] = normalized['composite_score'].rank(ascending=False)

        rankings = normalized.sort_values('rank')[['composite_score', 'rank']].to_dict('index')

        return {
            'rankings': rankings,
            'weights_used': weights,
            'top_5': list(normalized.nlargest(5, 'composite_score').index)
        }

    def _generate_insights(self, data: pd.DataFrame) -> List[str]:
        """Generate actionable insights from the data"""

        insights = []

        # Occupancy insights
        avg_occupancy = data['occupancy_rate'].mean()
        if avg_occupancy < 0.6:
            insights.append(f"Low average occupancy rate ({avg_occupancy:.1%}). Consider marketing efforts or admission criteria review.")
        elif avg_occupancy > 0.9:
            insights.append(f"Very high occupancy rate ({avg_occupancy:.1%}). Consider capacity expansion.")

        # Graduation rate insights
        avg_graduation = data['graduation_rate'].mean()
        if avg_graduation < 0.3:
            insights.append(f"Low graduation rate ({avg_graduation:.1%}). Review support services and mentorship programs.")
        elif avg_graduation > 0.7:
            insights.append(f"Strong graduation rate ({avg_graduation:.1%}). Current programs are effective.")

        # Survival rate insights
        avg_survival = data['survival_rate'].mean()
        if avg_survival < 0.5:
            insights.append(f"Concerning survival rate ({avg_survival:.1%}). Consider strengthening early-stage support.")

        # Economic impact insights
        total_jobs = data['jobs_created'].sum()
        total_revenue = data['total_revenue_generated'].sum()
        insights.append(f"Total economic impact: {total_jobs} jobs created and ${total_revenue:,.0f} in revenue generated.")

        # Variability insights
        occupancy_std = data['occupancy_rate'].std()
        if occupancy_std > 0.25:
            insights.append("High variability in occupancy rates across incubators. Consider sharing best practices.")

        return insights

    def _benchmark_comparison(self, data: pd.DataFrame, benchmark: pd.DataFrame) -> Dict[str, Any]:
        """Compare against benchmark data"""

        comparison = {}

        metrics = ['occupancy_rate', 'graduation_rate', 'survival_rate']

        for metric in metrics:
            if metric in data.columns and metric in benchmark.columns:
                data_mean = data[metric].mean()
                benchmark_mean = benchmark[metric].mean()
                difference = data_mean - benchmark_mean
                percent_difference = (difference / benchmark_mean) * 100 if benchmark_mean != 0 else 0

                comparison[metric] = {
                    'actual': float(data_mean),
                    'benchmark': float(benchmark_mean),
                    'difference': float(difference),
                    'percent_difference': float(percent_difference),
                    'performance': 'above' if difference > 0 else 'below' if difference < 0 else 'at'
                }

        return comparison


def analyze_performance(
    data: pd.DataFrame,
    benchmark_data: Optional[pd.DataFrame] = None
) -> Dict[str, Any]:
    """
    Convenience function for performance analysis

    Args:
        data: DataFrame with incubator metrics
        benchmark_data: Optional benchmark data

    Returns:
        Analysis results dictionary
    """
    analyzer = PerformanceAnalyzer()
    return analyzer.analyze_performance(data, benchmark_data)
