"""
University Incubator Analysis Tool

A comprehensive MCP tool for analyzing university business incubators from three
theoretical perspectives:
1. Business Incubator Performance Analysis
2. Socio-Structuration Analysis (Giddens' Structuration Theory)
3. Agentic Processes Analysis

Example usage:
    from university_incubator_analysis import (
        generate_incubator_data,
        analyze_performance,
        analyze_structuration,
        analyze_agency,
        generate_comprehensive_report
    )

    # Generate synthetic data
    data = generate_incubator_data(num_incubators=10, time_periods=12)

    # Analyze performance
    performance_results = analyze_performance(data)

    # Generate and analyze structuration contexts
    from university_incubator_analysis.data_generator import (
        IncubatorDataGenerator,
        generate_structuration_contexts,
        generate_entrepreneur_profiles
    )

    generator = IncubatorDataGenerator(seed=42)
    incubator_ids = data['incubator_id'].unique().tolist()

    contexts = generate_structuration_contexts(incubator_ids)
    structuration_results = analyze_structuration(contexts[0])

    # Generate and analyze entrepreneur profiles
    profiles = generate_entrepreneur_profiles(50, incubator_ids)
    agency_results = analyze_agency(profiles, contexts[0])

    # Generate comprehensive report
    report = generate_comprehensive_report(
        data,
        performance_results,
        contexts,
        structuration_results,
        profiles,
        agency_results,
        output_format="json"
    )
"""

from .data_generator import (
    generate_incubator_data,
    generate_structuration_contexts,
    generate_entrepreneur_profiles,
    IncubatorDataGenerator
)

from .performance_analysis import (
    analyze_performance,
    PerformanceAnalyzer
)

from .structuration_analysis import (
    analyze_structuration,
    StructurationAnalyzer
)

from .agency_analysis import (
    analyze_agency,
    AgencyAnalyzer
)

from .reporting import (
    generate_comprehensive_report,
    ReportGenerator
)

from .data_models import (
    IncubatorMetrics,
    InputMetrics,
    OutputMetrics,
    MarketReach,
    IncubatorStage,
    StructurationContext,
    SignificationStructure,
    DominationStructure,
    LegitimationStructure,
    AgencyManifestation,
    StructurationDynamics,
    EntrepreneurProfile,
    AgenticCapabilities,
    Intentionality,
    Forethought,
    SelfReactiveness,
    SelfReflectiveness,
    EmbeddedConstraints,
    AgencyStructureInteraction
)

__version__ = "1.0.0"
__author__ = "University Incubator Analysis Team"

__all__ = [
    # Data generation functions
    'generate_incubator_data',
    'generate_structuration_contexts',
    'generate_entrepreneur_profiles',
    'IncubatorDataGenerator',

    # Analysis functions
    'analyze_performance',
    'analyze_structuration',
    'analyze_agency',

    # Reporting
    'generate_comprehensive_report',

    # Analyzers
    'PerformanceAnalyzer',
    'StructurationAnalyzer',
    'AgencyAnalyzer',
    'ReportGenerator',

    # Data models
    'IncubatorMetrics',
    'InputMetrics',
    'OutputMetrics',
    'MarketReach',
    'IncubatorStage',
    'StructurationContext',
    'SignificationStructure',
    'DominationStructure',
    'LegitimationStructure',
    'AgencyManifestation',
    'StructurationDynamics',
    'EntrepreneurProfile',
    'AgenticCapabilities',
    'Intentionality',
    'Forethought',
    'SelfReactiveness',
    'SelfReflectiveness',
    'EmbeddedConstraints',
    'AgencyStructureInteraction',
]
