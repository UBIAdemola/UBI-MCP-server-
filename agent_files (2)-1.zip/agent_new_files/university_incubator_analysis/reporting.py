"""
Comprehensive reporting module

Generates integrated reports combining performance, structuration, and agency analyses.
"""

import json
from typing import Dict, Any, List, Optional, Union
from datetime import datetime
import pandas as pd
import numpy as np

from .data_models import StructurationContext, EntrepreneurProfile


def convert_numpy_types(obj):
    """Recursively convert numpy types to Python native types for JSON serialization"""
    if isinstance(obj, dict):
        return {key: convert_numpy_types(value) for key, value in obj.items()}
    elif isinstance(obj, list):
        return [convert_numpy_types(item) for item in obj]
    elif isinstance(obj, (np.integer, np.int64, np.int32)):
        return int(obj)
    elif isinstance(obj, (np.floating, np.float64, np.float32)):
        return float(obj)
    elif isinstance(obj, (np.bool_, bool)):
        return bool(obj)
    elif isinstance(obj, np.ndarray):
        return obj.tolist()
    else:
        return obj


class ReportGenerator:
    """Generates comprehensive analysis reports"""

    def __init__(self):
        """Initialize report generator"""
        pass

    def generate_comprehensive_report(
        self,
        performance_data: pd.DataFrame,
        performance_analysis: Dict[str, Any],
        structuration_contexts: Optional[List[StructurationContext]] = None,
        structuration_analysis: Optional[Dict[str, Any]] = None,
        entrepreneur_profiles: Optional[List[EntrepreneurProfile]] = None,
        agency_analysis: Optional[Dict[str, Any]] = None,
        output_format: str = "json"
    ) -> Union[Dict, str]:
        """
        Generate comprehensive integrated report

        Args:
            performance_data: Raw performance data
            performance_analysis: Performance analysis results
            structuration_contexts: Optional structuration contexts
            structuration_analysis: Optional structuration analysis results
            entrepreneur_profiles: Optional entrepreneur profiles
            agency_analysis: Optional agency analysis results
            output_format: Output format (json, html, or markdown)

        Returns:
            Report in specified format
        """

        report = {
            'metadata': self._create_metadata(performance_data),
            'executive_summary': self._create_executive_summary(
                performance_analysis,
                structuration_analysis,
                agency_analysis
            ),
            'performance_section': self._format_performance_section(performance_analysis),
        }

        if structuration_analysis:
            report['structuration_section'] = self._format_structuration_section(structuration_analysis)

        if agency_analysis:
            report['agency_section'] = self._format_agency_section(agency_analysis)

        if performance_analysis and structuration_analysis and agency_analysis:
            report['integrated_analysis'] = self._create_integrated_analysis(
                performance_analysis,
                structuration_analysis,
                agency_analysis
            )

        report['recommendations'] = self._generate_recommendations(
            performance_analysis,
            structuration_analysis,
            agency_analysis
        )

        # Format according to output type
        if output_format == "json":
            # Convert numpy types to Python native types for JSON serialization
            return convert_numpy_types(report)
        elif output_format == "markdown":
            return self._format_as_markdown(report)
        elif output_format == "html":
            return self._format_as_html(report)
        else:
            return convert_numpy_types(report)

    def _create_metadata(self, performance_data: pd.DataFrame) -> Dict[str, Any]:
        """Create report metadata"""
        return {
            'report_generated': datetime.now().isoformat(),
            'report_type': 'University Incubator Comprehensive Analysis',
            'data_points': len(performance_data),
            'incubators_analyzed': performance_data['incubator_id'].nunique() if 'incubator_id' in performance_data.columns else 0,
            'time_periods': performance_data['period'].nunique() if 'period' in performance_data.columns else 0
        }

    def _create_executive_summary(
        self,
        performance: Optional[Dict[str, Any]],
        structuration: Optional[Dict[str, Any]],
        agency: Optional[Dict[str, Any]]
    ) -> Dict[str, Any]:
        """Create executive summary combining all perspectives"""

        summary = {
            'overview': 'Comprehensive analysis of university business incubators from performance, structuration, and agency perspectives.'
        }

        # Performance highlights
        if performance and 'kpi_analysis' in performance:
            kpis = performance['kpi_analysis']
            summary['performance_highlights'] = {
                'average_occupancy': f"{kpis['occupancy']['average_rate']:.1%}" if 'occupancy' in kpis else 'N/A',
                'graduation_rate': f"{kpis['success_metrics']['average_graduation_rate']:.1%}" if 'success_metrics' in kpis else 'N/A',
                'total_jobs_created': kpis['economic_impact']['total_jobs_created'] if 'economic_impact' in kpis else 'N/A',
                'total_revenue': f"${kpis['economic_impact']['total_revenue_generated']:,.0f}" if 'economic_impact' in kpis else 'N/A'
            }

        # Structuration highlights
        if structuration:
            summary['structuration_highlights'] = {
                'structural_rigidity': f"{structuration.get('structural_analysis', {}).get('structural_characteristics', {}).get('rigidity', 0.5):.2f}",
                'agency_space': f"{structuration.get('agency_analysis', {}).get('agency_space_metrics', {}).get('overall_agency_space', 0.5):.2f}",
                'dominant_process': structuration.get('structuration_processes', {}).get('process_balance', {}).get('dominant_process', 'N/A')
            }

        # Agency highlights
        if agency and 'summary' in agency:
            summary['agency_highlights'] = {
                'total_entrepreneurs': agency['summary']['total_entrepreneurs'],
                'average_agency_score': f"{agency['summary']['average_agency_score']:.2f}",
                'most_common_type': self._get_most_common_agency_type(agency)
            }

        # Key insights
        summary['key_insights'] = self._extract_key_insights(performance, structuration, agency)

        return summary

    def _get_most_common_agency_type(self, agency: Dict[str, Any]) -> str:
        """Extract most common agency type"""
        if 'typology' not in agency or 'types' not in agency['typology']:
            return 'N/A'

        types = agency['typology']['types']
        if not types:
            return 'N/A'

        max_type = max(types.items(), key=lambda x: x[1]['count'])
        return max_type[0]

    def _extract_key_insights(
        self,
        performance: Optional[Dict[str, Any]],
        structuration: Optional[Dict[str, Any]],
        agency: Optional[Dict[str, Any]]
    ) -> List[str]:
        """Extract key insights from all analyses"""

        insights = []

        if performance and 'insights' in performance:
            insights.extend(performance['insights'][:2])

        if structuration and 'insights' in structuration:
            insights.extend(structuration['insights'][:2])

        if agency and 'insights' in agency:
            insights.extend(agency['insights'][:2])

        return insights[:5]  # Limit to top 5 insights

    def _format_performance_section(self, analysis: Dict[str, Any]) -> Dict[str, Any]:
        """Format performance analysis for report"""

        section = {
            'title': '1. Business Incubator Performance Analysis',
            'description': 'Quantitative analysis of key performance indicators (KPIs)',
            'summary_statistics': analysis.get('summary_statistics', {}),
            'kpi_analysis': analysis.get('kpi_analysis', {}),
            'trend_analysis': analysis.get('trend_analysis', {}),
            'performance_rankings': analysis.get('performance_rankings', {}),
            'visualizations': self._suggest_performance_visualizations(analysis)
        }

        return section

    def _format_structuration_section(self, analysis: Dict[str, Any]) -> Dict[str, Any]:
        """Format structuration analysis for report"""

        section = {
            'title': '2. Socio-Structuration Analysis',
            'description': 'Analysis based on Giddens\' Structuration Theory examining structure-agency duality',
            'structural_analysis': analysis.get('structural_analysis', {}),
            'agency_analysis': analysis.get('agency_analysis', {}),
            'duality_analysis': analysis.get('duality_analysis', {}),
            'structuration_processes': analysis.get('structuration_processes', {}),
            'visualizations': self._suggest_structuration_visualizations(analysis)
        }

        return section

    def _format_agency_section(self, analysis: Dict[str, Any]) -> Dict[str, Any]:
        """Format agency analysis for report"""

        section = {
            'title': '3. Agentic Processes Analysis',
            'description': 'Analysis of entrepreneurial agency and capability development',
            'capability_analysis': analysis.get('capability_analysis', {}),
            'constraint_analysis': analysis.get('constraint_analysis', {}),
            'agency_typology': analysis.get('typology', {}),
            'success_correlations': analysis.get('success_correlations', {}),
            'visualizations': self._suggest_agency_visualizations(analysis)
        }

        return section

    def _create_integrated_analysis(
        self,
        performance: Dict[str, Any],
        structuration: Dict[str, Any],
        agency: Dict[str, Any]
    ) -> Dict[str, Any]:
        """Create integrated analysis across all three perspectives"""

        integrated = {
            'title': '4. Integrated Cross-Perspective Analysis',
            'description': 'Synthesis of findings across performance, structuration, and agency perspectives'
        }

        # Performance-Structure linkages
        integrated['performance_structure_linkages'] = self._analyze_performance_structure_link(
            performance, structuration
        )

        # Structure-Agency linkages
        integrated['structure_agency_linkages'] = self._analyze_structure_agency_link(
            structuration, agency
        )

        # Agency-Performance linkages
        integrated['agency_performance_linkages'] = self._analyze_agency_performance_link(
            agency, performance
        )

        # Holistic insights
        integrated['holistic_insights'] = self._generate_holistic_insights(
            performance, structuration, agency
        )

        return integrated

    def _analyze_performance_structure_link(
        self,
        performance: Dict[str, Any],
        structuration: Dict[str, Any]
    ) -> Dict[str, Any]:
        """Analyze linkages between performance and structure"""

        linkages = {}

        # Does structural rigidity correlate with performance?
        struct_rigidity = structuration.get('structural_analysis', {}).get('structural_characteristics', {}).get('rigidity', 0.5)
        avg_graduation = performance.get('kpi_analysis', {}).get('success_metrics', {}).get('average_graduation_rate', 0.5)

        linkages['rigidity_performance_relationship'] = {
            'structural_rigidity': struct_rigidity,
            'graduation_rate': avg_graduation,
            'observation': self._interpret_rigidity_performance(struct_rigidity, avg_graduation)
        }

        return linkages

    def _analyze_structure_agency_link(
        self,
        structuration: Dict[str, Any],
        agency: Dict[str, Any]
    ) -> Dict[str, Any]:
        """Analyze linkages between structure and agency"""

        linkages = {}

        # Agency space vs entrepreneur agency
        if 'agency_structure_fit' in agency:
            linkages['fit_analysis'] = agency['agency_structure_fit']
        else:
            struct_agency_space = structuration.get('agency_analysis', {}).get('agency_space_metrics', {}).get('overall_agency_space', 0.5)
            entrepreneur_agency = agency.get('summary', {}).get('average_agency_score', 0.5)

            linkages['agency_alignment'] = {
                'structural_agency_space': struct_agency_space,
                'entrepreneur_agency_level': entrepreneur_agency,
                'alignment': 'good' if abs(struct_agency_space - entrepreneur_agency) < 0.2 else 'mismatch'
            }

        return linkages

    def _analyze_agency_performance_link(
        self,
        agency: Dict[str, Any],
        performance: Dict[str, Any]
    ) -> Dict[str, Any]:
        """Analyze linkages between agency and performance"""

        linkages = {}

        # Agency-performance correlations
        if 'success_correlations' in agency:
            linkages['correlations'] = agency['success_correlations']
            linkages['observation'] = "Higher agency levels may correlate with better performance outcomes."

        return linkages

    def _generate_holistic_insights(
        self,
        performance: Dict[str, Any],
        structuration: Dict[str, Any],
        agency: Dict[str, Any]
    ) -> List[str]:
        """Generate holistic insights across all perspectives"""

        insights = []

        # High-level synthesis
        insights.append("The incubator ecosystem demonstrates complex interactions between structural constraints, entrepreneurial agency, and performance outcomes.")

        # Performance-structure-agency synthesis
        struct_rigidity = structuration.get('structural_analysis', {}).get('structural_characteristics', {}).get('rigidity', 0.5)
        agency_score = agency.get('summary', {}).get('average_agency_score', 0.5)
        graduation_rate = performance.get('kpi_analysis', {}).get('success_metrics', {}).get('average_graduation_rate', 0.5)

        if graduation_rate > 0.6 and agency_score > 0.6:
            insights.append("High performance appears linked to strong entrepreneurial agency, suggesting effective capability development.")

        if struct_rigidity > 0.7 and agency_score < 0.4:
            insights.append("High structural rigidity combined with low agency may be constraining entrepreneurial potential.")

        if struct_rigidity < 0.4 and graduation_rate < 0.5:
            insights.append("Low structural rigidity without corresponding high performance suggests need for better guidance frameworks.")

        return insights

    def _interpret_rigidity_performance(self, rigidity: float, performance: float) -> str:
        """Interpret relationship between rigidity and performance"""

        if rigidity > 0.7 and performance > 0.6:
            return "High structure supports strong performance (structured enablement)"
        elif rigidity < 0.4 and performance > 0.6:
            return "Low structure with strong performance (entrepreneurial autonomy)"
        elif rigidity > 0.7 and performance < 0.4:
            return "High structure constrains performance (over-regulation)"
        else:
            return "Moderate relationship between structure and performance"

    def _generate_recommendations(
        self,
        performance: Optional[Dict[str, Any]],
        structuration: Optional[Dict[str, Any]],
        agency: Optional[Dict[str, Any]]
    ) -> Dict[str, List[str]]:
        """Generate actionable recommendations"""

        recommendations = {
            'performance_recommendations': [],
            'structural_recommendations': [],
            'agency_recommendations': [],
            'strategic_recommendations': []
        }

        # Performance recommendations
        if performance and 'kpi_analysis' in performance:
            kpis = performance['kpi_analysis']
            if kpis.get('occupancy', {}).get('average_rate', 1.0) < 0.6:
                recommendations['performance_recommendations'].append(
                    "Improve occupancy rates through enhanced marketing and streamlined admission processes"
                )
            if kpis.get('success_metrics', {}).get('average_graduation_rate', 1.0) < 0.5:
                recommendations['performance_recommendations'].append(
                    "Strengthen support services to improve graduation rates"
                )

        # Structural recommendations
        if structuration:
            rigidity = structuration.get('structural_analysis', {}).get('structural_characteristics', {}).get('rigidity', 0.5)
            if rigidity > 0.7:
                recommendations['structural_recommendations'].append(
                    "Introduce flexibility mechanisms to reduce structural rigidity"
                )
            elif rigidity < 0.3:
                recommendations['structural_recommendations'].append(
                    "Establish clearer frameworks to provide necessary structure"
                )

        # Agency recommendations
        if agency:
            avg_agency = agency.get('summary', {}).get('average_agency_score', 0.5)
            if avg_agency < 0.5:
                recommendations['agency_recommendations'].append(
                    "Implement capability development programs to strengthen entrepreneurial agency"
                )

        # Strategic recommendations
        recommendations['strategic_recommendations'].append(
            "Foster balanced structure-agency dynamics that enable while not constraining entrepreneurship"
        )
        recommendations['strategic_recommendations'].append(
            "Develop metrics tracking system to continuously monitor all three dimensions"
        )

        return recommendations

    def _suggest_performance_visualizations(self, analysis: Dict[str, Any]) -> List[Dict[str, str]]:
        """Suggest visualizations for performance data"""

        visualizations = [
            {'type': 'time_series', 'title': 'KPI Trends Over Time', 'metrics': ['occupancy_rate', 'graduation_rate']},
            {'type': 'bar_chart', 'title': 'Incubator Performance Rankings', 'data': 'performance_rankings'},
            {'type': 'heatmap', 'title': 'Performance Metrics Correlation', 'data': 'summary_statistics'},
            {'type': 'box_plot', 'title': 'KPI Distribution Across Incubators', 'metrics': ['graduation_rate', 'survival_rate']}
        ]

        return visualizations

    def _suggest_structuration_visualizations(self, analysis: Dict[str, Any]) -> List[Dict[str, str]]:
        """Suggest visualizations for structuration analysis"""

        visualizations = [
            {'type': 'network_diagram', 'title': 'Power Relations and Resource Flows', 'data': 'domination'},
            {'type': 'sankey_diagram', 'title': 'Structuration Processes', 'data': 'structuration_dynamics'},
            {'type': 'radar_chart', 'title': 'Structural Dimensions', 'dimensions': ['signification', 'domination', 'legitimation']},
            {'type': 'gauge_chart', 'title': 'Structural Rigidity vs Agency Space', 'metrics': ['rigidity', 'agency_space']}
        ]

        return visualizations

    def _suggest_agency_visualizations(self, analysis: Dict[str, Any]) -> List[Dict[str, str]]:
        """Suggest visualizations for agency analysis"""

        visualizations = [
            {'type': 'radar_chart', 'title': 'Agentic Capabilities Profile', 'dimensions': ['intentionality', 'forethought', 'self_reactiveness', 'self_reflectiveness']},
            {'type': 'scatter_plot', 'title': 'Agency vs Performance Outcomes', 'data': 'success_correlations'},
            {'type': 'stacked_bar', 'title': 'Constraint Distribution', 'data': 'constraint_analysis'},
            {'type': 'pie_chart', 'title': 'Agency Type Distribution', 'data': 'typology'}
        ]

        return visualizations

    def _format_as_markdown(self, report: Dict[str, Any]) -> str:
        """Format report as markdown"""

        md = ["# University Incubator Comprehensive Analysis Report\n"]

        # Metadata
        md.append("## Report Metadata\n")
        for key, value in report['metadata'].items():
            md.append(f"- **{key.replace('_', ' ').title()}**: {value}")
        md.append("\n")

        # Executive Summary
        md.append("## Executive Summary\n")
        summary = report['executive_summary']
        md.append(f"{summary.get('overview', '')}\n")

        if 'performance_highlights' in summary:
            md.append("### Performance Highlights\n")
            for key, value in summary['performance_highlights'].items():
                md.append(f"- **{key.replace('_', ' ').title()}**: {value}")
            md.append("\n")

        # Performance Section
        if 'performance_section' in report:
            md.append(f"## {report['performance_section']['title']}\n")
            md.append(f"{report['performance_section']['description']}\n\n")

        # Structuration Section
        if 'structuration_section' in report:
            md.append(f"## {report['structuration_section']['title']}\n")
            md.append(f"{report['structuration_section']['description']}\n\n")

        # Agency Section
        if 'agency_section' in report:
            md.append(f"## {report['agency_section']['title']}\n")
            md.append(f"{report['agency_section']['description']}\n\n")

        # Recommendations
        md.append("## Recommendations\n")
        for category, recs in report['recommendations'].items():
            md.append(f"### {category.replace('_', ' ').title()}\n")
            for rec in recs:
                md.append(f"- {rec}")
            md.append("\n")

        return "\n".join(md)

    def _format_as_html(self, report: Dict[str, Any]) -> str:
        """Format report as HTML"""

        html = ["<!DOCTYPE html>", "<html>", "<head>",
                "<title>University Incubator Analysis Report</title>",
                "<style>",
                "body { font-family: Arial, sans-serif; margin: 40px; }",
                "h1 { color: #2c3e50; }",
                "h2 { color: #34495e; border-bottom: 2px solid #3498db; padding-bottom: 10px; }",
                ".metadata { background: #ecf0f1; padding: 15px; border-radius: 5px; }",
                ".highlight { background: #3498db; color: white; padding: 10px; border-radius: 5px; margin: 10px 0; }",
                "</style>",
                "</head>", "<body>"]

        html.append("<h1>University Incubator Comprehensive Analysis Report</h1>")

        # Metadata
        html.append("<div class='metadata'>")
        html.append("<h2>Report Metadata</h2>")
        for key, value in report['metadata'].items():
            html.append(f"<p><strong>{key.replace('_', ' ').title()}:</strong> {value}</p>")
        html.append("</div>")

        # Executive Summary
        html.append("<h2>Executive Summary</h2>")
        summary = report['executive_summary']
        html.append(f"<p>{summary.get('overview', '')}</p>")

        html.append("</body>")
        html.append("</html>")
        return "\n".join(html)


def generate_comprehensive_report(
    performance_data: pd.DataFrame,
    performance_analysis: Dict[str, Any],
    structuration_contexts: Optional[List[StructurationContext]] = None,
    structuration_analysis: Optional[Dict[str, Any]] = None,
    entrepreneur_profiles: Optional[List[EntrepreneurProfile]] = None,
    agency_analysis: Optional[Dict[str, Any]] = None,
    output_format: str = "json"
) -> Union[Dict, str]:
    """
    Convenience function for report generation

    Args:
        performance_data: Raw performance data
        performance_analysis: Performance analysis results
        structuration_contexts: Optional structuration contexts
        structuration_analysis: Optional structuration analysis
        entrepreneur_profiles: Optional entrepreneur profiles
        agency_analysis: Optional agency analysis
        output_format: Output format (json, html, markdown)

    Returns:
        Report in specified format
    """
    generator = ReportGenerator()
    return generator.generate_comprehensive_report(
        performance_data,
        performance_analysis,
        structuration_contexts,
        structuration_analysis,
        entrepreneur_profiles,
        agency_analysis,
        output_format
    )
