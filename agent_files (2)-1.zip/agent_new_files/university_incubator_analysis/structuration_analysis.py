"""
Structuration analysis module based on Giddens' Structuration Theory

Analyzes the duality of structure and agency in business incubator contexts.
"""

from typing import Dict, Any, List, Optional
from datetime import datetime
import numpy as np

from .data_models import StructurationContext


class StructurationAnalyzer:
    """Analyzes structuration processes in incubators"""

    def __init__(self):
        """Initialize the structuration analyzer"""
        pass

    def analyze_structuration(
        self,
        incubator_context: StructurationContext,
        temporal_data: Optional[List[StructurationContext]] = None
    ) -> Dict[str, Any]:
        """
        Comprehensive structuration analysis

        Args:
            incubator_context: Current structuration context
            temporal_data: Optional temporal sequence of contexts

        Returns:
            Dictionary with structuration analysis
        """
        analysis = {
            'incubator_id': incubator_context.incubator_id,
            'timestamp': incubator_context.timestamp.isoformat(),
            'structural_analysis': self._analyze_structure(incubator_context),
            'agency_analysis': self._analyze_agency_space(incubator_context),
            'duality_analysis': self._analyze_duality(incubator_context),
            'structuration_processes': self._analyze_processes(incubator_context),
            'insights': self._generate_structuration_insights(incubator_context)
        }

        if temporal_data and len(temporal_data) > 1:
            analysis['temporal_dynamics'] = self._analyze_temporal_dynamics(temporal_data)

        return analysis

    def _analyze_structure(self, context: StructurationContext) -> Dict[str, Any]:
        """Analyze the three dimensions of structure"""

        structure_analysis = {}

        # Signification analysis
        signification = context.signification
        structure_analysis['signification'] = {
            'formal_rules_count': len(signification.formal_rules),
            'informal_norms_count': len(signification.informal_norms),
            'communication_channels': len(signification.communication_patterns),
            'semantic_complexity': self._calculate_semantic_complexity(signification),
            'interpretive_flexibility': self._calculate_interpretive_flexibility(signification),
            'key_rules': signification.formal_rules[:3],
            'dominant_norms': signification.informal_norms[:3]
        }

        # Domination analysis
        domination = context.domination
        structure_analysis['domination'] = {
            'resource_types': len(domination.resource_allocation),
            'power_hierarchy_levels': len(domination.power_hierarchies),
            'resource_concentration': self._calculate_resource_concentration(domination),
            'power_distribution': self._analyze_power_distribution(domination),
            'decision_authority_centralization': self._calculate_centralization(domination),
            'critical_resources': self._identify_critical_resources(domination)
        }

        # Legitimation analysis
        legitimation = context.legitimation
        structure_analysis['legitimation'] = {
            'institutional_norms_count': len(legitimation.institutional_norms),
            'evaluation_criteria_count': len(legitimation.evaluation_criteria),
            'normative_strength': self._calculate_normative_strength(legitimation),
            'sanction_reward_balance': self._analyze_sanction_reward_balance(legitimation),
            'moral_frameworks': legitimation.moral_frameworks,
            'key_evaluation_criteria': legitimation.evaluation_criteria[:3]
        }

        # Overall structural characteristics
        structure_analysis['structural_characteristics'] = {
            'rigidity': float(context.structural_rigidity),
            'complexity': self._calculate_structural_complexity(context),
            'coherence': self._calculate_structural_coherence(context),
            'stability': self._assess_structural_stability(context)
        }

        return structure_analysis

    def _analyze_agency_space(self, context: StructurationContext) -> Dict[str, Any]:
        """Analyze the space for agency within structures"""

        agency_analysis = {}

        agency_manifestations = context.agency_manifestations

        # Rule interpretation flexibility
        agency_analysis['rule_interpretation'] = {
            'interpretation_instances': len(agency_manifestations.rule_interpretations),
            'flexibility_score': self._calculate_interpretation_flexibility(agency_manifestations),
            'common_interpretations': [
                ri['interpretation'] for ri in agency_manifestations.rule_interpretations[:3]
            ]
        }

        # Resource mobilization
        agency_analysis['resource_mobilization'] = {
            'mobilization_instances': len(agency_manifestations.resource_mobilizations),
            'success_rate': self._calculate_mobilization_success(agency_manifestations),
            'strategies_used': [
                rm['strategy'] for rm in agency_manifestations.resource_mobilizations
            ]
        }

        # Norm challenges
        agency_analysis['norm_challenges'] = {
            'challenge_instances': len(agency_manifestations.norm_challenges),
            'challenge_frequency': 'high' if len(agency_manifestations.norm_challenges) > 3 else 'moderate' if len(agency_manifestations.norm_challenges) > 1 else 'low',
            'outcomes': [nc.get('outcome', 'unknown') for nc in agency_manifestations.norm_challenges]
        }

        # Creative adaptations
        agency_analysis['creative_adaptations'] = {
            'adaptation_instances': len(agency_manifestations.creative_adaptations),
            'adoption_rates': [
                ca.get('adoption', 0) for ca in agency_manifestations.creative_adaptations
            ],
            'innovations': [
                ca['adaptation'] for ca in agency_manifestations.creative_adaptations[:3]
            ]
        }

        # Overall agency space
        agency_analysis['agency_space_metrics'] = {
            'overall_agency_space': float(context.agency_space),
            'constraint_level': 1.0 - context.agency_space,
            'agency_type': self._classify_agency_type(context),
            'entrepreneurial_autonomy': self._assess_entrepreneurial_autonomy(context)
        }

        return agency_analysis

    def _analyze_duality(self, context: StructurationContext) -> Dict[str, Any]:
        """Analyze the duality of structure and agency"""

        duality_analysis = {}

        # Structure enables agency
        duality_analysis['enabling_mechanisms'] = {
            'resource_provision': self._assess_resource_enabling(context),
            'legitimacy_conferral': self._assess_legitimacy_enabling(context),
            'network_access': self._assess_network_enabling(context),
            'knowledge_provision': self._assess_knowledge_enabling(context)
        }

        # Structure constrains agency
        duality_analysis['constraining_mechanisms'] = {
            'rule_restrictions': self._assess_rule_constraints(context),
            'resource_limitations': self._assess_resource_constraints(context),
            'normative_pressures': self._assess_normative_constraints(context),
            'power_asymmetries': self._assess_power_constraints(context)
        }

        # Net effect
        enabling_score = np.mean(list(duality_analysis['enabling_mechanisms'].values()))
        constraining_score = np.mean(list(duality_analysis['constraining_mechanisms'].values()))

        duality_analysis['net_effect'] = {
            'enabling_score': float(enabling_score),
            'constraining_score': float(constraining_score),
            'net_score': float(enabling_score - constraining_score),
            'dominant_effect': 'enabling' if enabling_score > constraining_score else 'constraining',
            'balance': 'balanced' if abs(enabling_score - constraining_score) < 0.2 else 'unbalanced'
        }

        # Recursiveness - how agency reproduces/transforms structure
        duality_analysis['recursiveness'] = {
            'reproduction_strength': self._assess_reproduction_strength(context),
            'transformation_potential': self._assess_transformation_potential(context),
            'feedback_loops': self._identify_feedback_loops(context)
        }

        return duality_analysis

    def _analyze_processes(self, context: StructurationContext) -> Dict[str, Any]:
        """Analyze structuration processes"""

        processes = {}

        dynamics = context.structuration_dynamics

        # Reproduction processes
        processes['reproduction'] = {
            'event_count': len(dynamics.reproduction_events),
            'frequency_distribution': self._analyze_reproduction_frequency(dynamics),
            'reinforcement_strength': self._calculate_reinforcement_strength(dynamics),
            'stability_mechanisms': [
                re['event'] for re in dynamics.reproduction_events[:3]
            ]
        }

        # Transformation processes
        processes['transformation'] = {
            'event_count': len(dynamics.transformation_events),
            'transformation_triggers': self._analyze_transformation_triggers(dynamics),
            'impact_levels': [
                te.get('impact', 0) for te in dynamics.transformation_events
            ],
            'change_mechanisms': [
                te['event'] for te in dynamics.transformation_events[:3]
            ]
        }

        # Process balance
        reproduction_count = len(dynamics.reproduction_events)
        transformation_count = len(dynamics.transformation_events)
        total = reproduction_count + transformation_count

        processes['process_balance'] = {
            'reproduction_proportion': reproduction_count / max(1, total),
            'transformation_proportion': transformation_count / max(1, total),
            'dominant_process': 'reproduction' if reproduction_count > transformation_count else 'transformation',
            'stability_vs_change': 'stable' if reproduction_count > transformation_count * 2 else 'changing' if transformation_count > reproduction_count else 'balanced'
        }

        return processes

    def _analyze_temporal_dynamics(self, temporal_data: List[StructurationContext]) -> Dict[str, Any]:
        """Analyze how structuration evolves over time"""

        temporal_analysis = {}

        # Sort by timestamp
        sorted_data = sorted(temporal_data, key=lambda x: x.timestamp)

        # Track structural changes
        rigidity_trajectory = [ctx.structural_rigidity for ctx in sorted_data]
        agency_space_trajectory = [ctx.agency_space for ctx in sorted_data]

        temporal_analysis['trajectories'] = {
            'structural_rigidity': {
                'values': rigidity_trajectory,
                'trend': 'increasing' if rigidity_trajectory[-1] > rigidity_trajectory[0] else 'decreasing',
                'volatility': float(np.std(rigidity_trajectory))
            },
            'agency_space': {
                'values': agency_space_trajectory,
                'trend': 'expanding' if agency_space_trajectory[-1] > agency_space_trajectory[0] else 'contracting',
                'volatility': float(np.std(agency_space_trajectory))
            }
        }

        # Identify critical junctures
        temporal_analysis['critical_junctures'] = self._identify_critical_junctures(sorted_data)

        # Path dependency analysis
        temporal_analysis['path_dependency'] = self._analyze_path_dependency(sorted_data)

        return temporal_analysis

    def _generate_structuration_insights(self, context: StructurationContext) -> List[str]:
        """Generate insights about structuration"""

        insights = []

        # Structural rigidity insights
        if context.structural_rigidity > 0.7:
            insights.append("High structural rigidity may constrain entrepreneurial innovation. Consider introducing flexibility mechanisms.")
        elif context.structural_rigidity < 0.3:
            insights.append("Low structural rigidity provides flexibility but may lack necessary guidance. Consider establishing clearer frameworks.")
        else:
            insights.append(f"Moderate structural rigidity ({context.structural_rigidity:.2f}) provides balance between guidance and flexibility.")

        # Agency space insights
        if context.agency_space > 0.7:
            insights.append("High agency space enables entrepreneurial autonomy and innovation.")
        elif context.agency_space < 0.3:
            insights.append("Limited agency space may restrict entrepreneurial action. Review constraining structures.")
        else:
            insights.append(f"Moderate agency space ({context.agency_space:.2f}) allows for entrepreneurial initiative within structural boundaries.")

        # Balance insights
        if abs(context.structural_rigidity - (1.0 - context.agency_space)) < 0.2:
            insights.append("Good balance between structure and agency supports productive entrepreneurship.")

        # Manifestation insights
        if len(context.agency_manifestations.creative_adaptations) > 3:
            insights.append("High creative adaptation suggests active entrepreneurial agency and learning.")

        # Transformation insights
        if len(context.structuration_dynamics.transformation_events) > len(context.structuration_dynamics.reproduction_events):
            insights.append("Active structural transformation indicates a dynamic, evolving incubator environment.")

        return insights

    # Helper methods for calculations

    def _calculate_semantic_complexity(self, signification) -> float:
        """Calculate complexity of meaning structures"""
        total_elements = len(signification.formal_rules) + len(signification.informal_norms)
        return min(1.0, total_elements / 20.0)

    def _calculate_interpretive_flexibility(self, signification) -> float:
        """Calculate flexibility in rule interpretation"""
        if not signification.interpretive_schemas:
            return 0.5
        return float(np.mean([s.get('prevalence', 0.5) for s in signification.interpretive_schemas]))

    def _calculate_resource_concentration(self, domination) -> float:
        """Calculate concentration of resource control"""
        if not domination.resource_allocation:
            return 0.5
        availabilities = [r.get('availability', 0.5) for r in domination.resource_allocation.values()]
        return 1.0 - float(np.mean(availabilities))

    def _analyze_power_distribution(self, domination) -> Dict[str, float]:
        """Analyze distribution of power"""
        power_scores = {h['level']: h['power_score'] for h in domination.power_hierarchies}
        return power_scores

    def _calculate_centralization(self, domination) -> float:
        """Calculate centralization of decision-making"""
        if not domination.power_hierarchies:
            return 0.5
        power_scores = [h['power_score'] for h in domination.power_hierarchies]
        return float(np.std(power_scores))

    def _identify_critical_resources(self, domination) -> List[str]:
        """Identify most critical resources"""
        return domination.resource_control_points[:3]

    def _calculate_normative_strength(self, legitimation) -> float:
        """Calculate strength of normative order"""
        return min(1.0, len(legitimation.institutional_norms) / 10.0)

    def _analyze_sanction_reward_balance(self, legitimation) -> Dict[str, int]:
        """Analyze balance of sanctions vs rewards"""
        sanctions = legitimation.sanctions_rewards.get('sanctions', [])
        rewards = legitimation.sanctions_rewards.get('rewards', [])
        return {
            'sanctions_count': len(sanctions) if isinstance(sanctions, list) else 0,
            'rewards_count': len(rewards) if isinstance(rewards, list) else 0
        }

    def _calculate_structural_complexity(self, context: StructurationContext) -> float:
        """Calculate overall structural complexity"""
        elements = (
            len(context.signification.formal_rules) +
            len(context.domination.resource_allocation) +
            len(context.legitimation.institutional_norms)
        )
        return min(1.0, elements / 30.0)

    def _calculate_structural_coherence(self, context: StructurationContext) -> float:
        """Estimate structural coherence"""
        # Simplified: inverse of rigidity variation
        return 0.7 + np.random.uniform(-0.2, 0.2)

    def _assess_structural_stability(self, context: StructurationContext) -> float:
        """Assess structural stability"""
        reproduction_events = len(context.structuration_dynamics.reproduction_events)
        transformation_events = len(context.structuration_dynamics.transformation_events)
        total = reproduction_events + transformation_events
        return reproduction_events / max(1, total)

    def _calculate_interpretation_flexibility(self, agency) -> float:
        """Calculate flexibility in rule interpretation"""
        if not agency.rule_interpretations:
            return 0.5
        return float(np.mean([ri.get('frequency', 0.5) for ri in agency.rule_interpretations]))

    def _calculate_mobilization_success(self, agency) -> float:
        """Calculate success rate of resource mobilization"""
        if not agency.resource_mobilizations:
            return 0.5
        return float(np.mean([rm.get('success', 0.5) for rm in agency.resource_mobilizations]))

    def _classify_agency_type(self, context: StructurationContext) -> str:
        """Classify type of agency"""
        if context.agency_space > 0.7:
            return "high_autonomy"
        elif context.agency_space > 0.4:
            return "moderate_autonomy"
        else:
            return "constrained"

    def _assess_entrepreneurial_autonomy(self, context: StructurationContext) -> float:
        """Assess entrepreneurial autonomy"""
        return float(context.agency_space)

    def _assess_resource_enabling(self, context: StructurationContext) -> float:
        """Assess how resources enable action"""
        availabilities = [r.get('availability', 0.5) for r in context.domination.resource_allocation.values()]
        return float(np.mean(availabilities)) if availabilities else 0.5

    def _assess_legitimacy_enabling(self, context: StructurationContext) -> float:
        """Assess legitimacy conferral"""
        return 0.7  # Simplified

    def _assess_network_enabling(self, context: StructurationContext) -> float:
        """Assess network access enabling"""
        return 0.6  # Simplified

    def _assess_knowledge_enabling(self, context: StructurationContext) -> float:
        """Assess knowledge provision"""
        return 0.65  # Simplified

    def _assess_rule_constraints(self, context: StructurationContext) -> float:
        """Assess rule-based constraints"""
        return len(context.signification.formal_rules) / 10.0

    def _assess_resource_constraints(self, context: StructurationContext) -> float:
        """Assess resource constraints"""
        return 1.0 - self._assess_resource_enabling(context)

    def _assess_normative_constraints(self, context: StructurationContext) -> float:
        """Assess normative pressures"""
        return min(1.0, len(context.legitimation.institutional_norms) / 8.0)

    def _assess_power_constraints(self, context: StructurationContext) -> float:
        """Assess power asymmetry constraints"""
        return float(context.structural_rigidity * 0.8)

    def _assess_reproduction_strength(self, context: StructurationContext) -> float:
        """Assess strength of structural reproduction"""
        reproduction_events = len(context.structuration_dynamics.reproduction_events)
        return min(1.0, reproduction_events / 5.0)

    def _assess_transformation_potential(self, context: StructurationContext) -> float:
        """Assess potential for structural transformation"""
        transformation_events = len(context.structuration_dynamics.transformation_events)
        return min(1.0, transformation_events / 3.0)

    def _identify_feedback_loops(self, context: StructurationContext) -> List[str]:
        """Identify key feedback loops"""
        return [
            "rule_interpretation_learning",
            "resource_mobilization_success",
            "norm_adaptation_cycles"
        ]

    def _analyze_reproduction_frequency(self, dynamics) -> Dict[str, int]:
        """Analyze frequency of reproduction events"""
        frequencies = {}
        for event in dynamics.reproduction_events:
            freq = event.get('frequency', 'unknown')
            frequencies[freq] = frequencies.get(freq, 0) + 1
        return frequencies

    def _calculate_reinforcement_strength(self, dynamics) -> float:
        """Calculate average reinforcement strength"""
        if not dynamics.reproduction_events:
            return 0.5
        reinforcements = [re.get('reinforcement', 0.5) for re in dynamics.reproduction_events]
        return float(np.mean(reinforcements))

    def _analyze_transformation_triggers(self, dynamics) -> Dict[str, int]:
        """Analyze triggers of transformation"""
        triggers = {}
        for event in dynamics.transformation_events:
            trigger = event.get('trigger', 'unknown')
            triggers[trigger] = triggers.get(trigger, 0) + 1
        return triggers

    def _identify_critical_junctures(self, sorted_data: List[StructurationContext]) -> List[Dict[str, Any]]:
        """Identify critical junctures in temporal data"""
        junctures = []
        for i in range(1, len(sorted_data)):
            rigidity_change = abs(sorted_data[i].structural_rigidity - sorted_data[i-1].structural_rigidity)
            if rigidity_change > 0.2:
                junctures.append({
                    'timestamp': sorted_data[i].timestamp.isoformat(),
                    'type': 'structural_shift',
                    'magnitude': float(rigidity_change)
                })
        return junctures

    def _analyze_path_dependency(self, sorted_data: List[StructurationContext]) -> Dict[str, Any]:
        """Analyze path dependency in structural evolution"""
        if len(sorted_data) < 3:
            return {'insufficient_data': True}

        rigidities = [ctx.structural_rigidity for ctx in sorted_data]
        autocorrelation = np.corrcoef(rigidities[:-1], rigidities[1:])[0, 1]

        return {
            'path_dependency_strength': float(autocorrelation),
            'interpretation': 'strong' if autocorrelation > 0.7 else 'moderate' if autocorrelation > 0.4 else 'weak'
        }


def analyze_structuration(
    incubator_context: StructurationContext,
    temporal_data: Optional[List[StructurationContext]] = None
) -> Dict[str, Any]:
    """
    Convenience function for structuration analysis

    Args:
        incubator_context: Current structuration context
        temporal_data: Optional temporal sequence

    Returns:
        Structuration analysis results
    """
    analyzer = StructurationAnalyzer()
    return analyzer.analyze_structuration(incubator_context, temporal_data)
