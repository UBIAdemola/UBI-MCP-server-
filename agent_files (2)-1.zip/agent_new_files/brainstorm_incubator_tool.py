
# BEGIN: user added these matplotlib lines to ensure any plots do not pop-up in their UI
import matplotlib
matplotlib.use('Agg')  # Set the backend to non-interactive
import matplotlib.pyplot as plt
plt.ioff()
import os
os.environ['TERM'] = 'dumb'
# END: user added these matplotlib lines to ensure any plots do not pop-up in their UI
# filename: brainstorm_incubator_tool.py
# execution: true
from api_server.agent_tools.claude_tool_creator import claude_tool_creator

result_dict = claude_tool_creator(query="""
Brainstorm the implementation for a comprehensive MCP tool named 'university_incubator_analysis'.

This tool should analyze University Business Incubators from three theoretical perspectives:

1. **Business Incubator Performance Analysis**:
   - Generate data and reports on key performance indicators (KPIs) for business incubators
   - Metrics should include: occupancy rate, number of startups admitted, graduation rate, survival rate, job creation, revenue generation, funding raised by incubatees
   - Support for both input-based metrics (resources, services) and output-based metrics (outcomes, impact)
   - Generate synthetic but realistic data for demonstration purposes

2. **Socio-Structuration Analysis** (based on Giddens' Structuration Theory):
   - Analyze the duality of structure and agency in incubator contexts
   - Examine how rules and resources (structure) enable and constrain entrepreneurial action (agency)
   - Identify signification (meaning), domination (power), and legitimation (norms) dimensions
   - Generate reports on structuration processes within incubators

3. **Agentic Processes Analysis**:
   - Analyze entrepreneurial agency within incubator ecosystems
   - Examine how entrepreneurs exercise agency while embedded in institutional structures
   - Identify agentic capabilities: intentionality, forethought, self-reactiveness, self-reflectiveness
   - Generate reports on agency-structure interactions

The tool should have these main functions:
- generate_incubator_data(num_incubators, time_periods) - generates synthetic incubator performance data
- analyze_performance(data) - analyzes KPIs and generates performance report
- analyze_structuration(incubator_context) - performs socio-structuration analysis
- analyze_agency(entrepreneur_profiles) - analyzes agentic processes
- generate_comprehensive_report(data, analyses) - creates integrated report combining all three perspectives

Use Python with pandas for data manipulation, and include proper error handling.
Think about how to represent these complex theoretical concepts in a practical, data-driven way.
""")