
# BEGIN: user added these matplotlib lines to ensure any plots do not pop-up in their UI
import matplotlib
matplotlib.use('Agg')  # Set the backend to non-interactive
import matplotlib.pyplot as plt
plt.ioff()
import os
os.environ['TERM'] = 'dumb'
# END: user added these matplotlib lines to ensure any plots do not pop-up in their UI
# filename: create_agency_analysis.py
# execution: true

agency_analysis_code = '''"""
Agency analysis module for examining entrepreneurial agency.

Analyzes agentic capabilities and processes within incubator contexts.
"""

from typing import Dict, List
from collections import Counter
from data_models import IncubatorData, EntrepreneurProfile


def analyze_agency(data: IncubatorData) -> Dict:
    """
    Analyze entrepreneurial agency and agentic processes.
    
    Examines four dimensions of agency (Bandura):
    - Intentionality: Goal-directed behavior
    - Forethought: Future-oriented planning
    - Self-reactiveness: Self-regulation
    - Self-reflectiveness: Metacognition
    
    Args:
        data: IncubatorData object containing entrepreneur profiles
        
    Returns:
        Dictionary with agency analysis results
    """
    if not data.entrepreneur_profiles:
        raise ValueError("No entrepreneur profile data provided")
    
    # Analyze by incubator
    incubator_analyses = {}
    profiles_by_incubator = {}
    
    for profile in data.entrepreneur_profiles:
        if profile.incubator_id not in profiles_by_incubator:
            profiles_by_incubator[profile.incubator_id] = []
        profiles_by_incubator[profile.incubator_id].append(profile)
    
    for incubator_id, profiles in profiles_by_incubator.items():
        analysis = _analyze_incubator_agency(profiles)
        incubator_analyses[incubator_id] = analysis
    
    # Aggregate analysis
    aggregate = _calculate_aggregate_agency(data.entrepreneur_profiles)
    
    # Generate insights
    insights = _generate_agency_insights(incubator_analyses, aggregate)
    
    return {
        "incubator_analyses": incubator_analyses,
        "aggregate_patterns": aggregate,
        "insights": insights,
        "summary": {
            "total_entrepreneurs": len(data.entrepreneur_profiles),
            "avg_agency_score": aggregate["avg_overall_agency"],
            "dominant_agency_type": aggregate["dominant_agency_type"]
        }
    }


def _analyze_incubator_agency(profiles: List[EntrepreneurProfile]) -> Dict:
    """Analyze agency for entrepreneurs in a single incubator."""
    
    # Calculate average scores for each capability
    avg_intentionality = sum(p.intentionality.score for p in profiles) / len(profiles)
    avg_forethought = sum(p.forethought.score for p in profiles) / len(profiles)
    avg_self_reactiveness = sum(p.self_reactiveness.score for p in profiles) / len(profiles)
    avg_self_reflectiveness = sum(p.self_reflectiveness.score for p in profiles) / len(profiles)
    avg_overall = sum(p.overall_agency_score for p in profiles) / len(profiles)
    
    # Identify capability strengths and weaknesses
    capabilities = {
        "Intentionality": avg_intentionality,
        "Forethought": avg_forethought,
        "Self-Reactiveness": avg_self_reactiveness,
        "Self-Reflectiveness": avg_self_reflectiveness
    }
    
    strongest = max(capabilities.items(), key=lambda x: x[1])
    weakest = min(capabilities.items(), key=lambda x: x[1])
    
    # Count agency types
    agency_types = Counter(p.agency_type for p in profiles)
    dominant_type = agency_types.most_common(1)[0][0]
    
    # Analyze constraints
    all_constraints = []
    for profile in profiles:
        all_constraints.extend(profile.intentionality.constraints)
        all_constraints.extend(profile.forethought.constraints)
        all_constraints.extend(profile.self_reactiveness.constraints)
        all_constraints.extend(profile.self_reflectiveness.constraints)
    
    common_constraints = Counter(all_constraints).most_common(5)
    
    return {
        "capability_scores": {
            "intentionality": round(avg_intentionality, 3),
            "forethought": round(avg_forethought, 3),
            "self_reactiveness": round(avg_self_reactiveness, 3),
            "self_reflectiveness": round(avg_self_reflectiveness, 3),
            "overall": round(avg_overall, 3)
        },
        "capability_profile": {
            "strongest_capability": strongest[0],
            "strongest_score": round(strongest[1], 3),
            "weakest_capability": weakest[0],
            "weakest_score": round(weakest[1], 3)
        },
        "agency_types": dict(agency_types),
        "dominant_agency_type": dominant_type,
        "common_constraints": [c[0] for c in common_constraints],
        "entrepreneur_count": len(profiles)
    }


def _calculate_aggregate_agency(profiles: List[EntrepreneurProfile]) -> Dict:
    """Calculate aggregate agency patterns across all entrepreneurs."""
    
    avg_overall = sum(p.overall_agency_score for p in profiles) / len(profiles)
    
    # Agency type distribution
    agency_types = Counter(p.agency_type for p in profiles)
    dominant_type = agency_types.most_common(1)[0][0]
    
    # Capability averages
    avg_intentionality = sum(p.intentionality.score for p in profiles) / len(profiles)
    avg_forethought = sum(p.forethought.score for p in profiles) / len(profiles)
    avg_self_reactiveness = sum(p.self_reactiveness.score for p in profiles) / len(profiles)
    avg_self_reflectiveness = sum(p.self_reflectiveness.score for p in profiles) / len(profiles)
    
    # High agency entrepreneurs (score > 0.7)
    high_agency_count = sum(1 for p in profiles if p.overall_agency_score > 0.7)
    high_agency_pct = (high_agency_count / len(profiles)) * 100
    
    return {
        "avg_overall_agency": round(avg_overall, 3),
        "agency_type_distribution": dict(agency_types),
        "dominant_agency_type": dominant_type,
        "capability_averages": {
            "intentionality": round(avg_intentionality, 3),
            "forethought": round(avg_forethought, 3),
            "self_reactiveness": round(avg_self_reactiveness, 3),
            "self_reflectiveness": round(avg_self_reflectiveness, 3)
        },
        "high_agency_percentage": round(high_agency_pct, 1)
    }


def _generate_agency_insights(
    incubator_analyses: Dict,
    aggregate: Dict
) -> List[str]:
    """Generate insights from agency analysis."""
    
    insights = []
    
    # Overall agency level
    avg_agency = aggregate["avg_overall_agency"]
    if avg_agency > 0.7:
        insights.append(
            "High overall agency scores indicate entrepreneurs have strong capabilities "
            "for intentional, future-oriented, and self-regulated action"
        )
    elif avg_agency < 0.5:
        insights.append(
            "Lower agency scores suggest entrepreneurs may benefit from additional "
            "support in developing agentic capabilities"
        )
    
    # Agency type insights
    dominant_type = aggregate["dominant_agency_type"]
    insights.append(
        f"Dominant agency type is '{dominant_type}', indicating the primary mode "
        f"of entrepreneurial action in the incubator ecosystem"
    )
    
    # Capability insights
    capabilities = aggregate["capability_averages"]
    strongest = max(capabilities.items(), key=lambda x: x[1])
    weakest = min(capabilities.items(), key=lambda x: x[1])
    
    insights.append(
        f"Entrepreneurs show strongest capability in {strongest[0]} "
        f"(score: {strongest[1]:.3f})"
    )
    
    insights.append(
        f"Development opportunity identified in {weakest[0]} "
        f"(score: {weakest[1]:.3f})"
    )
    
    # High agency percentage
    if aggregate["high_agency_percentage"] > 50:
        insights.append(
            f"{aggregate['high_agency_percentage']:.1f}% of entrepreneurs demonstrate "
            "high agency, suggesting effective incubator support for entrepreneurial autonomy"
        )
    
    # Theoretical implications
    insights.append(
        "Agency analysis reveals how entrepreneurs exercise intentionality and "
        "self-direction within the structural context of incubators"
    )
    
    return insights
'''

# Write the file
with open('mcp_tools_runner/university_incubator_analysis/agency_analysis.py', 'w') as f:
    f.write(agency_analysis_code)

print("Created agency_analysis.py")
print(f"File size: {len(agency_analysis_code)} characters")