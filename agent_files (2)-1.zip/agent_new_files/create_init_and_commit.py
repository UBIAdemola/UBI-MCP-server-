
# BEGIN: user added these matplotlib lines to ensure any plots do not pop-up in their UI
import matplotlib
matplotlib.use('Agg')  # Set the backend to non-interactive
import matplotlib.pyplot as plt
plt.ioff()
import os
os.environ['TERM'] = 'dumb'
# END: user added these matplotlib lines to ensure any plots do not pop-up in their UI
# filename: create_init_and_commit.py
# execution: true
import os
import subprocess

# Create __init__.py
init_code = '''"""
University Incubator Analysis MCP Tool

A comprehensive tool for analyzing university business incubators from three perspectives:
- Performance Analysis (KPIs and metrics)
- Socio-Structuration Analysis (Giddens' theory)
- Agentic Processes Analysis (entrepreneurial agency)
"""

__version__ = "1.0.0"
'''

with open('mcp_tools_runner/university_incubator_analysis/__init__.py', 'w') as f:
    f.write(init_code)

print("Created __init__.py")

# List all created files
print("\nFiles created in university_incubator_analysis/:")
files = os.listdir('mcp_tools_runner/university_incubator_analysis')
for f in sorted(files):
    size = os.path.getsize(f'mcp_tools_runner/university_incubator_analysis/{f}')
    print(f"  - {f} ({size} bytes)")

# Git commit
os.chdir('mcp_tools_runner')
subprocess.run(['git', 'add', 'university_incubator_analysis/'], check=True)
subprocess.run(['git', 'commit', '-m', 'Add university_incubator_analysis MCP tool'], check=True)
print("\nCommitted to git repository")