
# BEGIN: user added these matplotlib lines to ensure any plots do not pop-up in their UI
import matplotlib
matplotlib.use('Agg')  # Set the backend to non-interactive
import matplotlib.pyplot as plt
plt.ioff()
import os
os.environ['TERM'] = 'dumb'
# END: user added these matplotlib lines to ensure any plots do not pop-up in their UI
# filename: create_structuration_analysis.py
# execution: true

structuration_analysis_code = '''"""
Structuration analysis module based on Giddens' Structuration Theory.

Analyzes the duality of structure and agency in incubator contexts.
"""

from typing import Dict, List
from data_models import IncubatorData, StructurationContext


def analyze_structuration(data: IncubatorData) -> Dict:
    """
    Analyze structuration processes in incubators.
    
    Based on Giddens' Structuration Theory, examining:
    - Signification (meaning and communication)
    - Domination (power and resources)
    - Legitimation (norms and sanctions)
    
    Args:
        data: IncubatorData object containing structuration contexts
        
    Returns:
        Dictionary with structuration analysis results
    """
    if not data.structuration_contexts:
        raise ValueError("No structuration context data provided")
    
    # Analyze each incubator's structuration
    incubator_analyses = {}
    for context in data.structuration_contexts:
        analysis = _analyze_single_context(context)
        incubator_analyses[context.incubator_id] = analysis
    
    # Calculate aggregate patterns
    aggregate = _calculate_aggregate_structuration(data.structuration_contexts)
    
    # Generate theoretical insights
    insights = _generate_structuration_insights(incubator_analyses, aggregate)
    
    return {
        "incubator_analyses": incubator_analyses,
        "aggregate_patterns": aggregate,
        "insights": insights,
        "summary": {
            "total_contexts": len(data.structuration_contexts),
            "avg_structural_rigidity": aggregate["avg_structural_rigidity"],
            "avg_agency_space": aggregate["avg_agency_space"],
            "dominant_process": aggregate["dominant_process"]
        }
    }


def _analyze_single_context(context: StructurationContext) -> Dict:
    """Analyze a single incubator's structuration context."""
    
    # Analyze each dimension
    signification_analysis = {
        "reproduction_score": context.signification.reproduction_score,
        "transformation_score": context.signification.transformation_score,
        "dominant_process": "Reproduction" if context.signification.reproduction_score > 
                           context.signification.transformation_score else "Transformation",
        "key_properties": context.signification.structural_properties,
        "interaction_patterns": context.signification.interaction_patterns
    }
    
    domination_analysis = {
        "reproduction_score": context.domination.reproduction_score,
        "transformation_score": context.domination.transformation_score,
        "dominant_process": "Reproduction" if context.domination.reproduction_score > 
                           context.domination.transformation_score else "Transformation",
        "key_properties": context.domination.structural_properties,
        "interaction_patterns": context.domination.interaction_patterns
    }
    
    legitimation_analysis = {
        "reproduction_score": context.legitimation.reproduction_score,
        "transformation_score": context.legitimation.transformation_score,
        "dominant_process": "Reproduction" if context.legitimation.reproduction_score > 
                           context.legitimation.transformation_score else "Transformation",
        "key_properties": context.legitimation.structural_properties,
        "interaction_patterns": context.legitimation.interaction_patterns
    }
    
    # Analyze duality of structure
    duality_analysis = {
        "structural_rigidity": context.structural_rigidity,
        "agency_space": context.agency_space,
        "balance": context.duality_balance,
        "interpretation": _interpret_duality(
            context.structural_rigidity,
            context.agency_space
        )
    }
    
    # Overall structuration assessment
    avg_reproduction = (
        context.signification.reproduction_score +
        context.domination.reproduction_score +
        context.legitimation.reproduction_score
    ) / 3
    
    avg_transformation = (
        context.signification.transformation_score +
        context.domination.transformation_score +
        context.legitimation.transformation_score
    ) / 3
    
    structuration_type = _determine_structuration_type(
        avg_reproduction,
        avg_transformation,
        context.structural_rigidity
    )
    
    return {
        "dimensions": {
            "signification": signification_analysis,
            "domination": domination_analysis,
            "legitimation": legitimation_analysis
        },
        "duality": duality_analysis,
        "overall": {
            "avg_reproduction": round(avg_reproduction, 3),
            "avg_transformation": round(avg_transformation, 3),
            "structuration_type": structuration_type
        }
    }


def _interpret_duality(rigidity: float, agency: float) -> str:
    """Interpret the structure-agency duality."""
    
    if rigidity > 0.7 and agency < 0.4:
        return "Structure-dominated: High constraints, limited agency"
    elif rigidity < 0.4 and agency > 0.7:
        return "Agency-dominated: High autonomy, flexible structures"
    elif abs(rigidity - agency) < 0.2:
        return "Balanced duality: Structure enables and constrains agency equally"
    elif rigidity > agency:
        return "Structure-leaning: Structures provide stability but may limit innovation"
    else:
        return "Agency-leaning: Entrepreneurial freedom with some structural support"


def _determine_structuration_type(
    reproduction: float,
    transformation: float,
    rigidity: float
) -> str:
    """Determine the type of structuration process."""
    
    if reproduction > 0.7 and transformation < 0.3:
        return "Conservative Structuration"
    elif transformation > 0.6 and reproduction < 0.4:
        return "Transformative Structuration"
    elif abs(reproduction - transformation) < 0.2:
        return "Balanced Structuration"
    elif rigidity > 0.6:
        return "Institutionalized Structuration"
    else:
        return "Emergent Structuration"


def _calculate_aggregate_structuration(contexts: List[StructurationContext]) -> Dict:
    """Calculate aggregate structuration patterns."""
    
    avg_rigidity = sum(c.structural_rigidity for c in contexts) / len(contexts)
    avg_agency = sum(c.agency_space for c in contexts) / len(contexts)
    
    # Count dominant processes
    reproduction_dominant = sum(
        1 for c in contexts
        if (c.signification.reproduction_score + c.domination.reproduction_score + 
            c.legitimation.reproduction_score) / 3 > 0.6
    )
    
    transformation_dominant = sum(
        1 for c in contexts
        if (c.signification.transformation_score + c.domination.transformation_score + 
            c.legitimation.transformation_score) / 3 > 0.6
    )
    
    if reproduction_dominant > transformation_dominant:
        dominant_process = "Reproduction"
    elif transformation_dominant > reproduction_dominant:
        dominant_process = "Transformation"
    else:
        dominant_process = "Mixed"
    
    return {
        "avg_structural_rigidity": round(avg_rigidity, 3),
        "avg_agency_space": round(avg_agency, 3),
        "dominant_process": dominant_process,
        "reproduction_dominant_count": reproduction_dominant,
        "transformation_dominant_count": transformation_dominant
    }


def _generate_structuration_insights(
    incubator_analyses: Dict,
    aggregate: Dict
) -> List[str]:
    """Generate theoretical insights from structuration analysis."""
    
    insights = []
    
    # Duality insights
    if aggregate["avg_structural_rigidity"] > 0.6:
        insights.append(
            "High structural rigidity suggests institutionalized practices that may "
            "constrain entrepreneurial innovation"
        )
    
    if aggregate["avg_agency_space"] > 0.6:
        insights.append(
            "High agency space indicates entrepreneurs have significant autonomy to "
            "shape their ventures and challenge existing structures"
        )
    
    # Process insights
    if aggregate["dominant_process"] == "Reproduction":
        insights.append(
            "Reproduction-dominant structuration: Incubators tend to reinforce existing "
            "entrepreneurial norms and practices"
        )
    elif aggregate["dominant_process"] == "Transformation":
        insights.append(
            "Transformation-dominant structuration: Incubators are sites of structural "
            "change and innovation in entrepreneurial practices"
        )
    
    # Theoretical implications
    insights.append(
        "Structuration analysis reveals the recursive relationship between "
        "entrepreneurial action and institutional structures in incubator ecosystems"
    )
    
    return insights
'''

# Write the file
with open('mcp_tools_runner/university_incubator_analysis/structuration_analysis.py', 'w') as f:
    f.write(structuration_analysis_code)

print("Created structuration_analysis.py")
print(f"File size: {len(structuration_analysis_code)} characters")