
# BEGIN: user added these matplotlib lines to ensure any plots do not pop-up in their UI
import matplotlib
matplotlib.use('Agg')  # Set the backend to non-interactive
import matplotlib.pyplot as plt
plt.ioff()
import os
os.environ['TERM'] = 'dumb'
# END: user added these matplotlib lines to ensure any plots do not pop-up in their UI
# filename: create_mcp_structure.py
# execution: true
import os
import json

# Create the MCP tool directory structure
mcp_dir = "mcp_tools_runner/university_incubator_analysis"
os.makedirs(mcp_dir, exist_ok=True)

print(f"Created directory: {mcp_dir}")
print(f"Directory exists: {os.path.exists(mcp_dir)}")
print(f"Contents: {os.listdir('mcp_tools_runner/')}")