# filename: init_git.sh
# execution: true
cd mcp_tools_runner
git init
git config user.email "mcp-builder@h2o.ai"
git config user.name "MCP Builder"
echo "Git repository initialized for tracking MCP tool development"