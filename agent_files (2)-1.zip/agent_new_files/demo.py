#!/usr/bin/env python3
"""
Demo script for University Incubator Analysis Tool

This script demonstrates the complete workflow of the tool,
showing how to generate data, perform analyses, and create reports.
"""

import json
from university_incubator_analysis import (
    generate_incubator_data,
    analyze_performance,
    generate_structuration_contexts,
    analyze_structuration,
    generate_entrepreneur_profiles,
    analyze_agency,
    generate_comprehensive_report
)


def main():
    print("\n" + "="*70)
    print("UNIVERSITY INCUBATOR ANALYSIS TOOL - DEMO")
    print("="*70 + "\n")

    # Step 1: Generate Synthetic Data
    print("Step 1: Generating synthetic incubator data...")
    print("-" * 70)
    performance_data = generate_incubator_data(
        num_incubators=10,
        time_periods=12,
        seed=42
    )
    print(f"✓ Generated data for {performance_data['incubator_id'].nunique()} incubators")
    print(f"✓ Time periods: {performance_data['period'].nunique()}")
    print(f"✓ Total data points: {len(performance_data)}")
    print(f"\nSample data:\n{performance_data.head(3)[['incubator_id', 'incubator_name', 'occupancy_rate', 'graduation_rate']].to_string()}\n")

    # Step 2: Performance Analysis
    print("\nStep 2: Analyzing incubator performance...")
    print("-" * 70)
    performance_analysis = analyze_performance(performance_data)

    kpis = performance_analysis['kpi_analysis']
    print(f"✓ Average occupancy rate: {kpis['occupancy']['average_rate']:.1%}")
    print(f"✓ Average graduation rate: {kpis['success_metrics']['average_graduation_rate']:.1%}")
    print(f"✓ Total jobs created: {kpis['economic_impact']['total_jobs_created']:,}")
    print(f"✓ Total revenue generated: ${kpis['economic_impact']['total_revenue_generated']:,.0f}")
    print(f"✓ Total funding raised: ${kpis['economic_impact']['total_funding_raised']:,.0f}")

    print("\nKey Performance Insights:")
    for i, insight in enumerate(performance_analysis['insights'][:3], 1):
        print(f"  {i}. {insight}")

    # Step 3: Structuration Analysis
    print("\n\nStep 3: Analyzing structuration (Giddens' Theory)...")
    print("-" * 70)
    incubator_ids = performance_data['incubator_id'].unique().tolist()
    structuration_contexts = generate_structuration_contexts(
        incubator_ids[:3],
        seed=42
    )

    structuration_analysis = analyze_structuration(structuration_contexts[0])

    struct_char = structuration_analysis['structural_analysis']['structural_characteristics']
    print(f"✓ Structural rigidity: {struct_char['rigidity']:.2f}")
    print(f"✓ Structural complexity: {struct_char['complexity']:.2f}")
    print(f"✓ Structural coherence: {struct_char['coherence']:.2f}")

    agency_metrics = structuration_analysis['agency_analysis']['agency_space_metrics']
    print(f"✓ Agency space: {agency_metrics['overall_agency_space']:.2f}")
    print(f"✓ Entrepreneurial autonomy: {agency_metrics['entrepreneurial_autonomy']:.2f}")

    duality = structuration_analysis['duality_analysis']['net_effect']
    print(f"✓ Dominant effect: {duality['dominant_effect']}")
    print(f"✓ Balance: {duality['balance']}")

    print("\nStructuration Insights:")
    for i, insight in enumerate(structuration_analysis['insights'][:3], 1):
        print(f"  {i}. {insight}")

    # Step 4: Agency Analysis
    print("\n\nStep 4: Analyzing entrepreneurial agency...")
    print("-" * 70)
    entrepreneur_profiles = generate_entrepreneur_profiles(
        50,
        incubator_ids[:3],
        seed=42
    )

    agency_analysis_result = analyze_agency(
        entrepreneur_profiles,
        structuration_contexts[0]
    )

    summary = agency_analysis_result['summary']
    print(f"✓ Total entrepreneurs analyzed: {summary['total_entrepreneurs']}")
    print(f"✓ Average agency score: {summary['average_agency_score']:.2f}")

    capabilities = agency_analysis_result['capability_analysis']
    print("\nAgentic Capabilities (mean scores):")
    print(f"  • Intentionality: {capabilities['intentionality']['mean']:.2f}")
    print(f"  • Forethought: {capabilities['forethought']['mean']:.2f}")
    print(f"  • Self-Reactiveness: {capabilities['self_reactiveness']['mean']:.2f}")
    print(f"  • Self-Reflectiveness: {capabilities['self_reflectiveness']['mean']:.2f}")

    typology = agency_analysis_result['typology']
    print("\nAgency Type Distribution:")
    for agency_type, type_data in list(typology['types'].items())[:3]:
        print(f"  • {agency_type}: {type_data['count']} ({type_data['percentage']:.1%})")

    print("\nAgency Insights:")
    for i, insight in enumerate(agency_analysis_result['insights'][:3], 1):
        print(f"  {i}. {insight}")

    # Step 5: Generate Comprehensive Report
    print("\n\nStep 5: Generating comprehensive integrated report...")
    print("-" * 70)

    report = generate_comprehensive_report(
        performance_data,
        performance_analysis,
        structuration_contexts,
        structuration_analysis,
        entrepreneur_profiles,
        agency_analysis_result,
        output_format="json"
    )

    print("✓ Report generated successfully!")
    print(f"✓ Report sections: {len(report)}")
    print(f"✓ Report includes:")
    for section in report.keys():
        print(f"    - {section}")

    # Display executive summary
    print("\n\nEXECUTIVE SUMMARY")
    print("="*70)
    exec_summary = report['executive_summary']
    print(f"{exec_summary['overview']}\n")

    if 'performance_highlights' in exec_summary:
        print("Performance Highlights:")
        for key, value in exec_summary['performance_highlights'].items():
            print(f"  • {key.replace('_', ' ').title()}: {value}")

    if 'key_insights' in exec_summary:
        print("\nKey Insights:")
        for i, insight in enumerate(exec_summary['key_insights'], 1):
            print(f"  {i}. {insight}")

    # Display recommendations
    print("\n\nRECOMMENDATIONS")
    print("="*70)
    recommendations = report['recommendations']

    for category, recs in recommendations.items():
        if recs:
            print(f"\n{category.replace('_', ' ').title()}:")
            for i, rec in enumerate(recs, 1):
                print(f"  {i}. {rec}")

    # Save report to file
    output_file = "incubator_analysis_report.json"
    with open(output_file, 'w') as f:
        json.dump(report, f, indent=2)
    print(f"\n✓ Full report saved to: {output_file}")

    # Generate markdown report
    markdown_report = generate_comprehensive_report(
        performance_data,
        performance_analysis,
        structuration_contexts,
        structuration_analysis,
        entrepreneur_profiles,
        agency_analysis_result,
        output_format="markdown"
    )

    markdown_file = "incubator_analysis_report.md"
    with open(markdown_file, 'w') as f:
        f.write(markdown_report)
    print(f"✓ Markdown report saved to: {markdown_file}")

    print("\n" + "="*70)
    print("DEMO COMPLETED SUCCESSFULLY!")
    print("="*70 + "\n")

    print("The tool has successfully demonstrated:")
    print("  1. ✓ Synthetic data generation with realistic distributions")
    print("  2. ✓ Performance analysis with comprehensive KPIs")
    print("  3. ✓ Structuration analysis (Giddens' Theory)")
    print("  4. ✓ Agentic processes analysis")
    print("  5. ✓ Integrated reporting across all perspectives")
    print("\nThis tool can be used for:")
    print("  • Incubator management and improvement")
    print("  • Policy analysis and development")
    print("  • Academic research on entrepreneurial ecosystems")
    print("  • Benchmarking and comparative studies")
    print("  • Understanding structure-agency dynamics\n")


if __name__ == "__main__":
    main()
