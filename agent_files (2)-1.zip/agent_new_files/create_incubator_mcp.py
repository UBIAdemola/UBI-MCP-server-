
# BEGIN: user added these matplotlib lines to ensure any plots do not pop-up in their UI
import matplotlib
matplotlib.use('Agg')  # Set the backend to non-interactive
import matplotlib.pyplot as plt
plt.ioff()
import os
os.environ['TERM'] = 'dumb'
# END: user added these matplotlib lines to ensure any plots do not pop-up in their UI
# filename: create_incubator_mcp.py
# execution: true
from api_server.agent_tools.claude_tool_creator import claude_tool_creator

result_dict = claude_tool_creator(query="""
Create a local MCP tool named 'university_incubator_analysis' based on the comprehensive implementation that was just brainstormed.

The tool should be placed in './mcp_tools_runner/university_incubator_analysis/' and include:

1. **server.py** - A fastMCPv2 server with these main functions:
   - generate_incubator_data(num_incubators: int, time_periods: int, seed: int = None) -> dict
   - analyze_performance(data: dict) -> dict
   - analyze_structuration(incubator_context: dict) -> dict
   - analyze_agency(entrepreneur_profiles: dict) -> dict
   - generate_comprehensive_report(data: dict, include_performance: bool = True, include_structuration: bool = True, include_agency: bool = True, output_format: str = "json") -> dict

2. **Supporting modules** that were developed in the brainstorming:
   - data_models.py - Data structures for all three perspectives
   - data_generator.py - Synthetic data generation
   - performance_analysis.py - KPI analysis
   - structuration_analysis.py - Giddens' Structuration Theory implementation
   - agency_analysis.py - Agentic processes analysis
   - reporting.py - Multi-format reporting

3. **description.md** - Comprehensive documentation explaining:
   - The three theoretical perspectives (Business Incubator Performance, Socio-Structuration, Agentic Processes)
   - Each function's purpose, parameters, and return values
   - Example use cases
   - Theoretical background

4. **README.md** - User guide with examples and API reference

Please ensure:
- All code from the brainstorming session is properly integrated
- The fastMCPv2 server properly exposes all functions
- Proper error handling throughout
- Type hints and validation
- No environment variables needed
- All supporting modules are included in the tool directory

Copy all the implementation files that were created during brainstorming into the proper MCP tool structure.
""", build_mcp=True)