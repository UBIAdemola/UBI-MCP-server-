
# BEGIN: user added these matplotlib lines to ensure any plots do not pop-up in their UI
import matplotlib
matplotlib.use('Agg')  # Set the backend to non-interactive
import matplotlib.pyplot as plt
plt.ioff()
import os
os.environ['TERM'] = 'dumb'
# END: user added these matplotlib lines to ensure any plots do not pop-up in their UI
# filename: test_incubator_tool.py
# execution: true
from api_server.agent_tools.claude_tool_runner import claude_tool_runner

result_dict = claude_tool_runner(
    query="""
    Use the 'university_incubator_analysis' MCP tool to:
    1. Generate data for 3 incubators over 8 time periods with seed 42
    2. Analyze the performance metrics
    3. Analyze the structuration processes
    4. Analyze the agentic processes
    5. Generate a comprehensive report in markdown format
    
    Show me the key findings from each analysis.
    """,
    tools=["university_incubator_analysis"]
)