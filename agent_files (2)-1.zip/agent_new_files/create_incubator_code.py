
# BEGIN: user added these matplotlib lines to ensure any plots do not pop-up in their UI
import matplotlib
matplotlib.use('Agg')  # Set the backend to non-interactive
import matplotlib.pyplot as plt
plt.ioff()
import os
os.environ['TERM'] = 'dumb'
# END: user added these matplotlib lines to ensure any plots do not pop-up in their UI
# filename: create_incubator_code.py
# execution: true
from api_server.agent_tools.claude_tool_creator import claude_tool_creator

result_dict = claude_tool_creator(query="""
Generate complete Python code for a University Incubator Analysis tool with these components:

1. Create data_models.py with Pydantic models for:
   - IncubatorData (performance metrics)
   - StructurationContext (structure-agency dimensions)
   - EntrepreneurProfile (agentic capabilities)

2. Create data_generator.py with function:
   - generate_incubator_data(num_incubators, time_periods, seed) that creates realistic synthetic data

3. Create performance_analysis.py with function:
   - analyze_performance(data) that calculates KPIs like occupancy rate, graduation rate, survival rate, job creation, revenue, funding

4. Create structuration_analysis.py with function:
   - analyze_structuration(context) that analyzes signification, domination, legitimation dimensions based on Giddens' theory

5. Create agency_analysis.py with function:
   - analyze_agency(profiles) that analyzes intentionality, forethought, self-reactiveness, self-reflectiveness

6. Create reporting.py with function:
   - generate_comprehensive_report(data, analyses, output_format) that creates integrated reports in JSON/Markdown format

Save all files to the current directory with proper imports, type hints, error handling, and documentation.
Make the code production-ready and well-structured.
""")