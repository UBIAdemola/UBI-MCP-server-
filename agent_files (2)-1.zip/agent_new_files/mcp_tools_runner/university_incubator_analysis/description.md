# University Incubator Analysis MCP Tool

This MCP tool provides comprehensive analysis of University Business Incubators from three theoretical perspectives:

1. **Performance Analysis** - Quantitative KPIs and metrics
2. **Socio-Structuration Analysis** - Based on Giddens' Structuration Theory
3. **Agentic Processes Analysis** - Entrepreneurial agency and capabilities

## Theoretical Framework

### 1. Business Incubator Performance Analysis

Analyzes incubator effectiveness using key performance indicators:

- **Input Metrics**: Capacity, staff, resources
- **Process Metrics**: Admissions, graduations, active startups
- **Output Metrics**: Job creation, revenue generation, funding raised
- **Outcome Metrics**: Survival rates, growth trends

### 2. Socio-Structuration Analysis (Giddens)

Based on Anthony Giddens' Structuration Theory, examining the duality of structure and agency:

- **Signification**: Meaning-making, communication, interpretive schemes
- **Domination**: Power relations, resource allocation, authority structures
- **Legitimation**: Norms, sanctions, moral frameworks

Analyzes how structures both enable and constrain entrepreneurial action, and how entrepreneurial practices reproduce or transform institutional structures.

### 3. Agentic Processes Analysis (Bandura)

Examines entrepreneurial agency across four dimensions:

- **Intentionality**: Goal-directed behavior and strategic planning
- **Forethought**: Future-oriented thinking and scenario planning
- **Self-Reactiveness**: Self-regulation, monitoring, and adaptive behavior
- **Self-Reflectiveness**: Metacognition, self-assessment, learning from experience

## Functions

### `generate_data(num_incubators, time_periods, seed)`

Generates synthetic but realistic incubator data for analysis.

**Parameters:**
- `num_incubators` (int): Number of incubators to generate (default: 5)
- `time_periods` (int): Number of time periods, e.g., quarters (default: 12)
- `seed` (int, optional): Random seed for reproducibility

**Returns:**
- `data` (dict): Complete dataset with metrics, contexts, and profiles
- `message` (str): Status message

**Example:**
```json
{
  "num_incubators": 5,
  "time_periods": 12,
  "seed": 42
}
```

### `analyze_performance_tool(data)`

Analyzes incubator performance metrics and generates KPI reports.

**Parameters:**
- `data` (dict): Incubator data containing performance metrics

**Returns:**
- `analysis` (dict): Performance analysis with KPIs, trends, and ratings
- `message` (str): Status message

**Analysis Includes:**
- Average occupancy and graduation rates
- Total jobs created and funding raised
- Performance trends over time
- Comparative ratings across incubators
- Actionable insights

### `analyze_structuration_tool(data)`

Performs socio-structuration analysis based on Giddens' theory.

**Parameters:**
- `data` (dict): Incubator data with structuration contexts

**Returns:**
- `analysis` (dict): Structuration analysis results
- `message` (str): Status message

**Analysis Includes:**
- Signification, domination, and legitimation dimensions
- Structural rigidity vs. agency space
- Reproduction vs. transformation processes
- Duality of structure interpretations
- Theoretical insights

### `analyze_agency_tool(data)`

Analyzes entrepreneurial agency and agentic capabilities.

**Parameters:**
- `data` (dict): Incubator data with entrepreneur profiles

**Returns:**
- `analysis` (dict): Agency analysis results
- `message` (str): Status message

**Analysis Includes:**
- Scores for four agentic capabilities
- Agency type distribution (Transformative, Proactive, Adaptive, Reactive)
- Capability strengths and weaknesses
- Common structural constraints
- Development recommendations

### `generate_report(data, performance_analysis, structuration_analysis, agency_analysis, output_format)`

Generates comprehensive integrated report combining all analyses.

**Parameters:**
- `data` (dict): Original incubator data
- `performance_analysis` (dict, optional): Performance analysis results
- `structuration_analysis` (dict, optional): Structuration analysis results
- `agency_analysis` (dict, optional): Agency analysis results
- `output_format` (str): Output format - "json", "markdown", or "html" (default: "json")

**Returns:**
- `report` (dict): Complete structured report
- `formatted_content` (str): Formatted report in requested format
- `message` (str): Status message

## Use Cases

### Academic Research
- Study entrepreneurial ecosystems
- Analyze structure-agency dynamics
- Investigate incubator effectiveness

### Incubator Management
- Monitor performance metrics
- Identify improvement opportunities
- Benchmark against best practices

### Policy Development
- Understand institutional structures
- Design support mechanisms
- Evaluate program effectiveness

### Entrepreneurship Education
- Demonstrate theoretical concepts
- Analyze real-world cases
- Develop analytical skills

## Example Workflow

1. **Generate Data**: Create synthetic dataset for 5 incubators over 12 quarters
2. **Analyze Performance**: Calculate KPIs and identify trends
3. **Analyze Structuration**: Examine structure-agency dynamics
4. **Analyze Agency**: Profile entrepreneurial capabilities
5. **Generate Report**: Create comprehensive integrated report in Markdown format

## Theoretical Background

This tool operationalizes key concepts from:

- **Giddens, A. (1984)**. *The Constitution of Society*. University of California Press.
- **Bandura, A. (2001)**. Social cognitive theory: An agentic perspective. *Annual Review of Psychology*, 52, 1-26.
- Business incubation literature on performance measurement and evaluation

## No Environment Variables Required

This tool operates entirely with synthetic data generation and does not require any external API keys or credentials.
