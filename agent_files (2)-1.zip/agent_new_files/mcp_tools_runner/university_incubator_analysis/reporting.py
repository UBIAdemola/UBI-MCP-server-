"""
Reporting module for generating comprehensive analysis reports.

Supports multiple output formats: JSON, Markdown, HTML.
"""

import json
from typing import Dict
from datetime import datetime


def generate_comprehensive_report(
    data: Dict,
    performance_analysis: Dict = None,
    structuration_analysis: Dict = None,
    agency_analysis: Dict = None,
    output_format: str = "json"
) -> Dict:
    """
    Generate comprehensive report combining all analyses.
    
    Args:
        data: Original incubator data
        performance_analysis: Performance analysis results
        structuration_analysis: Structuration analysis results
        agency_analysis: Agency analysis results
        output_format: Output format ("json", "markdown", or "html")
        
    Returns:
        Dictionary with report content and metadata
    """
    report = {
        "metadata": {
            "generated_at": datetime.now().isoformat(),
            "report_type": "University Incubator Comprehensive Analysis",
            "format": output_format
        },
        "data_summary": {
            "num_incubators": data.get("metadata", {}).get("num_incubators", 0),
            "time_periods": data.get("metadata", {}).get("time_periods", 0),
            "num_entrepreneurs": len(data.get("entrepreneur_profiles", []))
        }
    }
    
    # Add analyses
    if performance_analysis:
        report["performance_analysis"] = performance_analysis
    
    if structuration_analysis:
        report["structuration_analysis"] = structuration_analysis
    
    if agency_analysis:
        report["agency_analysis"] = agency_analysis
    
    # Generate formatted output
    if output_format == "json":
        content = json.dumps(report, indent=2)
    elif output_format == "markdown":
        content = _generate_markdown_report(report)
    elif output_format == "html":
        content = _generate_html_report(report)
    else:
        raise ValueError(f"Unsupported output format: {output_format}")
    
    return {
        "report": report,
        "formatted_content": content,
        "format": output_format
    }


def _generate_markdown_report(report: Dict) -> str:
    """Generate Markdown formatted report."""
    
    md = []
    md.append("# University Business Incubator Analysis Report")
    md.append(f"
**Generated:** {report['metadata']['generated_at']}")
    md.append(f"
**Report Type:** {report['metadata']['report_type']}
")
    
    # Data Summary
    md.append("## Data Summary
")
    summary = report["data_summary"]
    md.append(f"- **Number of Incubators:** {summary['num_incubators']}")
    md.append(f"- **Time Periods Analyzed:** {summary['time_periods']}")
    md.append(f"- **Number of Entrepreneurs:** {summary['num_entrepreneurs']}
")
    
    # Performance Analysis
    if "performance_analysis" in report:
        md.append("## Performance Analysis
")
        perf = report["performance_analysis"]
        
        if "summary" in perf:
            md.append("### Summary
")
            for key, value in perf["summary"].items():
                md.append(f"- **{key.replace('_', ' ').title()}:** {value}")
        
        if "insights" in perf:
            md.append("
### Key Insights
")
            for insight in perf["insights"]:
                md.append(f"- {insight}")
        md.append("")
    
    # Structuration Analysis
    if "structuration_analysis" in report:
        md.append("## Socio-Structuration Analysis
")
        struct = report["structuration_analysis"]
        
        if "summary" in struct:
            md.append("### Summary
")
            for key, value in struct["summary"].items():
                md.append(f"- **{key.replace('_', ' ').title()}:** {value}")
        
        if "insights" in struct:
            md.append("
### Theoretical Insights
")
            for insight in struct["insights"]:
                md.append(f"- {insight}")
        md.append("")
    
    # Agency Analysis
    if "agency_analysis" in report:
        md.append("## Agentic Processes Analysis
")
        agency = report["agency_analysis"]
        
        if "summary" in agency:
            md.append("### Summary
")
            for key, value in agency["summary"].items():
                md.append(f"- **{key.replace('_', ' ').title()}:** {value}")
        
        if "insights" in agency:
            md.append("
### Agency Insights
")
            for insight in agency["insights"]:
                md.append(f"- {insight}")
        md.append("")
    
    return "\n".join(md)


def _generate_html_report(report: Dict) -> str:
    """Generate HTML formatted report."""
    
    html = []
    html.append("<!DOCTYPE html>")
    html.append("<html><head>")
    html.append("<title>University Incubator Analysis Report</title>")
    html.append("<style>")
    html.append("body { font-family: Arial, sans-serif; margin: 40px; }")
    html.append("h1 { color: #2c3e50; }")
    html.append("h2 { color: #34495e; border-bottom: 2px solid #3498db; padding-bottom: 10px; }")
    html.append("h3 { color: #7f8c8d; }")
    html.append(".summary { background: #ecf0f1; padding: 15px; border-radius: 5px; }")
    html.append(".insight { margin: 10px 0; padding: 10px; background: #e8f4f8; border-left: 4px solid #3498db; }")
    html.append("</style>")
    html.append("</head><body>")
    
    html.append("<h1>University Business Incubator Analysis Report</h1>")
    html.append(f"<p><strong>Generated:</strong> {report['metadata']['generated_at']}</p>")
    
    # Data Summary
    html.append("<h2>Data Summary</h2>")
    html.append("<div class='summary'>")
    summary = report["data_summary"]
    html.append(f"<p><strong>Number of Incubators:</strong> {summary['num_incubators']}</p>")
    html.append(f"<p><strong>Time Periods:</strong> {summary['time_periods']}</p>")
    html.append(f"<p><strong>Entrepreneurs:</strong> {summary['num_entrepreneurs']}</p>")
    html.append("</div>")
    
    # Performance Analysis
    if "performance_analysis" in report:
        html.append("<h2>Performance Analysis</h2>")
        perf = report["performance_analysis"]
        
        if "insights" in perf:
            for insight in perf["insights"]:
                html.append(f"<div class='insight'>{insight}</div>")
    
    # Structuration Analysis
    if "structuration_analysis" in report:
        html.append("<h2>Socio-Structuration Analysis</h2>")
        struct = report["structuration_analysis"]
        
        if "insights" in struct:
            for insight in struct["insights"]:
                html.append(f"<div class='insight'>{insight}</div>")
    
    # Agency Analysis
    if "agency_analysis" in report:
        html.append("<h2>Agentic Processes Analysis</h2>")
        agency = report["agency_analysis"]
        
        if "insights" in agency:
            for insight in agency["insights"]:
                html.append(f"<div class='insight'>{insight}</div>")
    
    html.append("</body></html>")
    
    return "\n".join(html)
