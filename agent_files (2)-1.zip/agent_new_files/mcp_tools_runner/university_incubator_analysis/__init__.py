"""
University Incubator Analysis MCP Tool

A comprehensive tool for analyzing university business incubators from three perspectives:
- Performance Analysis (KPIs and metrics)
- Socio-Structuration Analysis (Giddens' theory)
- Agentic Processes Analysis (entrepreneurial agency)
"""

__version__ = "1.0.0"
