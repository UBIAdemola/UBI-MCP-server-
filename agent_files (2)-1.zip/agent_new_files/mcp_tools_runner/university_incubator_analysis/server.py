"""
FastMCP Server for University Incubator Analysis.

Provides MCP tools for analyzing university business incubators from three perspectives:
1. Performance Analysis (KPIs and metrics)
2. Socio-Structuration Analysis (Giddens' theory)
3. Agentic Processes Analysis (entrepreneurial agency)
"""

from fastmcp import FastMCP
from pydantic import BaseModel, Field
from typing import Optional, Dict
import json

from data_generator import generate_incubator_data
from performance_analysis import analyze_performance
from structuration_analysis import analyze_structuration
from agency_analysis import analyze_agency
from reporting import generate_comprehensive_report

mcp = FastMCP("University Incubator Analysis")


class GenerateDataRequest(BaseModel):
    num_incubators: int = Field(5, description="Number of incubators to generate")
    time_periods: int = Field(12, description="Number of time periods (e.g., quarters)")
    seed: Optional[int] = Field(None, description="Random seed for reproducibility")


class GenerateDataResponse(BaseModel):
    data: Dict = Field(..., description="Generated incubator data")
    message: str = Field(..., description="Status message")


@mcp.tool()
def generate_data(request: GenerateDataRequest) -> GenerateDataResponse:
    """
    Generate synthetic incubator data for analysis.
    
    Creates realistic data including:
    - Performance metrics (occupancy, graduation rates, jobs, revenue, funding)
    - Structuration contexts (signification, domination, legitimation)
    - Entrepreneur profiles (agentic capabilities)
    """
    try:
        data = generate_incubator_data(
            num_incubators=request.num_incubators,
            time_periods=request.time_periods,
            seed=request.seed
        )
        
        # Convert to dict for JSON serialization
        data_dict = {
            "metrics": [m.model_dump() for m in data.metrics],
            "structuration_contexts": [c.model_dump() for c in data.structuration_contexts],
            "entrepreneur_profiles": [p.model_dump() for p in data.entrepreneur_profiles],
            "metadata": data.metadata
        }
        
        return GenerateDataResponse(
            data=data_dict,
            message=f"Generated data for {request.num_incubators} incubators over {request.time_periods} periods"
        )
    except Exception as e:
        return GenerateDataResponse(
            data={},
            message=f"Error generating data: {str(e)}"
        )


class AnalyzePerformanceRequest(BaseModel):
    data: Dict = Field(..., description="Incubator data to analyze")


class AnalyzePerformanceResponse(BaseModel):
    analysis: Dict = Field(..., description="Performance analysis results")
    message: str = Field(..., description="Status message")


@mcp.tool()
def analyze_performance_tool(request: AnalyzePerformanceRequest) -> AnalyzePerformanceResponse:
    """
    Analyze incubator performance metrics and KPIs.
    
    Calculates:
    - Occupancy rates, graduation rates, survival rates
    - Job creation, revenue generation, funding raised
    - Performance trends and ratings
    - Comparative analysis across incubators
    """
    try:
        from data_models import IncubatorData, IncubatorMetrics
        
        # Reconstruct data objects
        metrics = [IncubatorMetrics(**m) for m in request.data.get("metrics", [])]
        data_obj = IncubatorData(
            metrics=metrics,
            structuration_contexts=[],
            entrepreneur_profiles=[],
            metadata=request.data.get("metadata", {})
        )
        
        analysis = analyze_performance(data_obj)
        
        return AnalyzePerformanceResponse(
            analysis=analysis,
            message="Performance analysis completed successfully"
        )
    except Exception as e:
        return AnalyzePerformanceResponse(
            analysis={},
            message=f"Error in performance analysis: {str(e)}"
        )


class AnalyzeStructurationRequest(BaseModel):
    data: Dict = Field(..., description="Incubator data with structuration contexts")


class AnalyzeStructurationResponse(BaseModel):
    analysis: Dict = Field(..., description="Structuration analysis results")
    message: str = Field(..., description="Status message")


@mcp.tool()
def analyze_structuration_tool(request: AnalyzeStructurationRequest) -> AnalyzeStructurationResponse:
    """
    Analyze socio-structuration processes based on Giddens' Structuration Theory.
    
    Examines:
    - Signification (meaning and communication)
    - Domination (power and resources)
    - Legitimation (norms and sanctions)
    - Duality of structure and agency
    - Reproduction vs. transformation processes
    """
    try:
        from data_models import IncubatorData, StructurationContext, StructurationDimension
        
        # Reconstruct structuration contexts
        contexts = []
        for c in request.data.get("structuration_contexts", []):
            sig = StructurationDimension(**c["signification"])
            dom = StructurationDimension(**c["domination"])
            leg = StructurationDimension(**c["legitimation"])
            
            context = StructurationContext(
                incubator_id=c["incubator_id"],
                signification=sig,
                domination=dom,
                legitimation=leg,
                structural_rigidity=c["structural_rigidity"],
                agency_space=c["agency_space"],
                duality_balance=c["duality_balance"]
            )
            contexts.append(context)
        
        data_obj = IncubatorData(
            metrics=[],
            structuration_contexts=contexts,
            entrepreneur_profiles=[],
            metadata=request.data.get("metadata", {})
        )
        
        analysis = analyze_structuration(data_obj)
        
        return AnalyzeStructurationResponse(
            analysis=analysis,
            message="Structuration analysis completed successfully"
        )
    except Exception as e:
        return AnalyzeStructurationResponse(
            analysis={},
            message=f"Error in structuration analysis: {str(e)}"
        )


class AnalyzeAgencyRequest(BaseModel):
    data: Dict = Field(..., description="Incubator data with entrepreneur profiles")


class AnalyzeAgencyResponse(BaseModel):
    analysis: Dict = Field(..., description="Agency analysis results")
    message: str = Field(..., description="Status message")


@mcp.tool()
def analyze_agency_tool(request: AnalyzeAgencyRequest) -> AnalyzeAgencyResponse:
    """
    Analyze entrepreneurial agency and agentic processes.
    
    Examines four dimensions of agency:
    - Intentionality (goal-directed behavior)
    - Forethought (future-oriented planning)
    - Self-reactiveness (self-regulation)
    - Self-reflectiveness (metacognition)
    
    Identifies agency types and structural constraints.
    """
    try:
        from data_models import IncubatorData, EntrepreneurProfile, AgenticCapability
        
        # Reconstruct entrepreneur profiles
        profiles = []
        for p in request.data.get("entrepreneur_profiles", []):
            intent = AgenticCapability(**p["intentionality"])
            fore = AgenticCapability(**p["forethought"])
            react = AgenticCapability(**p["self_reactiveness"])
            refl = AgenticCapability(**p["self_reflectiveness"])
            
            profile = EntrepreneurProfile(
                entrepreneur_id=p["entrepreneur_id"],
                incubator_id=p["incubator_id"],
                intentionality=intent,
                forethought=fore,
                self_reactiveness=react,
                self_reflectiveness=refl,
                overall_agency_score=p["overall_agency_score"],
                agency_type=p["agency_type"]
            )
            profiles.append(profile)
        
        data_obj = IncubatorData(
            metrics=[],
            structuration_contexts=[],
            entrepreneur_profiles=profiles,
            metadata=request.data.get("metadata", {})
        )
        
        analysis = analyze_agency(data_obj)
        
        return AnalyzeAgencyResponse(
            analysis=analysis,
            message="Agency analysis completed successfully"
        )
    except Exception as e:
        return AnalyzeAgencyResponse(
            analysis={},
            message=f"Error in agency analysis: {str(e)}"
        )


class GenerateReportRequest(BaseModel):
    data: Dict = Field(..., description="Original incubator data")
    performance_analysis: Optional[Dict] = Field(None, description="Performance analysis results")
    structuration_analysis: Optional[Dict] = Field(None, description="Structuration analysis results")
    agency_analysis: Optional[Dict] = Field(None, description="Agency analysis results")
    output_format: str = Field("json", description="Output format: json, markdown, or html")


class GenerateReportResponse(BaseModel):
    report: Dict = Field(..., description="Comprehensive report")
    formatted_content: str = Field(..., description="Formatted report content")
    message: str = Field(..., description="Status message")


@mcp.tool()
def generate_report(request: GenerateReportRequest) -> GenerateReportResponse:
    """
    Generate comprehensive analysis report.
    
    Combines all three analytical perspectives:
    - Performance metrics and KPIs
    - Socio-structuration dynamics
    - Agentic processes
    
    Supports multiple output formats: JSON, Markdown, HTML.
    """
    try:
        result = generate_comprehensive_report(
            data=request.data,
            performance_analysis=request.performance_analysis,
            structuration_analysis=request.structuration_analysis,
            agency_analysis=request.agency_analysis,
            output_format=request.output_format
        )
        
        return GenerateReportResponse(
            report=result["report"],
            formatted_content=result["formatted_content"],
            message=f"Report generated successfully in {request.output_format} format"
        )
    except Exception as e:
        return GenerateReportResponse(
            report={},
            formatted_content="",
            message=f"Error generating report: {str(e)}"
        )


if __name__ == "__main__":
    mcp.run()
