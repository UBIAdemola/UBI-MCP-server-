
# BEGIN: user added these matplotlib lines to ensure any plots do not pop-up in their UI
import matplotlib
matplotlib.use('Agg')  # Set the backend to non-interactive
import matplotlib.pyplot as plt
plt.ioff()
import os
os.environ['TERM'] = 'dumb'
# END: user added these matplotlib lines to ensure any plots do not pop-up in their UI
# filename: fix_data_models.py
# execution: true

# Read the current file
with open('mcp_tools_runner/university_incubator_analysis/data_models.py', 'r') as f:
    content = f.read()

# Fix the import and type annotation
content = content.replace('from typing import List, Dict, Optional', 
                         'from typing import List, Dict, Optional, Any')
content = content.replace('metadata: Dict[str, any]', 
                         'metadata: Dict[str, Any]')

# Write back
with open('mcp_tools_runner/university_incubator_analysis/data_models.py', 'w') as f:
    f.write(content)

print("Fixed data_models.py - replaced 'any' with 'Any'")

# Now test again
import sys
sys.path.insert(0, 'mcp_tools_runner/university_incubator_analysis')

from data_generator import generate_incubator_data
from performance_analysis import analyze_performance
from structuration_analysis import analyze_structuration
from agency_analysis import analyze_agency
from reporting import generate_comprehensive_report

print("\n=== Testing University Incubator Analysis Tool ===\n")

# 1. Generate data
print("1. Generating data for 3 incubators over 8 periods...")
data = generate_incubator_data(num_incubators=3, time_periods=8, seed=42)
print(f"   ✓ Generated {len(data.metrics)} metrics")
print(f"   ✓ Generated {len(data.structuration_contexts)} structuration contexts")
print(f"   ✓ Generated {len(data.entrepreneur_profiles)} entrepreneur profiles\n")

# 2. Analyze performance
print("2. Analyzing performance...")
perf_analysis = analyze_performance(data)
print(f"   ✓ Analyzed {perf_analysis['summary']['total_incubators']} incubators")
print(f"   ✓ Average occupancy rate: {perf_analysis['summary']['avg_occupancy_rate']:.1%}")
print(f"   ✓ Total jobs created: {perf_analysis['summary']['total_jobs_created']}")
print(f"   ✓ Key insight: {perf_analysis['insights'][0]}\n")

# 3. Analyze structuration
print("3. Analyzing structuration...")
struct_analysis = analyze_structuration(data)
print(f"   ✓ Analyzed {struct_analysis['summary']['total_contexts']} contexts")
print(f"   ✓ Avg structural rigidity: {struct_analysis['summary']['avg_structural_rigidity']:.3f}")
print(f"   ✓ Avg agency space: {struct_analysis['summary']['avg_agency_space']:.3f}")
print(f"   ✓ Dominant process: {struct_analysis['summary']['dominant_process']}\n")

# 4. Analyze agency
print("4. Analyzing agency...")
agency_analysis_result = analyze_agency(data)
print(f"   ✓ Analyzed {agency_analysis_result['summary']['total_entrepreneurs']} entrepreneurs")
print(f"   ✓ Avg agency score: {agency_analysis_result['summary']['avg_agency_score']:.3f}")
print(f"   ✓ Dominant type: {agency_analysis_result['summary']['dominant_agency_type']}\n")

# 5. Generate report
print("5. Generating comprehensive report...")
data_dict = {
    "metrics": [m.model_dump() for m in data.metrics],
    "structuration_contexts": [c.model_dump() for c in data.structuration_contexts],
    "entrepreneur_profiles": [p.model_dump() for p in data.entrepreneur_profiles],
    "metadata": data.metadata
}

report = generate_comprehensive_report(
    data=data_dict,
    performance_analysis=perf_analysis,
    structuration_analysis=struct_analysis,
    agency_analysis=agency_analysis_result,
    output_format="markdown"
)

print(f"   ✓ Report generated in {report['format']} format")
print(f"   ✓ Report size: {len(report['formatted_content'])} characters\n")

print("=== All Tests Passed! ===\n")

# Save a sample report
with open('sample_incubator_report.md', 'w') as f:
    f.write(report['formatted_content'])
print("Sample report saved to: sample_incubator_report.md")