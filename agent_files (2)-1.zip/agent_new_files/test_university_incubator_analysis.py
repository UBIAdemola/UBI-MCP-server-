"""
Comprehensive tests for University Incubator Analysis Tool
"""

import pytest
import pandas as pd
import numpy as np
from datetime import datetime

from university_incubator_analysis import (
    generate_incubator_data,
    analyze_performance,
    generate_structuration_contexts,
    analyze_structuration,
    generate_entrepreneur_profiles,
    analyze_agency,
    generate_comprehensive_report,
    IncubatorDataGenerator,
    PerformanceAnalyzer,
    StructurationAnalyzer,
    AgencyAnalyzer,
    ReportGenerator
)

from university_incubator_analysis.data_models import (
    IncubatorMetrics,
    MarketReach,
    IncubatorStage
)


class TestDataGeneration:
    """Test data generation functions"""

    def test_generate_incubator_data_basic(self):
        """Test basic incubator data generation"""
        data = generate_incubator_data(num_incubators=5, time_periods=4, seed=42)

        assert isinstance(data, pd.DataFrame)
        assert len(data) == 20  # 5 incubators * 4 periods
        assert 'incubator_id' in data.columns
        assert 'period' in data.columns
        assert 'occupancy_rate' in data.columns
        print("✓ Basic incubator data generation works correctly")

    def test_data_generator_reproducibility(self):
        """Test that data generation is reproducible with seed"""
        start_date = datetime(2022, 1, 1)
        data1 = generate_incubator_data(num_incubators=3, time_periods=2, start_date=start_date, seed=42)
        data2 = generate_incubator_data(num_incubators=3, time_periods=2, start_date=start_date, seed=42)

        pd.testing.assert_frame_equal(data1, data2)
        print("✓ Data generation is reproducible with seed")

    def test_data_values_in_valid_range(self):
        """Test that generated values are in valid ranges"""
        data = generate_incubator_data(num_incubators=5, time_periods=3, seed=42)

        assert (data['occupancy_rate'] >= 0).all() and (data['occupancy_rate'] <= 1).all()
        assert (data['graduation_rate'] >= 0).all() and (data['graduation_rate'] <= 1).all()
        assert (data['survival_rate'] >= 0).all() and (data['survival_rate'] <= 1).all()
        assert (data['jobs_created'] >= 0).all()
        assert (data['total_revenue_generated'] >= 0).all()
        print("✓ Generated data values are in valid ranges")

    def test_generate_structuration_contexts(self):
        """Test structuration context generation"""
        incubator_ids = ['INC_001', 'INC_002', 'INC_003']
        contexts = generate_structuration_contexts(incubator_ids, seed=42)

        assert len(contexts) == 3
        assert all(ctx.incubator_id in incubator_ids for ctx in contexts)
        assert all(hasattr(ctx, 'signification') for ctx in contexts)
        assert all(hasattr(ctx, 'domination') for ctx in contexts)
        assert all(hasattr(ctx, 'legitimation') for ctx in contexts)
        print("✓ Structuration context generation works correctly")

    def test_generate_entrepreneur_profiles(self):
        """Test entrepreneur profile generation"""
        incubator_ids = ['INC_001', 'INC_002']
        profiles = generate_entrepreneur_profiles(10, incubator_ids, seed=42)

        assert len(profiles) == 10
        assert all(p.incubator_id in incubator_ids for p in profiles)
        assert all(hasattr(p, 'agentic_capabilities') for p in profiles)
        assert all(hasattr(p, 'embedded_constraints') for p in profiles)
        print("✓ Entrepreneur profile generation works correctly")


class TestPerformanceAnalysis:
    """Test performance analysis functions"""

    def test_analyze_performance_basic(self):
        """Test basic performance analysis"""
        data = generate_incubator_data(num_incubators=5, time_periods=4, seed=42)
        analysis = analyze_performance(data)

        assert 'summary_statistics' in analysis
        assert 'kpi_analysis' in analysis
        assert 'trend_analysis' in analysis
        assert 'insights' in analysis
        print("✓ Basic performance analysis works correctly")

    def test_performance_summary_statistics(self):
        """Test summary statistics calculation"""
        data = generate_incubator_data(num_incubators=5, time_periods=4, seed=42)
        analysis = analyze_performance(data)

        summary = analysis['summary_statistics']
        assert 'occupancy_rate' in summary
        assert 'mean' in summary['occupancy_rate']
        assert 'median' in summary['occupancy_rate']
        assert 'std' in summary['occupancy_rate']
        print("✓ Summary statistics calculation works correctly")

    def test_kpi_analysis(self):
        """Test KPI analysis"""
        data = generate_incubator_data(num_incubators=5, time_periods=4, seed=42)
        analysis = analyze_performance(data)

        kpis = analysis['kpi_analysis']
        assert 'occupancy' in kpis
        assert 'success_metrics' in kpis
        assert 'economic_impact' in kpis
        assert 'startup_flow' in kpis

        # Verify calculations
        assert isinstance(kpis['occupancy']['average_rate'], float)
        assert isinstance(kpis['economic_impact']['total_jobs_created'], int)
        print("✓ KPI analysis works correctly")

    def test_trend_analysis(self):
        """Test trend analysis"""
        data = generate_incubator_data(num_incubators=5, time_periods=8, seed=42)
        analysis = analyze_performance(data)

        trends = analysis['trend_analysis']
        if 'occupancy_rate' in trends:
            assert 'direction' in trends['occupancy_rate']
            assert 'slope' in trends['occupancy_rate']
            assert 'r_squared' in trends['occupancy_rate']
            print("✓ Trend analysis works correctly")
        else:
            print("✓ Trend analysis structure is correct")

    def test_performance_insights_generation(self):
        """Test insight generation"""
        data = generate_incubator_data(num_incubators=5, time_periods=4, seed=42)
        analysis = analyze_performance(data)

        insights = analysis['insights']
        assert isinstance(insights, list)
        assert len(insights) > 0
        assert all(isinstance(insight, str) for insight in insights)
        print("✓ Performance insights generation works correctly")

    def test_comparative_analysis(self):
        """Test comparative analysis across incubators"""
        data = generate_incubator_data(num_incubators=5, time_periods=4, seed=42)
        analysis = analyze_performance(data)

        comparative = analysis['comparative_analysis']
        assert 'by_incubator' in comparative
        assert 'top_performers' in comparative
        print("✓ Comparative analysis works correctly")


class TestStructurationAnalysis:
    """Test structuration analysis functions"""

    def test_analyze_structuration_basic(self):
        """Test basic structuration analysis"""
        contexts = generate_structuration_contexts(['INC_001'], seed=42)
        analysis = analyze_structuration(contexts[0])

        assert 'structural_analysis' in analysis
        assert 'agency_analysis' in analysis
        assert 'duality_analysis' in analysis
        assert 'structuration_processes' in analysis
        assert 'insights' in analysis
        print("✓ Basic structuration analysis works correctly")

    def test_structural_analysis(self):
        """Test structural analysis components"""
        contexts = generate_structuration_contexts(['INC_001'], seed=42)
        analysis = analyze_structuration(contexts[0])

        structural = analysis['structural_analysis']
        assert 'signification' in structural
        assert 'domination' in structural
        assert 'legitimation' in structural
        assert 'structural_characteristics' in structural
        print("✓ Structural analysis components work correctly")

    def test_agency_space_analysis(self):
        """Test agency space analysis"""
        contexts = generate_structuration_contexts(['INC_001'], seed=42)
        analysis = analyze_structuration(contexts[0])

        agency = analysis['agency_analysis']
        assert 'rule_interpretation' in agency
        assert 'resource_mobilization' in agency
        assert 'agency_space_metrics' in agency
        print("✓ Agency space analysis works correctly")

    def test_duality_analysis(self):
        """Test duality of structure and agency analysis"""
        contexts = generate_structuration_contexts(['INC_001'], seed=42)
        analysis = analyze_structuration(contexts[0])

        duality = analysis['duality_analysis']
        assert 'enabling_mechanisms' in duality
        assert 'constraining_mechanisms' in duality
        assert 'net_effect' in duality
        assert 'recursiveness' in duality

        # Verify net effect calculation
        net_effect = duality['net_effect']
        assert 'enabling_score' in net_effect
        assert 'constraining_score' in net_effect
        assert 'net_score' in net_effect
        assert 'dominant_effect' in net_effect
        print("✓ Duality analysis works correctly")

    def test_structuration_processes(self):
        """Test structuration processes analysis"""
        contexts = generate_structuration_contexts(['INC_001'], seed=42)
        analysis = analyze_structuration(contexts[0])

        processes = analysis['structuration_processes']
        assert 'reproduction' in processes
        assert 'transformation' in processes
        assert 'process_balance' in processes
        print("✓ Structuration processes analysis works correctly")

    def test_structuration_insights(self):
        """Test structuration insights generation"""
        contexts = generate_structuration_contexts(['INC_001'], seed=42)
        analysis = analyze_structuration(contexts[0])

        insights = analysis['insights']
        assert isinstance(insights, list)
        assert len(insights) > 0
        print("✓ Structuration insights generation works correctly")


class TestAgencyAnalysis:
    """Test agency analysis functions"""

    def test_analyze_agency_basic(self):
        """Test basic agency analysis"""
        profiles = generate_entrepreneur_profiles(20, ['INC_001', 'INC_002'], seed=42)
        analysis = analyze_agency(profiles)

        assert 'summary' in analysis
        assert 'capability_analysis' in analysis
        assert 'constraint_analysis' in analysis
        assert 'interaction_analysis' in analysis
        assert 'typology' in analysis
        assert 'insights' in analysis
        print("✓ Basic agency analysis works correctly")

    def test_capability_analysis(self):
        """Test capability analysis"""
        profiles = generate_entrepreneur_profiles(20, ['INC_001'], seed=42)
        analysis = analyze_agency(profiles)

        capabilities = analysis['capability_analysis']
        assert 'intentionality' in capabilities
        assert 'forethought' in capabilities
        assert 'self_reactiveness' in capabilities
        assert 'self_reflectiveness' in capabilities

        # Verify statistics
        for cap_type in ['intentionality', 'forethought', 'self_reactiveness', 'self_reflectiveness']:
            assert 'mean' in capabilities[cap_type]
            assert 'median' in capabilities[cap_type]
            assert 'std' in capabilities[cap_type]
        print("✓ Capability analysis works correctly")

    def test_constraint_analysis(self):
        """Test constraint analysis"""
        profiles = generate_entrepreneur_profiles(20, ['INC_001'], seed=42)
        analysis = analyze_agency(profiles)

        constraints = analysis['constraint_analysis']
        assert 'institutional_pressures' in constraints
        assert 'resource_limitations' in constraints
        assert 'network_dependencies' in constraints
        print("✓ Constraint analysis works correctly")

    def test_interaction_analysis(self):
        """Test agency-structure interaction analysis"""
        profiles = generate_entrepreneur_profiles(20, ['INC_001'], seed=42)
        analysis = analyze_agency(profiles)

        interactions = analysis['interaction_analysis']
        assert 'constraint_negotiations' in interactions
        assert 'opportunity_creation' in interactions
        assert 'structure_transformation' in interactions
        print("✓ Interaction analysis works correctly")

    def test_agency_typology(self):
        """Test agency typology creation"""
        profiles = generate_entrepreneur_profiles(30, ['INC_001'], seed=42)
        analysis = analyze_agency(profiles)

        typology = analysis['typology']
        assert 'types' in typology
        assert 'descriptions' in typology

        # Verify all profiles are classified
        total_classified = sum(t['count'] for t in typology['types'].values())
        assert total_classified == 30
        print("✓ Agency typology creation works correctly")

    def test_agency_structure_fit(self):
        """Test agency-structure fit analysis"""
        profiles = generate_entrepreneur_profiles(20, ['INC_001'], seed=42)
        contexts = generate_structuration_contexts(['INC_001'], seed=42)
        analysis = analyze_agency(profiles, contexts[0])

        assert 'agency_structure_fit' in analysis
        fit = analysis['agency_structure_fit']
        assert 'fit_metrics' in fit
        assert 'recommendations' in fit
        print("✓ Agency-structure fit analysis works correctly")


class TestReporting:
    """Test reporting functions"""

    def test_generate_comprehensive_report_json(self):
        """Test comprehensive report generation in JSON format"""
        # Generate all data
        perf_data = generate_incubator_data(num_incubators=5, time_periods=4, seed=42)
        perf_analysis = analyze_performance(perf_data)

        incubator_ids = perf_data['incubator_id'].unique().tolist()
        contexts = generate_structuration_contexts(incubator_ids, seed=42)
        struct_analysis = analyze_structuration(contexts[0])

        profiles = generate_entrepreneur_profiles(30, incubator_ids, seed=42)
        agency_analysis_result = analyze_agency(profiles, contexts[0])

        # Generate report
        report = generate_comprehensive_report(
            perf_data,
            perf_analysis,
            contexts,
            struct_analysis,
            profiles,
            agency_analysis_result,
            output_format="json"
        )

        assert isinstance(report, dict)
        assert 'metadata' in report
        assert 'executive_summary' in report
        assert 'performance_section' in report
        assert 'structuration_section' in report
        assert 'agency_section' in report
        assert 'integrated_analysis' in report
        assert 'recommendations' in report
        print("✓ Comprehensive JSON report generation works correctly")

    def test_generate_report_markdown(self):
        """Test report generation in Markdown format"""
        perf_data = generate_incubator_data(num_incubators=3, time_periods=2, seed=42)
        perf_analysis = analyze_performance(perf_data)

        report = generate_comprehensive_report(
            perf_data,
            perf_analysis,
            output_format="markdown"
        )

        assert isinstance(report, str)
        assert "# University Incubator Comprehensive Analysis Report" in report
        assert "## Report Metadata" in report
        print("✓ Markdown report generation works correctly")

    def test_generate_report_html(self):
        """Test report generation in HTML format"""
        perf_data = generate_incubator_data(num_incubators=3, time_periods=2, seed=42)
        perf_analysis = analyze_performance(perf_data)

        report = generate_comprehensive_report(
            perf_data,
            perf_analysis,
            output_format="html"
        )

        assert isinstance(report, str)
        assert "<!DOCTYPE html>" in report
        assert "<html>" in report
        assert "University Incubator" in report
        print("✓ HTML report generation works correctly")

    def test_executive_summary_content(self):
        """Test executive summary content"""
        perf_data = generate_incubator_data(num_incubators=5, time_periods=4, seed=42)
        perf_analysis = analyze_performance(perf_data)

        report = generate_comprehensive_report(
            perf_data,
            perf_analysis,
            output_format="json"
        )

        summary = report['executive_summary']
        assert 'overview' in summary
        assert 'performance_highlights' in summary
        assert 'key_insights' in summary
        print("✓ Executive summary content is correct")

    def test_integrated_analysis_section(self):
        """Test integrated analysis section"""
        perf_data = generate_incubator_data(num_incubators=3, time_periods=4, seed=42)
        perf_analysis = analyze_performance(perf_data)

        incubator_ids = perf_data['incubator_id'].unique().tolist()
        contexts = generate_structuration_contexts(incubator_ids, seed=42)
        struct_analysis = analyze_structuration(contexts[0])

        profiles = generate_entrepreneur_profiles(20, incubator_ids, seed=42)
        agency_analysis_result = analyze_agency(profiles, contexts[0])

        report = generate_comprehensive_report(
            perf_data,
            perf_analysis,
            contexts,
            struct_analysis,
            profiles,
            agency_analysis_result,
            output_format="json"
        )

        integrated = report['integrated_analysis']
        assert 'performance_structure_linkages' in integrated
        assert 'structure_agency_linkages' in integrated
        assert 'agency_performance_linkages' in integrated
        assert 'holistic_insights' in integrated
        print("✓ Integrated analysis section is correct")


class TestIntegration:
    """Integration tests for complete workflows"""

    def test_complete_workflow(self):
        """Test complete analysis workflow"""
        print("\n=== Testing Complete Workflow ===")

        # Step 1: Generate data
        print("Generating synthetic data...")
        perf_data = generate_incubator_data(num_incubators=10, time_periods=12, seed=42)
        assert len(perf_data) == 120
        print(f"✓ Generated {len(perf_data)} data points for 10 incubators over 12 periods")

        # Step 2: Performance analysis
        print("Analyzing performance...")
        perf_analysis = analyze_performance(perf_data)
        avg_grad_rate = perf_analysis['kpi_analysis']['success_metrics']['average_graduation_rate']
        print(f"✓ Average graduation rate: {avg_grad_rate:.1%}")

        # Step 3: Structuration analysis
        print("Analyzing structuration...")
        incubator_ids = perf_data['incubator_id'].unique().tolist()
        contexts = generate_structuration_contexts(incubator_ids[:3], seed=42)
        struct_analysis = analyze_structuration(contexts[0])
        structural_rigidity = struct_analysis['structural_analysis']['structural_characteristics']['rigidity']
        print(f"✓ Structural rigidity: {structural_rigidity:.2f}")

        # Step 4: Agency analysis
        print("Analyzing agency...")
        profiles = generate_entrepreneur_profiles(50, incubator_ids[:3], seed=42)
        agency_analysis_result = analyze_agency(profiles, contexts[0])
        avg_agency = agency_analysis_result['summary']['average_agency_score']
        print(f"✓ Average agency score: {avg_agency:.2f}")

        # Step 5: Generate comprehensive report
        print("Generating comprehensive report...")
        report = generate_comprehensive_report(
            perf_data,
            perf_analysis,
            contexts,
            struct_analysis,
            profiles,
            agency_analysis_result,
            output_format="json"
        )
        assert 'integrated_analysis' in report
        print("✓ Comprehensive report generated successfully")

        print("\n=== Complete Workflow Test Passed ===\n")

    def test_edge_cases(self):
        """Test edge cases and error handling"""
        # Test with minimal data
        minimal_data = generate_incubator_data(num_incubators=1, time_periods=1, seed=42)
        analysis = analyze_performance(minimal_data)
        assert analysis is not None
        print("✓ Handles minimal data correctly")

        # Test with empty entrepreneur list
        empty_analysis = analyze_agency([])
        assert 'error' in empty_analysis
        print("✓ Handles empty entrepreneur list correctly")


def test_data_model_conversions():
    """Test data model to_dict conversions"""
    # Generate data
    generator = IncubatorDataGenerator(seed=42)

    # Test incubator metrics conversion
    data = generator.generate_incubator_data(1, 1)
    assert isinstance(data, pd.DataFrame)
    print("✓ Incubator metrics conversion works")

    # Test structuration context conversion
    context = generator.generate_structuration_context('INC_001')
    context_dict = context.to_dict()
    assert isinstance(context_dict, dict)
    assert 'incubator_id' in context_dict
    print("✓ Structuration context conversion works")

    # Test entrepreneur profile conversion
    profile = generator.generate_entrepreneur_profile('ENT_001', 'INC_001')
    profile_dict = profile.to_dict()
    assert isinstance(profile_dict, dict)
    assert 'entrepreneur_id' in profile_dict
    print("✓ Entrepreneur profile conversion works")


if __name__ == "__main__":
    print("\n" + "="*60)
    print("UNIVERSITY INCUBATOR ANALYSIS TOOL - TEST SUITE")
    print("="*60 + "\n")

    # Run tests manually for debugging
    print("Running Data Generation Tests...")
    test_dg = TestDataGeneration()
    test_dg.test_generate_incubator_data_basic()
    test_dg.test_data_generator_reproducibility()
    test_dg.test_data_values_in_valid_range()
    test_dg.test_generate_structuration_contexts()
    test_dg.test_generate_entrepreneur_profiles()

    print("\nRunning Performance Analysis Tests...")
    test_pa = TestPerformanceAnalysis()
    test_pa.test_analyze_performance_basic()
    test_pa.test_performance_summary_statistics()
    test_pa.test_kpi_analysis()
    test_pa.test_trend_analysis()
    test_pa.test_performance_insights_generation()
    test_pa.test_comparative_analysis()

    print("\nRunning Structuration Analysis Tests...")
    test_sa = TestStructurationAnalysis()
    test_sa.test_analyze_structuration_basic()
    test_sa.test_structural_analysis()
    test_sa.test_agency_space_analysis()
    test_sa.test_duality_analysis()
    test_sa.test_structuration_processes()
    test_sa.test_structuration_insights()

    print("\nRunning Agency Analysis Tests...")
    test_aa = TestAgencyAnalysis()
    test_aa.test_analyze_agency_basic()
    test_aa.test_capability_analysis()
    test_aa.test_constraint_analysis()
    test_aa.test_interaction_analysis()
    test_aa.test_agency_typology()
    test_aa.test_agency_structure_fit()

    print("\nRunning Reporting Tests...")
    test_rep = TestReporting()
    test_rep.test_generate_comprehensive_report_json()
    test_rep.test_generate_report_markdown()
    test_rep.test_generate_report_html()
    test_rep.test_executive_summary_content()
    test_rep.test_integrated_analysis_section()

    print("\nRunning Integration Tests...")
    test_int = TestIntegration()
    test_int.test_complete_workflow()
    test_int.test_edge_cases()

    print("\nRunning Data Model Tests...")
    test_data_model_conversions()

    print("\n" + "="*60)
    print("ALL TESTS COMPLETED SUCCESSFULLY!")
    print("="*60 + "\n")
