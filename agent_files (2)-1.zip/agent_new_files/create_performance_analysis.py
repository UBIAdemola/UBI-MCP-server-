
# BEGIN: user added these matplotlib lines to ensure any plots do not pop-up in their UI
import matplotlib
matplotlib.use('Agg')  # Set the backend to non-interactive
import matplotlib.pyplot as plt
plt.ioff()
import os
os.environ['TERM'] = 'dumb'
# END: user added these matplotlib lines to ensure any plots do not pop-up in their UI
# filename: create_performance_analysis.py
# execution: true

performance_analysis_code = '''"""
Performance analysis module for University Incubator Analysis.

Analyzes KPIs and generates performance reports.
"""

from typing import Dict, List
from data_models import IncubatorData, IncubatorMetrics


def analyze_performance(data: IncubatorData) -> Dict:
    """
    Analyze incubator performance metrics.
    
    Args:
        data: IncubatorData object containing metrics
        
    Returns:
        Dictionary with performance analysis results
    """
    if not data.metrics:
        raise ValueError("No metrics data provided")
    
    # Group metrics by incubator
    incubator_metrics = {}
    for metric in data.metrics:
        if metric.incubator_id not in incubator_metrics:
            incubator_metrics[metric.incubator_id] = []
        incubator_metrics[metric.incubator_id].append(metric)
    
    # Analyze each incubator
    incubator_analyses = {}
    for incubator_id, metrics in incubator_metrics.items():
        analysis = _analyze_single_incubator(metrics)
        incubator_analyses[incubator_id] = analysis
    
    # Calculate aggregate statistics
    aggregate = _calculate_aggregate_stats(data.metrics)
    
    # Generate insights
    insights = _generate_insights(incubator_analyses, aggregate)
    
    return {
        "incubator_analyses": incubator_analyses,
        "aggregate_statistics": aggregate,
        "insights": insights,
        "summary": {
            "total_incubators": len(incubator_metrics),
            "total_periods": len(data.metrics),
            "avg_occupancy_rate": aggregate["avg_occupancy_rate"],
            "total_jobs_created": aggregate["total_jobs_created"],
            "total_funding_raised": aggregate["total_funding_raised"]
        }
    }


def _analyze_single_incubator(metrics: List[IncubatorMetrics]) -> Dict:
    """Analyze metrics for a single incubator."""
    
    # Calculate averages
    avg_occupancy = sum(m.occupancy_rate for m in metrics if m.occupancy_rate) / len(metrics)
    avg_graduation = sum(m.graduation_rate for m in metrics if m.graduation_rate) / len(metrics)
    avg_survival_1yr = sum(m.survival_rate_1yr for m in metrics) / len(metrics)
    avg_survival_3yr = sum(m.survival_rate_3yr for m in metrics) / len(metrics)
    
    # Calculate totals
    total_admitted = sum(m.startups_admitted for m in metrics)
    total_graduated = sum(m.startups_graduated for m in metrics)
    total_jobs = sum(m.jobs_created for m in metrics)
    total_revenue = sum(m.total_revenue for m in metrics)
    total_funding = sum(m.funding_raised for m in metrics)
    
    # Calculate trends (simple linear)
    if len(metrics) > 1:
        occupancy_trend = (metrics[-1].occupancy_rate - metrics[0].occupancy_rate) / len(metrics)
        jobs_trend = (metrics[-1].jobs_created - metrics[0].jobs_created) / len(metrics)
    else:
        occupancy_trend = 0
        jobs_trend = 0
    
    # Performance rating
    performance_score = (
        avg_occupancy * 0.2 +
        avg_graduation * 0.2 +
        avg_survival_1yr * 0.3 +
        avg_survival_3yr * 0.3
    )
    
    if performance_score > 0.8:
        rating = "Excellent"
    elif performance_score > 0.6:
        rating = "Good"
    elif performance_score > 0.4:
        rating = "Fair"
    else:
        rating = "Needs Improvement"
    
    return {
        "averages": {
            "occupancy_rate": round(avg_occupancy, 3),
            "graduation_rate": round(avg_graduation, 3),
            "survival_rate_1yr": round(avg_survival_1yr, 3),
            "survival_rate_3yr": round(avg_survival_3yr, 3)
        },
        "totals": {
            "startups_admitted": total_admitted,
            "startups_graduated": total_graduated,
            "jobs_created": total_jobs,
            "total_revenue": round(total_revenue, 2),
            "funding_raised": round(total_funding, 2)
        },
        "trends": {
            "occupancy_trend": round(occupancy_trend, 4),
            "jobs_trend": round(jobs_trend, 2)
        },
        "performance_score": round(performance_score, 3),
        "rating": rating
    }


def _calculate_aggregate_stats(metrics: List[IncubatorMetrics]) -> Dict:
    """Calculate aggregate statistics across all incubators."""
    
    total_jobs = sum(m.jobs_created for m in metrics)
    total_revenue = sum(m.total_revenue for m in metrics)
    total_funding = sum(m.funding_raised for m in metrics)
    
    avg_occupancy = sum(m.occupancy_rate for m in metrics if m.occupancy_rate) / len(metrics)
    avg_graduation = sum(m.graduation_rate for m in metrics if m.graduation_rate) / len(metrics)
    
    return {
        "total_jobs_created": total_jobs,
        "total_revenue": round(total_revenue, 2),
        "total_funding_raised": round(total_funding, 2),
        "avg_occupancy_rate": round(avg_occupancy, 3),
        "avg_graduation_rate": round(avg_graduation, 3)
    }


def _generate_insights(incubator_analyses: Dict, aggregate: Dict) -> List[str]:
    """Generate insights from the analysis."""
    
    insights = []
    
    # Identify top performers
    top_incubators = sorted(
        incubator_analyses.items(),
        key=lambda x: x[1]["performance_score"],
        reverse=True
    )[:3]
    
    insights.append(
        f"Top performing incubators: {', '.join([inc_id for inc_id, _ in top_incubators])}"
    )
    
    # Occupancy insights
    if aggregate["avg_occupancy_rate"] > 0.8:
        insights.append("High occupancy rates indicate strong demand for incubator services")
    elif aggregate["avg_occupancy_rate"] < 0.6:
        insights.append("Low occupancy rates suggest need for marketing or service improvements")
    
    # Job creation insights
    insights.append(
        f"Incubators collectively created {aggregate['total_jobs_created']} jobs"
    )
    
    # Funding insights
    insights.append(
        f"Total funding raised by incubatees: ${aggregate['total_funding_raised']:,.2f}"
    )
    
    return insights
'''

# Write the file
with open('mcp_tools_runner/university_incubator_analysis/performance_analysis.py', 'w') as f:
    f.write(performance_analysis_code)

print("Created performance_analysis.py")
print(f"File size: {len(performance_analysis_code)} characters")