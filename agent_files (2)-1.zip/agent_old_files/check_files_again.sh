# filename: check_files_again.sh
# execution: true
ls -l mcp_tools_runner/random_generator/