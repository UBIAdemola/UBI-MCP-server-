
# BEGIN: user added these matplotlib lines to ensure any plots do not pop-up in their UI
import matplotlib
matplotlib.use('Agg')  # Set the backend to non-interactive
import matplotlib.pyplot as plt
plt.ioff()
import os
os.environ['TERM'] = 'dumb'
# END: user added these matplotlib lines to ensure any plots do not pop-up in their UI
# filename: test_generate_uuid.py
# execution: true
from api_server.agent_tools.claude_tool_runner import claude_tool_runner
result_dict = claude_tool_runner(query="Generate a UUID using the 'random_generator' tool.", tools=["random_generator"])