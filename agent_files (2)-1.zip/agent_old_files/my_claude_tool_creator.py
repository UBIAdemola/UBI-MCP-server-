
# BEGIN: user added these matplotlib lines to ensure any plots do not pop-up in their UI
import matplotlib
matplotlib.use('Agg')  # Set the backend to non-interactive
import matplotlib.pyplot as plt
plt.ioff()
import os
os.environ['TERM'] = 'dumb'
# END: user added these matplotlib lines to ensure any plots do not pop-up in their UI
# filename: my_claude_tool_creator.py
# execution: true
from api_server.agent_tools.claude_tool_creator import claude_tool_creator
result_dict = claude_tool_creator(query="""
Create a local MCP tool named 'random_generator'.
Ensure the tool's files are placed in the standard MCP directory structure:
'./mcp_tools_runner/random_generator/'.

1.  **server.py**:
    *   Implement a `random_number(min, max)` function that generates a random integer between `min` and `max` (inclusive). It should handle `ValueError` if `min` or `max` are not integers, or if `min > max`.
    *   Implement a `random_string(length)` function that generates a random alphanumeric string of the specified `length`. It should handle `ValueError` if `length` is not a positive integer.
    *   Implement a `random_choice(items)` function that picks a random item from a comma-separated string of `items`. It should handle `ValueError` if `items` is empty or not a string.
    *   Implement a `generate_uuid()` function that generates a UUID.
    *   Use Python's `random` and `uuid` libraries.
    *   Ensure the `server.py` is a fastMCPv2 server.

2.  **description.md**:
    *   Create a markdown file describing the 'random_generator' tool and each of its functions, including their parameters and what they return.
    *   Explain the error handling for each function.

No environment variables are needed for this tool.
""", build_mcp=True)