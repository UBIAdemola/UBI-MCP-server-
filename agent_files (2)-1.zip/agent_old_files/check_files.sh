# filename: check_files.sh
# execution: true
ls -l mcp_tools_runner/random_generator/