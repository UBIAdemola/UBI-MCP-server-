# random_generator MCP Tool

This MCP tool provides various functions for generating random numbers, strings, choices, and UUIDs.

## Functions:

### `random_number(min, max)`

Generates a random integer between `min` and `max` (inclusive).

*   **Parameters:**
    *   `min` (integer): The minimum value (inclusive).
    *   `max` (integer): The maximum value (inclusive).

*   **Returns:**
    *   `random_number` (integer): A random integer.

*   **Error Handling:**
    *   Raises `ValueError` if `min` or `max` are not integers.
    *   Raises `ValueError` if `min` is greater than `max`.

### `random_string(length)`

Generates a random alphanumeric string of the specified `length`.

*   **Parameters:**
    *   `length` (integer): The desired length of the string.

*   **Returns:**
    *   `random_string` (string): A random alphanumeric string.

*   **Error Handling:**
    *   Raises `ValueError` if `length` is not a positive integer.

### `random_choice(items)`

Picks a random item from a comma-separated string of `items`.

*   **Parameters:**
    *   `items` (string): A comma-separated string of items (e.g., "apple,banana,orange").

*   **Returns:**
    *   `random_item` (string): A randomly selected item from the list.

*   **Error Handling:**
    *   Raises `ValueError` if `items` is not a string, is empty, or contains no valid items after splitting.

### `generate_uuid()`

Generates a universally unique identifier (UUID).

*   **Parameters:** None

*   **Returns:**
    *   `uuid` (string): A randomly generated UUID string.

*   **Error Handling:** None
