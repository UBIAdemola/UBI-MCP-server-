import random
import uuid
import string
from fastmcp import FastMCP
from pydantic import BaseModel, Field

mcp = FastMCP("Random Generator")

class RandomNumberRequest(BaseModel):
    min: int = Field(..., description="The minimum value (inclusive).")
    max: int = Field(..., description="The maximum value (inclusive).")

class RandomNumberResponse(BaseModel):
    random_number: int

@mcp.tool()
def random_number(request: RandomNumberRequest) -> RandomNumberResponse:
    """Generates a random integer between min and max (inclusive)."""
    if not isinstance(request.min, int) or not isinstance(request.max, int):
        raise ValueError("Min and max must be integers.")
    if request.min > request.max:
        raise ValueError("Min cannot be greater than max.")
    return RandomNumberResponse(random_number=random.randint(request.min, request.max))

class RandomStringRequest(BaseModel):
    length: int = Field(..., description="The length of the random alphanumeric string.")

class RandomStringResponse(BaseModel):
    random_string: str

@mcp.tool()
def random_string(request: RandomStringRequest) -> RandomStringResponse:
    """Generates a random alphanumeric string of the specified length."""
    if not isinstance(request.length, int) or request.length <= 0:
        raise ValueError("Length must be a positive integer.")
    characters = string.ascii_letters + string.digits
    return RandomStringResponse(random_string=''.join(random.choice(characters) for i in range(request.length)))

class RandomChoiceRequest(BaseModel):
    items: str = Field(..., description="A comma-separated string of items to choose from.")

class RandomChoiceResponse(BaseModel):
    random_item: str

@mcp.tool()
def random_choice(request: RandomChoiceRequest) -> RandomChoiceResponse:
    """Picks a random item from a comma-separated string of items."""
    if not isinstance(request.items, str) or not request.items.strip():
        raise ValueError("Items must be a non-empty comma-separated string.")
    item_list = [item.strip() for item in request.items.split(',') if item.strip()]
    if not item_list:
        raise ValueError("No valid items found in the comma-separated string.")
    return RandomChoiceResponse(random_item=random.choice(item_list))

class GenerateUuidResponse(BaseModel):
    uuid: str

@mcp.tool()
def generate_uuid() -> GenerateUuidResponse:
    """Generates a UUID."""
    return GenerateUuidResponse(uuid=str(uuid.uuid4()))

if __name__ == "__main__":
    mcp.run()
