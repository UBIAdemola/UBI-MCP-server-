# filename: cat_description.sh
# execution: true
cat mcp_tools_runner/random_generator/description.md