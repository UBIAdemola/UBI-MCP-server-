# filename: cat_server.sh
# execution: true
cat mcp_tools_runner/random_generator/server.py